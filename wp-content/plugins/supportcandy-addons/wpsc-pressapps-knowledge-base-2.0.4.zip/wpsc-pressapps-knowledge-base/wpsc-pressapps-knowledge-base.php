<?php
/**
 * Plugin Name: SupportCandy - Knowledgebase Integration
 * Plugin URI: https://supportcandy.net/
 * Description: Knowledgebase by Pressapps integration for SupportCandy
 * Version: 2.0.4
 * Author: Support Candy
 * Author URI: https://supportcandy.net/
 * Requires at least: 4.4
 * Tested up to: 4.9
 * Text Domain: wpsc-prass-kb
 * Domain Path: /lang
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if ( ! class_exists( 'Support_Candy_PRASS_KB' ) ) :

  final class Support_Candy_PRASS_KB {

    public $version = '2.0.4';

    public function __construct() {
    
		  $this->define_constants();
			$this->includes();
			add_action( 'init', array($this,'load_textdomain') );
			
    }

    function define_constants() {
      $this->define('WPSC_PRASS_KB_PLUGIN_FILE', __FILE__);
      $this->define('WPSC_PRASS_KB_ABSPATH', dirname(__FILE__) . '/');
      $this->define('WPSC_PRASS_KB_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
      $this->define('WPSC_PRASS_KB_PLUGIN_BASENAME', plugin_basename(__FILE__));
			$this->define('WPSC_PRASS_KB_STORE_ID', '269');
      $this->define('WPSC_PRASS_KB_VERSION', $this->version);
    }

    function load_textdomain(){
      $locale = apply_filters( 'plugin_locale', get_locale(), 'wpsc-prass-kb' );
      load_textdomain( 'wpsc-prass-kb', WP_LANG_DIR . '/wpsc/wpsc-prass-kb-' . $locale . '.mo' );
      load_plugin_textdomain( 'wpsc-prass-kb', false, plugin_basename( dirname( __FILE__ ) ) . '/lang' );
    }

    public function includes() {
      $select_knowledgbase = get_option('wpsc_select_knowledgbase_set','');
      include_once( WPSC_PRASS_KB_ABSPATH . 'class-wpsc-prasskb-install.php' );
      include_once( WPSC_PRASS_KB_ABSPATH . 'class-wpsc-prasskb.php' );
      $prasskb = new WPSC_PRASSKB();

			// Setting
      add_action( 'wpsc_after_setting_pills', array($prasskb,'kb_setting_pill'));
      add_action( 'wp_ajax_wpsc_get_kb_settings', array($prasskb,'get_kb_settings'));
			add_action( 'wp_ajax_wpsc_set_kb_settings', array($prasskb,'set_kb_settings'));

			//prassapp actions
			if($select_knowledgbase=='WPSC_PrassApp_Knowledgbase'){
			add_action('wpsc_add_addon_tab_after_macro', array($prasskb, 'knowledgebase_macro'));
			add_action('wp_ajax_wpsc_get_prass_knowledgbase', array($prasskb, 'get_prass_knowledgbase'));
			add_action('wp_ajax_wpsc_prass_kb_insert_link', array($prasskb, 'insert_link'));
			add_action('wp_ajax_wpsc_prass_kb_insert_text', array($prasskb, 'insert_text'));

			// replace tag for kb suggestions

			add_filter('wpsc_replace_macro', array($prasskb, 'replace_macro'), 10, 3);
		} elseif ($select_knowledgbase=='WPSC_WP_Knowledgbase') {

			//WP knowledgbase
			add_action('wpsc_add_addon_tab_after_macro', array($prasskb, 'wp_knowledgebase_macro'));
			add_action('wp_ajax_wpsc_get_wp_knowledgbase', array($prasskb, 'get_wp_knowledgbase'));
			add_action('wp_ajax_wpsc_wp_kb_insert_link', array($prasskb, 'wp_insert_link'));
			add_action('wp_ajax_wpsc_wp_kb_insert_text', array($prasskb, 'wp_insert_text'));

			// replace tag for kb suggestions
			add_filter('wpsc_replace_macro', array($prasskb, 'wp_replace_macro'), 10, 3);
		} else if($select_knowledgbase=='WPSC_BasePress_Knowledgbase'){
			add_action('wpsc_add_addon_tab_after_macro', array($prasskb, 'base_press_knowledgebase_macro'));
			add_action('wp_ajax_wpsc_get_base_press_knowledgebase', array($prasskb, 'get_base_press_knowledgebase'));
			add_action('wp_ajax_wpsc_base_press_kb_insert_link', array($prasskb, 'base_press_insert_link'));
			add_action('wp_ajax_wpsc_base_press_kb_insert_text', array($prasskb, 'base_press_insert_text'));

				// replace tag for kb suggestions
			add_filter('wpsc_replace_macro', array($prasskb, 'base_press_replace_macro'), 10, 3);
		}else if($select_knowledgbase=='WPSC_HelpGuru_Knowledgbase'){
			add_action('wpsc_add_addon_tab_after_macro', array($prasskb, 'hg_knowledgebase_macro'));
			add_action('wp_ajax_wpsc_get_hg_knowledgbase', array($prasskb, 'get_hg_knowledgbase'));
			add_action('wp_ajax_wpsc_hg_kb_insert_link', array($prasskb, 'hg_insert_link'));
			add_action('wp_ajax_wpsc_hg_kb_insert_text', array($prasskb, 'hg_insert_text'));
			add_filter('wpsc_replace_macro', array($prasskb, 'hg_replace_macro'), 10, 3);
		}else if ($select_knowledgbase=='WPSC_BWL_Knowledgbase'){
			add_action('wpsc_add_addon_tab_after_macro', array($prasskb, 'bwl_knowledgebase_macro'));
			add_action('wp_ajax_wpsc_get_bwl_knowledgbase', array($prasskb, 'get_bwl_knowledgbase'));
			add_action('wp_ajax_wpsc_bwl_kb_insert_link', array($prasskb, 'bwl_insert_link'));
			add_action('wp_ajax_wpsc_bwl_kb_insert_text', array($prasskb, 'bwl_insert_text'));
			add_filter('wpsc_replace_macro', array($prasskb, 'bwl_replace_macro'), 10, 3);
		}else if ($select_knowledgbase=='WPSC_Echo_Knowledgbase'){
			add_action('wpsc_add_addon_tab_after_macro', array($prasskb, 'echo_knowledgebase_macro'));
			add_action('wp_ajax_wpsc_get_echo_knowledgbase', array($prasskb, 'get_echo_knowledgbase'));
			add_action('wp_ajax_wpsc_echo_insert_link', array($prasskb, 'echo_insert_link'));
			add_action('wp_ajax_wpsc_echo_insert_text', array($prasskb, 'echo_insert_text'));
			add_filter('wpsc_replace_macro', array($prasskb, 'echo_replace_macro'), 10, 3);
		}elseif($select_knowledgbase=='WPSC_Knowledgebase_Helpdesk'){
			add_action('wpsc_add_addon_tab_after_macro', array($prasskb, 'kbx_macro'));
			add_action('wp_ajax_wpsc_get_knowledgebase_helpdesk', array($prasskb, 'get_knowledgebase_helpdesk'));
			add_action('wp_ajax_wpsc_kbx_insert_link', array($prasskb, 'kbx_insert_link'));
			add_action('wp_ajax_wpsc_kbx_insert_text', array($prasskb, 'kbx_insert_text'));
			add_filter('wpsc_replace_macro', array($prasskb, 'kbx_replace_macro'), 10, 3);	
		}elseif($select_knowledgbase=='WPSC_BetterDocs'){
			add_action('wpsc_add_addon_tab_after_macro', array($prasskb, 'betterdocs_knowledgbase_macro'));
			add_action('wp_ajax_wpsc_get_betterdocs_knowledgbase', array($prasskb, 'get_betterdocs_knowledgbase'));
			add_action('wp_ajax_wpsc_betterdocs_insert_link', array($prasskb, 'betterdocs_insert_link'));
			add_action('wp_ajax_wpsc_betterdocs_insert_text', array($prasskb, 'betterdocs_insert_text'));
			add_filter('wpsc_replace_macro', array($prasskb, 'betterdocs_replace_macro'), 10, 3);	
		}

			// License
		add_filter( 'wpsc_is_add_on_installed', array($prasskb,'is_add_on_installed'));
		add_action( 'wpsc_addon_license_area', array($prasskb,'addon_license_area'));
		add_action( 'wp_ajax_wpsc_prass_kb_activate_license', array($prasskb,'license_activate'));
		add_action( 'wp_ajax_wpsc_prass_kb_deactivate_license', array($prasskb,'license_deactivate'));
		add_action( 'admin_init', array($this, 'plugin_updator'));

    }

    private function define($name, $value) {
      if (!defined($name)) {
        define($name, $value);
      }
    }

		function plugin_updator(){
			$license_key    = get_option('wpsc_prass_kb_license_key','');
			$license_expiry = get_option('wpsc_prass_kb_license_expiry','');
			if ( class_exists('Support_Candy') && $license_key && $license_expiry ) {
				$edd_updater = new EDD_SL_Plugin_Updater( WPSC_STORE_URL, __FILE__, array(
								'version' => WPSC_PRASS_KB_VERSION,
								'license' => $license_key,
								'item_id' => WPSC_PRASS_KB_STORE_ID,
								'author'  => 'Pradeep Makone',
								'url'     => site_url()
				) );
			}
    }
  }

endif;

new Support_Candy_PRASS_KB();
