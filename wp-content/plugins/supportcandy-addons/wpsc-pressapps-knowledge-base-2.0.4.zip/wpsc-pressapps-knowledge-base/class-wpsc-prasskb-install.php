<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if ( ! class_exists( 'WPSC_PRASSKB_Install' ) ) :
  
  final class WPSC_PRASSKB_Install {
    
    public function __construct() {
      $this->check_version();
    }
    
		/**
     * Check version of WPSC
     */
    public function check_version(){
        $installed_version = get_option( 'wpsc_prasskb_current_version', 0 );
        if( $installed_version != WPSC_PRASS_KB_VERSION ){
            add_action( 'init', array($this,'upgrade'), 101 );
        }

    }
    
    // Upgrade
		public function upgrade(){
				
        $installed_version = get_option( 'wpsc_prasskb_current_version', 0 );
				$installed_version = $installed_version ? $installed_version : 0;
				
				if ( $installed_version < '1.0.0' ) {
					$term = wp_insert_term( 'prassapp_kb_suggestions', 'wpsc_ticket_custom_fields' );
					if ( !is_wp_error($term) && isset($term['term_id'])) {
						add_term_meta ($term['term_id'], 'wpsc_tf_label', __('Knowledgebase Suggestions','wpsc-prass-kb'));
						add_term_meta ($term['term_id'], 'agentonly', '2');
						add_term_meta ($term['term_id'], 'wpsc_tf_type', '0');
						add_term_meta ($term['term_id'], 'wpsc_allow_ticket_list', '0');
						add_term_meta ($term['term_id'], 'wpsc_allow_ticket_filter', '0');
					}
					
        }
				if ( $installed_version < '1.0.1' ) {
					
						$term = wp_insert_term( 'wp_knowledgebase_suggestions', 'wpsc_ticket_custom_fields' );
						if ( !is_wp_error($term) && isset($term['term_id'])) {
							add_term_meta ($term['term_id'], 'wpsc_tf_label', __('Knowledgebase Suggestions','wpsc-prass-kb'));
							add_term_meta ($term['term_id'], 'agentonly', '2');
							add_term_meta ($term['term_id'], 'wpsc_tf_type', '0');
							add_term_meta ($term['term_id'], 'wpsc_allow_ticket_list', '0');
							add_term_meta ($term['term_id'], 'wpsc_allow_ticket_filter', '0');
						}
						
						update_option('wpsc_select_knowledgbase_set','WPSC_PrassApp_Knowledgbase');
				}
				if ( $installed_version < '1.0.4' ) {
					
						$term = wp_insert_term( 'basepress_kb_suggestions', 'wpsc_ticket_custom_fields' );
						if ( !is_wp_error($term) && isset($term['term_id'])) {
							add_term_meta ($term['term_id'], 'wpsc_tf_label', __('Knowledgebase Suggestions','wpsc-prass-kb'));
							add_term_meta ($term['term_id'], 'agentonly', '2');
							add_term_meta ($term['term_id'], 'wpsc_tf_type', '0');
							add_term_meta ($term['term_id'], 'wpsc_allow_ticket_list', '0');
							add_term_meta ($term['term_id'], 'wpsc_allow_ticket_filter', '0');
						}
						
						$term = wp_insert_term( 'helpguru_knowledgebase_suggestions', 'wpsc_ticket_custom_fields' );
						if ( !is_wp_error($term) && isset($term['term_id'])) {
							add_term_meta ($term['term_id'], 'wpsc_tf_label', __('Knowledgebase Suggestions','wpsc-prass-kb'));
							add_term_meta ($term['term_id'], 'agentonly', '2');
							add_term_meta ($term['term_id'], 'wpsc_tf_type', '0');
							add_term_meta ($term['term_id'], 'wpsc_allow_ticket_list', '0');
							add_term_meta ($term['term_id'], 'wpsc_allow_ticket_filter', '0');
						}	
					
				}
				if ( $installed_version < '1.0.5' ) {
					
						$term = wp_insert_term( 'bwl_kb_suggestions', 'wpsc_ticket_custom_fields' );
						if ( !is_wp_error($term) && isset($term['term_id'])) {
							add_term_meta ($term['term_id'], 'wpsc_tf_label', __('Knowledgebase Suggestions','wpsc-prass-kb'));
							add_term_meta ($term['term_id'], 'agentonly', '2');
							add_term_meta ($term['term_id'], 'wpsc_tf_type', '0');
							add_term_meta ($term['term_id'], 'wpsc_allow_ticket_list', '0');
							add_term_meta ($term['term_id'], 'wpsc_allow_ticket_filter', '0');
						}
				}	
				
				if ( $installed_version < '1.0.6' ) {
					
						$term = wp_insert_term( 'echo_knowledgebase_suggestions', 'wpsc_ticket_custom_fields' );
						if ( !is_wp_error($term) && isset($term['term_id'])) {
							add_term_meta ($term['term_id'], 'wpsc_tf_label', __('Knowledgebase Suggestions','wpsc-prass-kb'));
							add_term_meta ($term['term_id'], 'agentonly', '2');
							add_term_meta ($term['term_id'], 'wpsc_tf_type', '0');
							add_term_meta ($term['term_id'], 'wpsc_allow_ticket_list', '0');
							add_term_meta ($term['term_id'], 'wpsc_allow_ticket_filter', '0');
						}
				}

		if($installed_version < '2.0.2'){
			$term = wp_insert_term( 'knowledgebase_helpdesk_pro', 'wpsc_ticket_custom_fields' );
			if ( !is_wp_error($term) && isset($term['term_id'])) {
				add_term_meta ($term['term_id'], 'wpsc_tf_label', __('Knowledgebase Suggestions','wpsc-prass-kb'));
				add_term_meta ($term['term_id'], 'agentonly', '2');
				add_term_meta ($term['term_id'], 'wpsc_tf_type', '0');
				add_term_meta ($term['term_id'], 'wpsc_allow_ticket_list', '0');
				add_term_meta ($term['term_id'], 'wpsc_allow_ticket_filter', '0');
			}	
		}
		
		if($installed_version < '2.0.3'){
			$term = wp_insert_term( 'betterdocs_knowledgebase', 'wpsc_ticket_custom_fields' );
			if ( !is_wp_error($term) && isset($term['term_id'])) {
				add_term_meta ($term['term_id'], 'wpsc_tf_label', __('Knowledgebase Suggestions','wpsc-prass-kb'));
				add_term_meta ($term['term_id'], 'agentonly', '2');
				add_term_meta ($term['term_id'], 'wpsc_tf_type', '0');
				add_term_meta ($term['term_id'], 'wpsc_allow_ticket_list', '0');
				add_term_meta ($term['term_id'], 'wpsc_allow_ticket_filter', '0');
			}
		}
		
        update_option( 'wpsc_prasskb_current_version', WPSC_PRASS_KB_VERSION );
        
    }
    
  }
  
endif;

new WPSC_PRASSKB_Install();