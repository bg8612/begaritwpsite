<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $current_user;
$select_knowledgbase = get_option('wpsc_select_knowledgbase_set','');
if(!$current_user->ID || !$current_user->has_cap('wpsc_agent') || !class_exists('BetterDocs')) return;
if($select_knowledgbase=='WPSC_BetterDocs'){
?>
<span onclick="wpsc_get_betterdocs_knowledgbase();" ><?php _e('Knowledgebase','wpsc-prass-kb')?></span>
<?php } ?>
<script>
  function wpsc_get_betterdocs_knowledgbase(){
    wpsc_modal_open('<?php _e('Knowledgebase','wpsc-prass-kb')?>');
    var data = {
      action: 'wpsc_get_betterdocs_knowledgbase'  
    };
    jQuery.post(wpsc_admin.ajax_url, data, function(response_str) {
      var response = JSON.parse(response_str);
      jQuery('#wpsc_popup_body').html(response.body);
      jQuery('#wpsc_popup_footer').html(response.footer);
      jQuery('#wpsc_cat_name').focus();
    });
  }
</script>