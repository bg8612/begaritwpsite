<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
$select_knowledgbase = get_option('wpsc_select_knowledgbase_set','');
?>
<h4>
	<?php _e('Select Integration','supportcandy');?>	
</h4><br />
<form id="wpsc_frm_knowledgbase_settings" method="post" action="javascript:wpsc_set_kb_settings();">
	
	<div class="row">
		<div class="col-sm-6" style="margin-bottom:10px; display:flex;">
			<div style="width:25px;">
				<input type="radio" class="wpsp_knowledgbase_addon_name" name="wpsp_knowledgbase_addon_name" value="WPSC_PrassApp_Knowledgbase" <?php echo ($select_knowledgbase=='WPSC_PrassApp_Knowledgbase')?'checked="checked"':''; ?> >
			</div>
			<div style="padding-top:3px;">
				 <?php _e('PressApp Knowledgbase (<a href="https://codecanyon.net/item/knowledge-base-helpdesk-wiki-wordpress-plugin/5758910" target="_blank">Plugin Url</a>)','wpsc-prass-kb');?>
			</div>
		</div>
		<div class="col-sm-6" style="margin-bottom:10px;display:flex; width: unset;">
			<?php if($select_knowledgbase=='WPSC_PrassApp_Knowledgbase' && !class_exists('Pressapps_Knowledge_Base')){?><div class="wpsc_kb_notice"> (<?php _e('Please Install Pressapps KnowledgeBase Plugin.','wpsc-prass-kb');  ?>)</div><?php } ?>
		</div>
	</div>
	
	<div class="row">
		<div class="col-sm-6" style="margin-bottom:10px; display:flex; width: unset">
			<div style="width:25px;">
				<input type="radio" class="wpsp_knowledgbase_addon_name" name="wpsp_knowledgbase_addon_name" value="WPSC_WP_Knowledgbase" <?php echo ($select_knowledgbase=='WPSC_WP_Knowledgbase')?'checked="checked"':''; ?> >      		
			</div>
			<div style="padding-top:3px;">
				<?php _e('WP Knowledgbase (<a href="https://wordpress.org/plugins/wp-knowledgebase/" target="_blank">Plugin Url</a>)','wpsc-prass-kb');?>
			</div>
		</div>
		<div class="col-sm-6" style="margin-bottom:10px;display:flex; width: unset;">
			<?php if($select_knowledgbase=='WPSC_WP_Knowledgbase' && !function_exists('kbe_styles')){?><div class="wpsc_kb_notice"> (<?php _e('Please Install WP KnowledgeBase Plugin.','wpsc-prass-kb');  ?>)</div><?php } ?>
		</div>
	</div>
	
	<div class="row">
		<div class="col-sm-6" style="margin-bottom:10px;display:flex; width: unset;">
			<div style="width:25px;">
				<input type="radio" class="wpsp_knowledgbase_addon_name" name="wpsp_knowledgbase_addon_name" value="WPSC_HelpGuru_Knowledgbase" <?php echo ($select_knowledgbase=='WPSC_HelpGuru_Knowledgbase')?'checked="checked"':''; ?> >      		
			</div>
			<div style="margin-top: 3px;">
				<?php _e('Helpguru Knowledgebase - HeroThemes (<a href="https://herothemes.com" target="_blank">Plugin Url</a>)','wpsc-prass-kb');?>
			</div>
		</div>
		<div class="col-sm-6" style="margin-bottom:10px;display:flex; width: unset;">
			<?php if($select_knowledgbase=='WPSC_HelpGuru_Knowledgbase' && !class_exists('HT_Knowledge_Base')){?><div class="wpsc_kb_notice"> (<?php _e('Please Install HelpGuru KnowledgeBase Plugin.','wpsc-prass-kb');  ?>)</div><?php } ?>
		</div>
	</div>
	
	<div class="row">
		<div class="col-sm-6" style="margin-bottom:10px;display:flex; width: unset;">
			<div style="width:25px;">
				<input type="radio" class="wpsp_knowledgbase_addon_name" name="wpsp_knowledgbase_addon_name" value="WPSC_BasePress_Knowledgbase" <?php echo ($select_knowledgbase=='WPSC_BasePress_Knowledgbase')?'checked="checked"':''; ?> >      		
			</div>
			<div style="margin-top:3px;">
				<?php _e('BasePress Knowledgebase (<a href="https://wordpress.org/plugins/basepress/" target="_blank">Plugin Url</a>)','wpsc-prass-kb');?>
			</div>
		</div>
		<div class="col-sm-6" style="margin-bottom:10px;display:flex; width: unset;">
			<?php if($select_knowledgbase=='WPSC_BasePress_Knowledgbase' && !function_exists('base_fs')){?><div class="wpsc_kb_notice"> (<?php _e('Please Install BasePress KnowledgeBase Plugin.','wpsc-prass-kb');  ?>)</div><?php } ?>
		</div>
	</div>
	
	<div class="row">
		<div class="col-sm-6" style="margin-bottom:10px;display:flex; width: unset;">
			<div style="width:25px;">
				<input type="radio" class="wpsp_knowledgbase_addon_name" name="wpsp_knowledgbase_addon_name" value="WPSC_BWL_Knowledgbase" <?php echo ($select_knowledgbase=='WPSC_BWL_Knowledgbase')?'checked="checked"':''; ?> >      		
			</div>
			<div style="margin-top: 3px;">
				<?php _e('BWL Knowledgebase Manager (<a href="https://codecanyon.net/item/bwl-knowledge-base-manager/7972812" target="_blank">Plugin Url</a>)','wpsc-prass-kb');?>
			</div>
		</div>
		<div class="col-sm-6" style="margin-bottom:10px;display:flex; width: unset;">
			<?php if($select_knowledgbase=='WPSC_BWL_Knowledgbase' && !class_exists('BWL_KB_Manager')){?><div class="wpsc_kb_notice"> (<?php _e('Please Install BWL KnowledgeBase Plugin.','wpsc-prass-kb');  ?>)</div><?php } ?>
		</div>
	</div> 
	
	<div class="row">
		<div class="col-sm-6" style="margin-bottom:10px;display:flex; width: unset;">
			<div style="width:25px;">
				<input type="radio" class="wpsc_echo_knowledgbase_addon_name" name="wpsp_knowledgbase_addon_name" value="WPSC_Echo_Knowledgbase" <?php echo ($select_knowledgbase=='WPSC_Echo_Knowledgbase')?'checked="checked"':''; ?> >      		
			</div>
			<div style="margin-top: 3px;">
				<?php _e('Echo Knowledgebase (<a href="https://wordpress.org/plugins/echo-knowledge-base/" target="_blank">Plugin Url</a>)','wpsc-prass-kb');?>
			</div>
		</div>
		<div class="col-sm-6" style="margin-bottom:10px;display:flex; width: unset;">
			<?php if($select_knowledgbase=='WPSC_Echo_Knowledgbase' && ! class_exists( 'Echo_Knowledge_Base' )){?><div class="wpsc_kb_notice"> (<?php _e('Please Install Echo KnowledgeBase Plugin.','wpsc-prass-kb');  ?>)</div><?php } ?>
		</div>
	</div>

	<div class="row">
		<div class="col-sm-6" style="margin-bottom:10px;display:flex; width: unset;">
			<div style="width:25px;">
				<input type="radio" class="wpsc_knowledgbase_addon_name" name="wpsp_knowledgbase_addon_name" value="WPSC_Knowledgebase_Helpdesk" <?php echo ($select_knowledgbase=='WPSC_Knowledgebase_Helpdesk')?'checked="checked"':''; ?> >      		
			</div>
			<div style="margin-top: 3px;">
				<?php _e('KnowledgeBase X w/ FAQ, Glossary Powered by WPBot ChatBot/HelpDesk (<a href="https://www.quantumcloud.com/products/knowledgebase-helpdesk/" target="_blank">Plugin Url</a>)','wpsc-prass-kb');?>
			</div>
		</div>
		<div class="col-sm-6" style="margin-bottom:10px;display:flex; width: unset;">
			<?php if($select_knowledgbase=='WPSC_Knowledgebase_Helpdesk' && ! class_exists( 'KBX_TAXONOMY_META' )){?><div class="wpsc_kb_notice"> (<?php _e('Please Install KnowledgeBase Helpdesk Plugin.','wpsc-prass-kb');  ?>)</div><?php } ?>
		</div>
	</div>
	
	<div class="row">
		<div class="col-sm-6" style="margin-bottom:10px;display:flex; width: unset;">
			<div style="width:25px;">
				<input type="radio" class="wpsc_knowledgbase_addon_name" name="wpsp_knowledgbase_addon_name" value="WPSC_BetterDocs" <?php echo ($select_knowledgbase=='WPSC_BetterDocs')?'checked="checked"':''; ?> >      		
			</div>
			<div style="margin-top: 3px;">
				<?php _e('BetterDocs – Best Documentation & Knowledge Base Plugin (<a href="https://wordpress.org/plugins/betterdocs/" target="_blank">Plugin Url</a>)','wpsc-prass-kb');?>
			</div>
		</div>
		<div class="col-sm-6" style="margin-bottom:10px;display:flex; width: unset;">
			<?php if($select_knowledgbase=='WPSC_BetterDocs' && ! class_exists( 'BetterDocs' )){?><div class="wpsc_kb_notice"> (<?php _e('Please Install KnowledgeBase Helpdesk Plugin.','wpsc-prass-kb');  ?>)</div><?php } ?>
		</div>
	</div><br>

  <button type="submit" class="btn btn-success" id="wpsc_prass_kb_save_btn"><?php _e('Save Changes','wpsc-prass-kb');?></button>
  <img class="wpsc_submit_wait" style="display:none;" src="<?php echo WPSC_PLUGIN_URL.'asset/images/ajax-loader@2x.gif';?>">
  <input type="hidden" name="action" value="wpsc_set_kb_settings" />
  
</form>
<script>
function wpsc_set_kb_settings(){
  var dataform = new FormData(jQuery('#wpsc_frm_knowledgbase_settings')[0]);
  dataform.append('action', 'wpsc_set_kb_settings');
  jQuery('.wpsc_reply_widget').html(wpsc_admin.loading_html);
  jQuery.ajax({
    url: wpsc_admin.ajax_url,
    type: 'POST',
    data: dataform,
    processData: false,
    contentType: false
  })
  .done(function (response_str) {
    var response = JSON.parse(response_str);
     if (response.sucess_status=='1') {
       jQuery('#wpsc_alert_success .wpsc_alert_text').text(response.messege);
       jQuery('#wpsc_alert_success').slideDown('fast',function(){});
       setTimeout(function(){ jQuery('#wpsc_alert_success').slideUp('fast',function(){}); }, 3000);       
     } else {
       jQuery('#wpsc_alert_error .wpsc_alert_text').text(response.messege);
       jQuery('#wpsc_alert_error').slideDown('fast',function(){});
       setTimeout(function(){ jQuery('#wpsc_alert_error').slideUp('fast',function(){}); }, 3000);
     }
		 wpsc_get_kb_settings();
  }); 
}
</script>
<style>
	.wpsc_kb_notice{
		color: #b72929;
		margin-top: 3px;
	}
</style>