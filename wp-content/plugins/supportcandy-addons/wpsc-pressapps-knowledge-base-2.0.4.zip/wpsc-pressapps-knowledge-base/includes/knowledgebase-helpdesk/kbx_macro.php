<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $current_user;
$select_knowledgbase = get_option('wpsc_select_knowledgbase_set','');
if(!$current_user->ID || !$current_user->has_cap('wpsc_agent') || !class_exists('KBX_TAXONOMY_META')) return;
if($select_knowledgbase=='WPSC_Knowledgebase_Helpdesk'){
?>
<span onclick="wpsc_get_knowledgebase_helpdesk()" ><?php _e('Knowledgebase','wpsc-prass-kb')?></span>
<?php } ?>

<script>
  function wpsc_get_knowledgebase_helpdesk(){
		wpsc_modal_open('<?php _e('Knowledgebase Helpdesk','wpsc-prass-kb')?>');
    var data = {
      action: 'wpsc_get_knowledgebase_helpdesk'  
    };
    jQuery.post(wpsc_admin.ajax_url, data, function(response_str) {
      var response = JSON.parse(response_str);
      jQuery('#wpsc_popup_body').html(response.body);
      jQuery('#wpsc_popup_footer').html(response.footer);
      jQuery('#wpsc_cat_name').focus();
    });
	}
</script>