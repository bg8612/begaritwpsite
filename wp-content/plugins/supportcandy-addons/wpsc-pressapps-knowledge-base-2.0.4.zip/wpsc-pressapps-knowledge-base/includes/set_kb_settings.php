<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $current_user;
if (!($current_user->ID && $current_user->has_cap('manage_options'))) {
	exit;
}
$knowledgbase_addon_name  = isset($_POST) && isset($_POST['wpsp_knowledgbase_addon_name']) ? sanitize_text_field($_POST['wpsp_knowledgbase_addon_name']) : '';
if (!$knowledgbase_addon_name) {exit;}
update_option('wpsc_select_knowledgbase_set',$knowledgbase_addon_name);

echo '{ "sucess_status":"1","messege":"'.__('Settings saved.','wpsc-prass-kb').'" }';
?>