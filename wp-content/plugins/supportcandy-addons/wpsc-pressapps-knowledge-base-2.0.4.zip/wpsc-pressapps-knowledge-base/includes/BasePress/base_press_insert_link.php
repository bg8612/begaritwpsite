<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $current_user;

$post_id = isset($_POST['post_id']) ? intval($_POST['post_id']) : 0;

if(!$post_id || !$current_user->ID || !$current_user->has_cap('wpsc_agent') || !function_exists('base_fs')) exit;

$knowledgebase = get_post($post_id);

$response = '<a href="'.get_permalink($post_id).'" target="_blank">'.$knowledgebase->post_title.'</a>';
echo $response;
