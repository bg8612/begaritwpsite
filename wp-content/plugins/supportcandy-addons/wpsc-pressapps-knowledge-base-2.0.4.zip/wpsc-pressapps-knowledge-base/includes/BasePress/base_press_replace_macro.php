<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
global  $wpscfunction;
$ticket_subject = $wpscfunction->get_ticket_fields($ticket_id,'ticket_subject');
$ticket_subject = explode(' ',$ticket_subject);

$args = array(
	'post_type'      => 'knowledgebase',
	'post_status'    => 'publish',
	'posts_per_page' => 3,
  'tax_query'   => array( 
    array(
      'taxonomy' => 'knowledgebase_cat',
      'field'    => 'name',
      'terms'    => $ticket_subject,
      'operator' => 'IN',
    )
  ),
);
$posts = get_posts($args);

$count = 0;
$replace_data = '<ul>';
foreach($posts as $base_press_kbase){
  $count ++;
  $replace_data .= '<li><a href="'.get_permalink($base_press_kbase->ID).'" target="_blank">'.$base_press_kbase->post_title.'</a></li>';
}
$replace_data .= '</ul>';

if(!$count){
  $replace_data .= __('No Knowledgebase suggestions found','wpsc-prass-kb');
}

$str = preg_replace('/{basepress_kb_suggestions}/', $replace_data, $str);

