<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $current_user;

$post_id = isset($_POST['post_id']) ? intval($_POST['post_id']) : 0;

if(!$post_id || !$current_user->ID || !$current_user->has_cap('wpsc_agent') || !class_exists('Pressapps_Knowledge_Base')) exit;

$knowledgebase = get_post($post_id);
echo wpautop($knowledgebase->post_content);
