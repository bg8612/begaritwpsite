<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if ( ! class_exists( 'WPSC_PRASSKB' ) ) :

  final class WPSC_PRASSKB {

		function kb_setting_pill(){
			include WPSC_PRASS_KB_ABSPATH . 'includes/kb_setting_pill.php';
		}

		function get_kb_settings(){
			include WPSC_PRASS_KB_ABSPATH . 'includes/get_kb_settings.php';
			die();
		}

		function set_kb_settings(){
			include WPSC_PRASS_KB_ABSPATH . 'includes/set_kb_settings.php';
			die();
		}

		//pressapp file add
    function knowledgebase_macro(){
			include WPSC_PRASS_KB_ABSPATH . 'includes/knowledgebase_macro.php';
		}

    function get_prass_knowledgbase(){
			include WPSC_PRASS_KB_ABSPATH . 'includes/get_prass_knowledgbase.php';
			die();
		}

    function insert_link(){
			include WPSC_PRASS_KB_ABSPATH . 'includes/insert_link.php';
			die();
		}

		function insert_text(){
			include WPSC_PRASS_KB_ABSPATH . 'includes/insert_text.php';
			die();
		}

    function replace_macro($str,$ticket_id){
			include WPSC_PRASS_KB_ABSPATH . 'includes/replace_macro.php';
			return $str;
		}

		//WP KNOW file added

		function wp_knowledgebase_macro(){
			include WPSC_PRASS_KB_ABSPATH . 'includes/wp-knowledgebase/knowledgebase_macro.php';
		}

    function get_wp_knowledgbase(){
			include WPSC_PRASS_KB_ABSPATH . 'includes/wp-knowledgebase/get_wp_knowledgbase.php';
			die();
		}

    function wp_insert_link(){
			include WPSC_PRASS_KB_ABSPATH . 'includes/wp-knowledgebase/insert_link.php';
			die();
		}

		function wp_insert_text(){
			include WPSC_PRASS_KB_ABSPATH . 'includes/wp-knowledgebase/insert_text.php';
			die();
		}

    function wp_replace_macro($str,$ticket_id){
			include WPSC_PRASS_KB_ABSPATH . 'includes/wp-knowledgebase/replace_macro.php';
			return $str;
		}

		// Add-on installed or not for licensing
		function is_add_on_installed($flag){
			return true;
		}

		// Print license functionlity for this add-on
		function addon_license_area(){
			include WPSC_PRASS_KB_ABSPATH . 'includes/addon_license_area.php';
		}

		// Activate Knowledgebase license
		function license_activate(){
			include WPSC_PRASS_KB_ABSPATH . 'includes/license_activate.php';
			die();
		}

		// Deactivate Knowledgebase license
		function license_deactivate(){
			include WPSC_PRASS_KB_ABSPATH . 'includes/license_deactivate.php';
			die();
		}

		function base_press_knowledgebase_macro(){
			include WPSC_PRASS_KB_ABSPATH . 'includes/BasePress/base_press_knowledgebase_macro.php';
		}

		function get_base_press_knowledgebase(){
			include WPSC_PRASS_KB_ABSPATH . 'includes/BasePress/get_base_press_knowledgebase.php';
			die();
		}

		function base_press_replace_macro($str,$ticket_id){
			include WPSC_PRASS_KB_ABSPATH . 'includes/BasePress/base_press_replace_macro.php';
			return $str;
		}

		function base_press_insert_link(){
			include WPSC_PRASS_KB_ABSPATH . 'includes/BasePress/base_press_insert_link.php';
			die();
		}

		function base_press_insert_text(){
			include WPSC_PRASS_KB_ABSPATH . 'includes/BasePress/base_press_insert_text.php';
			die();
		}

		function hg_knowledgebase_macro(){
			include WPSC_PRASS_KB_ABSPATH . 'includes/ht-knowledge-base/hg_knowledgbase_macro.php';
		}

    function get_hg_knowledgbase(){
			include WPSC_PRASS_KB_ABSPATH . 'includes/ht-knowledge-base/get_hg_knowledgbase.php';
			die();
		}

    function hg_insert_link(){
			include WPSC_PRASS_KB_ABSPATH . 'includes/ht-knowledge-base/hg_insert_link.php';
			die();
		}

		function hg_insert_text(){
			include WPSC_PRASS_KB_ABSPATH . 'includes/ht-knowledge-base/hg_insert_text.php';
			die();
		}

    function hg_replace_macro($str,$ticket_id){
			include WPSC_PRASS_KB_ABSPATH . 'includes/ht-knowledge-base/hg_replace_macro.php';
			return $str;
		}

		function bwl_knowledgebase_macro(){
			include WPSC_PRASS_KB_ABSPATH . 'includes/Bwl-knowledgebase/bwl_knowledgbase_macro.php';
		}

    function get_bwl_knowledgbase(){
			include WPSC_PRASS_KB_ABSPATH . 'includes/Bwl-knowledgebase/get_bwl_knowledgbase.php';
			die();
		}

    function bwl_insert_link(){
			include WPSC_PRASS_KB_ABSPATH . 'includes/Bwl-knowledgebase/bwl_insert_link.php';
			die();
		}

		function bwl_insert_text(){
			include WPSC_PRASS_KB_ABSPATH . 'includes/Bwl-knowledgebase/bwl_insert_text.php';
			die();
		}

    function bwl_replace_macro($str,$ticket_id){
			include WPSC_PRASS_KB_ABSPATH . 'includes/Bwl-knowledgebase/bwl_replace_macro.php';
			return $str;
		}

		function echo_knowledgebase_macro(){	
			include WPSC_PRASS_KB_ABSPATH . 'includes/echo-knowledgebase/echo_knowledgebase_macro.php';
		}

    function get_echo_knowledgbase(){
			include WPSC_PRASS_KB_ABSPATH . 'includes/echo-knowledgebase/get_echo_knowledgbase.php';
			die();
		}

    function echo_insert_link(){
			include WPSC_PRASS_KB_ABSPATH . 'includes/echo-knowledgebase/echo_insert_link.php';
			die();
		}

		function echo_insert_text(){
			include WPSC_PRASS_KB_ABSPATH . 'includes/echo-knowledgebase/echo_insert_text.php';
			die();
		}

    function echo_replace_macro($str,$ticket_id){
			include WPSC_PRASS_KB_ABSPATH . 'includes/echo-knowledgebase/echo_replace_macro.php';
			return $str;
		}
	
	
	function kbx_macro(){
		include WPSC_PRASS_KB_ABSPATH . 'includes/knowledgebase-helpdesk/kbx_macro.php';
	}
	
	function get_knowledgebase_helpdesk(){
		include WPSC_PRASS_KB_ABSPATH . 'includes/knowledgebase-helpdesk/get_knowlegdebase_helpdesk.php';
		die();
	}
	
	function kbx_insert_link(){
		include WPSC_PRASS_KB_ABSPATH . 'includes/knowledgebase-helpdesk/kbx_insert_link.php';
		die();
	}
	
	function kbx_insert_text(){
		include WPSC_PRASS_KB_ABSPATH . 'includes/knowledgebase-helpdesk/kbx_insert_text.php';
		die();
	}

	function kbx_replace_macro($str,$ticket_id){
		include WPSC_PRASS_KB_ABSPATH . 'includes/knowledgebase-helpdesk/kbx_replace_macro.php';
		return $str;
	}

	function betterdocs_knowledgbase_macro(){
		include WPSC_PRASS_KB_ABSPATH . 'includes/BetterDocs/betterdocs_knowledgbase_macro.php';
	}
	
	function get_betterdocs_knowledgbase(){
		include WPSC_PRASS_KB_ABSPATH . 'includes/BetterDocs/get_betterdocs_knowledgbase.php';
		die();
	}
	
	function betterdocs_insert_link(){
		include WPSC_PRASS_KB_ABSPATH . 'includes/BetterDocs/betterdocs_insert_link.php';
		die();
	}
	
	function betterdocs_insert_text(){
		include WPSC_PRASS_KB_ABSPATH . 'includes/BetterDocs/betterdocs_insert_text.php';
		die();
	}

	function betterdocs_replace_macro($str,$ticket_id){
		include WPSC_PRASS_KB_ABSPATH . 'includes/BetterDocs/betterdocs_replace_macro.php';
		return $str;
	}
  }
endif;
