<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $wpdb;

$value =array(
	'post_id' => $ticket_id,
);
$wpdb->update($wpdb->prefix.'wpsc_timer', $value, array('post_id'=>$post_id));