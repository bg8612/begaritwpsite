<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $wpdb,$current_user,$wpscfunction;

$wpsc_timer_enable = get_option('wpsc_timer_enable');

if($wpsc_timer_enable){
	$start_time	=	date("Y-m-d H:i:s");

	$values=array(
	            'post_id'=>	$ticket_id,
	            'start_time'=> $start_time,
	            'timer_status'=>	1
	        );
	$wpdb->insert($wpdb->prefix.'wpsc_timer',$values);
}