<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $current_user;
if (!($current_user->ID && $current_user->has_cap('manage_options'))) {
	exit;
}

// Allow ticket url Permissions
$wpsc_timer_enable = isset($_POST) && isset($_POST['wpsc_timer_enable']) ? sanitize_text_field($_POST['wpsc_timer_enable']) : '0';
update_option('wpsc_timer_enable',$wpsc_timer_enable);

$wpsc_timer_stop = isset($_POST) && isset($_POST['wpsc_timer_stop']) ? sanitize_text_field($_POST['wpsc_timer_stop']) : '0';
update_option('wpsc_timer_stop',$wpsc_timer_stop);

$wpsc_timer_visibility_for_customer = isset($_POST) && isset($_POST['wpsc_timer_visibility']) ? sanitize_text_field($_POST['wpsc_timer_visibility']) : '0';
update_option('wpsc_timer_visibility_for_customer',$wpsc_timer_visibility_for_customer);

$wpsc_active_timer_color = isset($_POST) && isset($_POST['wpsc_active_timer_color']) ? sanitize_text_field($_POST['wpsc_active_timer_color']) : '';
update_option('wpsc_active_timer_color',$wpsc_active_timer_color);

echo '{ "sucess_status":"1","messege":"'.__('Settings saved.','supportcandy').'" }';
