<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $current_user;
if (!($current_user->ID && $current_user->has_cap('manage_options'))) {exit;}

?>
<div class="form-group row" style="margin-bottom:30px;">
  <div class="col-sm-4">
    <label><?php _e('Timer unassigned','wpsc-timer');?></label>
    <p class="help-block"><?php _e('Timer unassigned ticket capability.','wpsc-timer');?></p>
    <select class="form-control" name="agentrole[view_unassigned_timer]">
      <option <?php echo $agent_role_item['view_unassigned_timer'] == '0' ? 'selected="selected"' : ''?> value="0"><?php _e('Disable','supportcandy');?></option>
      <option <?php echo $agent_role_item['view_unassigned_timer'] == '1' ? 'selected="selected"' : ''?> value="1"><?php _e('Enable','supportcandy');?></option>
    </select>
  </div>
  
  <div class="col-sm-4">
    <label><?php _e('Timer assigned me','wpsc-timer');?></label>
    <p class="help-block"><?php _e('Ticket assigned to user himself timer capability.','wpsc-timer');?></p>
    <select class="form-control" name="agentrole[view_assigned_me_timer]">
      <option <?php echo $agent_role_item['view_assigned_me_timer'] == '0' ? 'selected="selected"' : ''?> value="0"><?php _e('Disable','supportcandy');?></option>
      <option <?php echo $agent_role_item['view_assigned_me_timer'] == '1' ? 'selected="selected"' : ''?> value="1"><?php _e('Enable','supportcandy');?></option>
    </select>
  </div>
  
  <div class="col-sm-4">
    <label><?php _e('Timer assigned others','wpsc-timer');?></label>
    <p class="help-block"><?php _e('Ticket assigned to all other agents timer capability.','wpsc-timer');?></p>
    <select class="form-control" name="agentrole[view_assigned_others_timer]">
      <option <?php echo $agent_role_item['view_assigned_others_timer'] == '0' ? 'selected="selected"' : ''?> value="0"><?php _e('Disable','supportcandy');?></option>
      <option <?php echo $agent_role_item['view_assigned_others_timer'] == '1' ? 'selected="selected"' : ''?> value="1"><?php _e('Enable','supportcandy');?></option>
    </select>
  </div>
</div> 