<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $wpscfunction, $current_user;

$wpsc_appearance_individual_ticket_page = get_option('wpsc_individual_ticket_page');
$ticket_widget = get_term_by( 'slug', 'timer', 'wpsc_ticket_widget' );
$wpsc_custom_widget_localize = get_option('wpsc_custom_widget_localize');
$ticket_widget_name = $wpsc_custom_widget_localize['custom_widget_'.$ticket_widget->term_id];
$customer_name = $wpscfunction->get_ticket_fields($ticket_id,'customer_name');
$is_active = $wpscfunction->get_ticket_fields($ticket_id,'active');
?>
<div>
	<div class="row" style="background-color:<?php echo $wpsc_appearance_individual_ticket_page['wpsc_ticket_widgets_bg_color']?> !important;color:<?php echo $wpsc_appearance_individual_ticket_page['wpsc_ticket_widgets_text_color']?> !important;border-color:<?php echo $wpsc_appearance_individual_ticket_page['wpsc_ticket_widgets_border_color']?> !important;">
		<h4 class="widget_header"><i class="fa fa-stopwatch" aria-hidden="true" ></i> <?php echo $ticket_widget_name?></h4>	
		<hr class="widget_divider">
		<div class="ticket_timer_sidebar" style="font-size: 20px;font-weight: bold;padding: 3px;">
        <span id="sw_h">00</span> :
        <span id="sw_m">00</span> :
        <span id="sw_s">00</span>
    </div>
    
    <div class="ticket_status_sidebar" style="display: none">
        <span id="sw_status">Idle</span>
    </div>
    <?php 
      if($current_user->has_cap('wpsc_agent') && apply_filters('wpsc_allow_timer_widget_buttons',true)){
     ?>
		    <div style="margin-bottom: 10px;" >
				<hr class="widget_divider">
                <?php if($is_active){?>

		        <input type="button" value="<?php _e('Start Timer', 'wpsc-timer'); ?>" class="btn btn-default btn-sm" id="sw_start" />
		        <input type="button" value="<?php _e('Stop Timer', 'wpsc-timer'); ?>" class="btn btn-default btn-sm"  id="sw_stop" />

                <?php } ?>   
		        <input type="button" value="<?php _e('View Log', 'wpsc-timer'); ?>" class="btn btn-default btn-sm" onclick="wpsc_view_ticket_timer_log(<?php echo $ticket_id ?>)" id="sw_view_log" />
						
						<input type="button" value="<?php _e('All Tickets', 'wpsc-timer'); ?>" style="margin-top:5px;" class="btn btn-default btn-sm" onclick="wpsc_all_ticket_timer_log(<?php echo $ticket_id ?>)" id="sw_all_tickets_view_log" />
		    </div>
     <?php
		  do_action('wpsc_after_timer_view_log',$ticket_id);	
	 		} 
			?>
	</div>
</div>

<script type="text/javascript">
	function wpsc_view_ticket_timer_log(ticket_id){
		wpsc_modal_open('<?php _e('Timer Log','wpsc-timer')?>');
		var data = {
	        action	: 'view_ticket_timer_log',
	        ticket_id : ticket_id,
	    }
			jQuery.post(wpsc_admin.ajax_url, data, function(response_str) {
			 var response = JSON.parse(response_str);
			 jQuery('#wpsc_popup_body').html(response.body);
	     jQuery('#wpsc_popup_footer').html(response.footer);
	   });
	}
	
	function wpsc_all_ticket_timer_log(ticket_id){
		wpsc_modal_open("<?php echo 'Total Time ('.$customer_name.')'?>");
		var data = {
	        action	: 'get_all_tickets_time',
	        ticket_id : ticket_id,
	    }
			jQuery.post(wpsc_admin.ajax_url, data, function(response_str) {
			 var response = JSON.parse(response_str);
			 jQuery('#wpsc_popup_body').html(response.body);
	     jQuery('#wpsc_popup_footer').html(response.footer);
	   });
	}
	
  jQuery(document).ready(function() {
    (function(jQuery){

    jQuery.extend({

        Timer : {

            formatTimer : function(a) {
                if (a < 10) {
                    a = '0' + a;
                }
                return a;
            },

            startTimer : function(dir) {
                jQuery('#sw_start').hide();
                jQuery('#sw_stop').show();

                // save type
                jQuery.Timer.dir = dir;
								
								snd = new Date();
								jQuery.Timer.d1 = new Date(snd.getUTCFullYear(), snd.getUTCMonth(), snd.getUTCDate(), snd.getUTCHours(), snd.getUTCMinutes(), snd.getUTCSeconds(), snd.getUTCMilliseconds());
								//jQuery.Timer.d1 = new Date();
								jQuery.Timer.t1 = jQuery.Timer.d1.getTime();
								
                //log start time
                var data = {
                    'action'	: 'wpsc_start_timer',
                    'ticket_id' : <?php echo $ticket_id; ?>

                };
                jQuery.post(wpsc_admin.ajax_url, data, function(response) {

                });

                // reset state
                jQuery.Timer.state = 'alive';
                jQuery('#' + jQuery.Timer.dir + '_status').html('Running');

                // start loop
                jQuery.Timer.loopTimer();

            },

            stopTimer : function() {

                jQuery('#sw_start').show();
                jQuery('#sw_stop').hide();

                //log end time
                var data = {
                    'action'	: 'wpsc_stop_timer',
                    'ticket_id'	: <?php echo $ticket_id; ?>
                };
                jQuery.post(wpsc_admin.ajax_url, data, function(response) {
										var data = {
												'action': 'wpsc_check_timer_status',
												'ticket_id': <?php echo $ticket_id; ?>
										};
										jQuery.post(wpsc_admin.ajax_url, data, function(response) {

												var data = jQuery.parseJSON(response);

												time_sec = parseInt(data["time_seconds"]);

												jQuery.Timer.time_mili = time_sec*1000;
										});
										
                });

                // set state
                jQuery.Timer.state = 'stop';
                jQuery('#' + jQuery.Timer.dir + '_status').html('Stopped');
                wpsc_get_add_timer_note(<?php echo $ticket_id ?>);

            },

            loopTimer : function() {

                var td;
                var d2,t2;

                var ms = 0;
                var s  = 0;
                var m  = 0;
                var h  = 0;

                if (jQuery.Timer.state === 'alive') {

                    // get current date and convert it into
                    // timestamp for calculations
                    //d2 = new Date();
										nd = new Date();
										d2 = new Date(nd.getUTCFullYear(), nd.getUTCMonth(), nd.getUTCDate(), nd.getUTCHours(), nd.getUTCMinutes(), nd.getUTCSeconds(), nd.getUTCMilliseconds());
										t2 = d2.getTime();
                    // calculate time difference between
                    // initial and current timestamp

                    td = t2 - jQuery.Timer.t1; //return milliseconds
										
                    //add previous minitus
                     td = td+jQuery.Timer.time_mili;

                    // calculate milliseconds
                    ms = td%1000;
                    if (ms < 1) {
                        ms = 0;
                    } else {
                        // calculate seconds
                        s = (td-ms)/1000;
                        if (s < 1) {
                            s = 0;
                        } else {
                            // calculate minutes
                            var m = (s-(s%60))/60;
                            if (m < 1) {
                                m = 0;
                            } else {
                                // calculate hours
                                var h = (m-(m%60))/60;
                                if (h < 1) {
                                    h = 0;
                                }
                            }
                        }
                    }

                    // substract elapsed minutes & hours
                    ms = Math.round(ms/100);
                    s  = s-(m*60);
                    m  = m-(h*60);

                    // update display
                    jQuery('#' + jQuery.Timer.dir + '_ms').html(jQuery.Timer.formatTimer(ms));
                    jQuery('#' + jQuery.Timer.dir + '_s').html(jQuery.Timer.formatTimer(s));
                    jQuery('#' + jQuery.Timer.dir + '_m').html(jQuery.Timer.formatTimer(m));
                    jQuery('#' + jQuery.Timer.dir + '_h').html(jQuery.Timer.formatTimer(h));

                    // loop
                    jQuery.Timer.t = setTimeout(jQuery.Timer.loopTimer,1);

                } else {

                    // kill loop
                    clearTimeout(jQuery.Timer.t);
                    return true;

                }

            },

            checkTimerStatus: function(){

                //check timer status
                var data = {
                    'action' : 'wpsc_check_timer_status',
                    'ticket_id': <?php echo $ticket_id; ?>
                };
                jQuery.post(wpsc_admin.ajax_url, data, function(response) {

                    var data=jQuery.parseJSON(response);

                    time_sec=parseInt(data["time_seconds"]);

                    jQuery.Timer.time_mili=time_sec*1000;

                    jQuery.Timer.dir='sw';

                    if(data["ticket_status"]=="1"){

                        //ticket time is running
                        jQuery.Timer.d1 = new Date(data["ticket_start"]);

                        jQuery.Timer.t1 = jQuery.Timer.d1.getTime();

                        jQuery.Timer.state = 'alive';

                        jQuery('#sw_start').hide();
                        jQuery('#sw_stop').show();

                        jQuery.Timer.loopTimer();

                    }else{

                        jQuery('#sw_start').show();
                        jQuery('#sw_stop').hide();

                        jQuery.Timer.preTimeDisplay(time_sec,'sw');

                        // jQuery.Timer.d1 = new Date();
                         //jQuery.Timer.t1 = jQuery.Timer.d1.getTime();
                    }
                });

            },

            preTimeDisplay:function (td,dir){
                var ms = 0;
                var s  = 0;
                var m  = 0;
                var h  = 0;


                // calculate seconds
                s = td;
                if (s < 1) {
                    s = 0;
                } else {
                    // calculate minutes
                    var m = (s-(s%60))/60;
                    if (m < 1) {
                        m = 0;
                    } else {
                        // calculate hours
                        var h = (m-(m%60))/60;
                        if (h < 1) {
                            h = 0;
                        }
                    }
                }


                // substract elapsed minutes & hours
                ms = Math.round(ms/100);
                s  = s-(m*60);
                m  = m-(h*60);

                // update display
                jQuery('#' + jQuery.Timer.dir + '_ms').html(jQuery.Timer.formatTimer(ms));
                jQuery('#' + jQuery.Timer.dir + '_s').html(jQuery.Timer.formatTimer(s));
                jQuery('#' + jQuery.Timer.dir + '_m').html(jQuery.Timer.formatTimer(m));
                jQuery('#' + jQuery.Timer.dir + '_h').html(jQuery.Timer.formatTimer(h));
            }

        }

    });

	    jQuery.Timer.checkTimerStatus();

	    jQuery('#sw_start').on('click', function() {
	        jQuery.Timer.startTimer('sw');
	    });

	    jQuery('#sw_stop').on('click', function() {
	        jQuery.Timer.stopTimer();
	    });

    })(jQuery);
  });

  function wpsc_get_add_timer_note(ticket_id){
    wpsc_modal_open('<?php _e('Add Note','wpsc-timer')?>');
		var data = {
	        action	: 'get_add_timer_note',
	        ticket_id : ticket_id,
	    }
        jQuery.post(wpsc_admin.ajax_url, data, function(response_str) {
        var response = JSON.parse(response_str);
        jQuery('#wpsc_popup_body').html(response.body);
	    jQuery('#wpsc_popup_footer').html(response.footer);
	   });
  }

  function wpsc_set_add_timer_note(ticket_id){
    var dataform = new FormData(jQuery('#frn_add_timer_note')[0]);
    wpsc_modal_close();
    jQuery('.wpsc_reply_widget').html(wpsc_admin.loading_html);
    jQuery.ajax({
        url: wpsc_admin.ajax_url,
        type: 'POST',
        data: dataform,
        processData: false,
        contentType: false
    })
    .done(function (response_str) {
      wpsc_open_ticket(ticket_id);
    });
  }
</script>