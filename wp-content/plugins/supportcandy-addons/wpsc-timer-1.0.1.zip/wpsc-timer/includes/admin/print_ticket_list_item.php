<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
global $wpdb, $wpsctimer, $wpscfunction;

$time_total_seconds = 0;
$flag = false;
if ($field->list_item->slug == 'timer') {
  $timer	=	$wpdb->get_results("SELECT * FROM {$wpdb->prefix}wpsc_timer WHERE post_id='".$field->ticket['id']."'");
  if(!empty($timer)){
    	foreach ($timer as $trow){
        if($trow->timer_status){
            $flag = true;
        }
        $time_total_seconds = $time_total_seconds + ((int)$trow->time_spend);
      }    
  }else{
      //no timer entry for this ticket
      $time_total_seconds = 0;
  }
  
  
	$timer_status	=	$wpdb->get_results("SELECT timer_status FROM {$wpdb->prefix}wpsc_timer WHERE post_id='".$field->ticket['id']."'");
	$time = array();
	$timer_status = json_decode(json_encode($timer_status), true);
	foreach ($timer_status as $key => $timer_status_value) {
		foreach ($timer_status_value as $key => $value) {
			$time['timer_status']  = $value;
		}
		
	}
	
	foreach ($time as $key => $value) {
		if($value == 1){
			$timer_start	=	$wpdb->get_row("SELECT start_time FROM {$wpdb->prefix}wpsc_timer WHERE post_id=".$field->ticket['id']." AND timer_status=1");
			$sttime				= strtotime($timer_start->start_time);
			$now 					= strtotime(date('Y-m-d H:i:s'));
			$diff					= $now - $sttime;
			$diff = $time_total_seconds + $diff;
			?>
				<div style="color:<?php echo get_option('wpsc_active_timer_color'); ?>"><?php echo $wpsctimer->sec_to_min_hrs($diff);?></div>     
			<?php 
		}else if($value == 0){
			if($time_total_seconds){
		    echo $wpsctimer->sec_to_min_hrs($time_total_seconds);     
		  }else if($time_total_seconds==0){
		    echo '00:00:00';
		  }
		}
	}	
}
