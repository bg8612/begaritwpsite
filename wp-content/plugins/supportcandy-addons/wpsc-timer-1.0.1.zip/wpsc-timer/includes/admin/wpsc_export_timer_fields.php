<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
global $wpdb, $wpsctimer;
if($value == 'timer'){
	$time_total_seconds = 0;
	$flag = false;
	$timer	=	$wpdb->get_results("SELECT * FROM {$wpdb->prefix}wpsc_timer WHERE post_id='".$ticket_id."'");
	
	if(!empty($timer)){
	    foreach ($timer as $trow){
	      if($trow->timer_status){
	          $flag = true;
	      }
	      $time_total_seconds = $time_total_seconds + ((int)$trow->time_spend);
	    }    
	}else{
	    //no timer entry for this ticket
	    $time_total_seconds = 0;
	}

	if($time_total_seconds){
		$export_colomn_value[] = $wpsctimer->sec_to_min_hrs($time_total_seconds);
	
	}else if($time_total_seconds == 0){
		$export_colomn_value[]= '00:00:00';		
	}
}
	