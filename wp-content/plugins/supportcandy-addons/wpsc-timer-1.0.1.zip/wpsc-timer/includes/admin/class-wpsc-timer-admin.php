<?php
if ( ! defined( 'ABSPATH' ) ) {
  exit; // Exit if accessed directly
}

if ( ! class_exists( 'WPSC_TR_Admin' ) ) :
  
  
  final class WPSC_TR_Admin {

    function wpsc_timer_sidebar_module($ticket_id,$ticket_widget, $ticket_widgets){
      global $current_user,$wpscfunction;
      
  	  $role_id                 = get_user_option('wpsc_agent_role');
  		$wpsc_ticket_widget_type = get_term_meta( $ticket_widget->term_id, 'wpsc_ticket_widget_type', true);
  		$wpsc_ticket_widget_role = get_term_meta( $ticket_widget->term_id, 'wpsc_ticket_widget_role', true);
      $wpsc_timer_visibility_for_customer =  get_option('wpsc_timer_visibility_for_customer');
			if( $ticket_widget->slug == "timer" ){
        if($wpsc_ticket_widget_type && (in_array($role_id,$wpsc_ticket_widget_role) || !$current_user->has_cap('wpsc_agent') && in_array('customer',$wpsc_ticket_widget_role))){
          if((!$current_user->has_cap('wpsc_agent') && $wpsc_timer_visibility_for_customer ) || $current_user->has_cap('wpsc_agent') && $wpscfunction->has_permission('view_timer', $ticket_id)){
            include_once( WPSC_TR_ABSPATH . 'includes/admin/html/wpsc_timer_sidebar_module.php'); 
          }
        }
      }
    }
   
    // Add-on installed or not for licensing
    function is_add_on_installed($flag){
      return true;
    }
  
    // Print license functionlity for this add-on
    function addon_license_area(){
      include WPSC_TR_ABSPATH . 'includes/addon_license_area.php';
    }
  
    // Activate Timer license
    function license_activate(){
      include WPSC_TR_ABSPATH . 'includes/license_activate.php';
      die();
    }
  
    // Deactivate Timer license
    function license_deactivate(){
      include WPSC_TR_ABSPATH . 'includes/license_deactivate.php';
      die();
    }
    
    function print_ticket_list_item($field){
      include WPSC_TR_ABSPATH . 'includes/admin/print_ticket_list_item.php';
    }
  
    function wpsc_export_timer_fields($export_colomn_value,$ticket_id,$value){
      include WPSC_TR_ABSPATH . 'includes/admin/wpsc_export_timer_fields.php';
      return $export_colomn_value;
    }
    
    function print_ticket_list_header($ticket_widget_id){
      
      $ticket_widget = get_term_by( 'term_id', $ticket_widget_id, 'wpsc_ticket_widget' );
      if($ticket_widget->slug == 'timer' ){
        $ticket_widget_name = get_term_meta($ticket_widget->term_id, 'wpsc_label', true);
        $ticket_list        = get_term_by( 'slug', 'timer', 'wpsc_ticket_custom_fields' );
        update_term_meta($ticket_list->term_id,'wpsc_tf_label',$ticket_widget_name);
      }
    }
    
    function timer_setting_pill(){
      include WPSC_TR_ABSPATH . 'includes/timer_setting_pill.php';
    }
    
    function get_timer_settings(){
      include WPSC_TR_ABSPATH . 'includes/get_timer_settings.php';
      die();
    }
    
    function set_timer_settings(){
      include WPSC_TR_ABSPATH . 'includes/set_timer_settings.php';
      die();
    }
    
    function auto_start_timer($ticket_id){
      include WPSC_TR_ABSPATH . 'includes/auto_start_timer.php';
    }
    
    function wpsc_get_all_meta_keys($meta_key){
			$meta_key[] = 'timer';
			return $meta_key;
		}
    
    function db_upgrade_data($ticket_id,$post_id){
      include WPSC_TR_ABSPATH . 'db_upgrade_data.php';
    }
    
    function auto_stop_timer($ticket_id,$status_id,$prev_status){
      include WPSC_TR_ABSPATH . 'includes/auto_stop_timer.php';
    }
    
    function wpsc_add_agent_role_item()  {
      include WPSC_TR_ABSPATH . 'includes/add_role_item.php';
    }
    
    function wpsc_edit_agent_role_item($agent_role_item){
      include WPSC_TR_ABSPATH . 'includes/edit_role_item.php';
    }
    
    function wpsc_has_permission($response, $ticket_id, $permission){
      global $wpscfunction;
      switch ($permission) {
        
        case 'view_timer':
          $response = $wpscfunction->agent_has_permission( 'view_unassigned_timer', $ticket_id ) ||  $wpscfunction->agent_has_permission( 'view_assigned_me_timer', $ticket_id ) || $wpscfunction->agent_has_permission( 'view_assigned_others_timer', $ticket_id ) ? true : false;
          break;
      }
        return $response;
    }
    
    function wpsc_agent_has_permission( $response, $permission, $ticket_id){
      
      global $current_user,$wpscfunction;
      $current_agent_id = $wpscfunction->get_current_user_agent_id();
      if(!$current_agent_id) return false;
      
      if(!$current_user->has_cap('wpsc_agent')) return false;
      $role_id = get_user_option( 'wpsc_agent_role', $current_user->ID );
      $agent_roles = get_option('wpsc_agent_role');
      
      $permissions = $agent_roles[$role_id];
      $assigned_agents = $wpscfunction->get_ticket_meta($ticket_id,'assigned_agent');
      
      switch($permission){
        case 'view_unassigned_timer':
            $response = ($permissions[$permission] && in_array(0,$assigned_agents)) ? true : false;
            break;
      
        case 'view_assigned_me_timer':
          $response = ($permissions[$permission] && in_array($current_agent_id,$assigned_agents)) ? true : false;
          break;
        
        case 'view_assigned_others_timer':
          $response = ($permissions[$permission] && !in_array($current_agent_id,$assigned_agents) && !in_array(0,$assigned_agents)) ? true : false;
          break;
      }
      
      return $response;
    }

    // get add timer note
    function get_add_timer_note(){
      include WPSC_TR_ABSPATH . 'includes/admin/settings-tabs/ajax/get_add_timer_note.php';
      die();
    }

    // set add timer note
    function set_add_timer_note(){
      include WPSC_TR_ABSPATH . 'includes/admin/settings-tabs/ajax/set_add_timer_note.php';
    }
}
endif;
