<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $wpdb;

$timer_information = array();

$ticket_id = isset($_POST) && isset($_POST['ticket_id']) ? intval($_POST['ticket_id']) : 0;

$timer_information['ticket_id ']= $ticket_id ;
$flag 	=  false;
$time_total_seconds = 0;
$timer	=	$wpdb->get_results("SELECT * FROM {$wpdb->prefix}wpsc_timer WHERE post_id='".$ticket_id."'");
if(!empty($timer)){
  	foreach ($timer as $trow){
      if($trow->timer_status){
          $flag = true;
      }
      $time_total_seconds = $time_total_seconds + ((int)$trow->time_spend);
  	}    
}else{
    //no timer entry for this ticket
    $time_total_seconds = 0;
}

if($flag){
    $timer_information['ticket_status'] = 1;//timer is on
		//$start_time = date_i18n( 'Y-m-d H:i:s', strtotime( get_date_from_gmt($trow->start_time, 'Y-m-d H:i:s') ) );
		$start_time = $trow->start_time;
    $timer_information['ticket_start']  = $start_time;
}else{
    $timer_information['ticket_status'] = 0;//timer is off
}
$timer_information['time_seconds'] = $time_total_seconds;

echo json_encode($timer_information);