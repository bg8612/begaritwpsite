<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
global $wpdb,$wpsctimer;

$log_id     = isset($_POST['log_id']) ? (sanitize_text_field($_POST['log_id'])) : 0 ;
$end_time   = isset($_POST['edate']) ? (sanitize_text_field($_POST['edate'])) : 0 ;
$start_time = isset($_POST['sdate']) ? (sanitize_text_field($_POST['sdate'])) : 0 ;
$note       = isset($_POST) && isset($_POST['note']) ? sanitize_text_field($_POST['note']) : '';

$timer	    = $wpdb->get_row("SELECT * FROM {$wpdb->prefix}wpsc_timer WHERE id='".$log_id."'");
$start_time = $wpsctimer->get_time_local_to_utc($start_time);
$end_time   = $wpsctimer->get_time_local_to_utc( $end_time);

$timeFirst  = strtotime($start_time);
$timeSecond = strtotime($end_time);
$differenceInSeconds = $timeSecond - $timeFirst;

$values = array(
	        'start_time'    => $start_time,
            'end_time'      => $end_time,
            'time_spend'    => $differenceInSeconds,
            'note'          => $note
        );

$wpdb->update($wpdb->prefix.'wpsc_timer',$values,array('id'=>$timer->id));

echo '{ "sucess_status":"1","messege":"'.__('Log updated successfully.','wpsc-timer').'" }';