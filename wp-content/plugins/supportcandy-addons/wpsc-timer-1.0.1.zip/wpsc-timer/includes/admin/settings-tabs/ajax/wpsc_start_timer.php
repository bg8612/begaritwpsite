<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
global $wpdb,$wpsctimer;
$start_time	=	date("Y-m-d H:i:s");
$ticket_id = isset($_POST) && isset($_POST['ticket_id']) ? intval($_POST['ticket_id']) : 0;

$values=array(
            'post_id'=>	$ticket_id,
            'start_time'=> $start_time,
            'timer_status'=>	1
        );
$wpdb->insert($wpdb->prefix.'wpsc_timer',$values);
echo $wpdb->insert_id;


