<?php
if ( ! defined( 'ABSPATH' ) ) {
  exit; // Exit if accessed directly
}

global $wpscfunction,$wpdb,$current_user;

$ticket_id = isset($_POST['ticket_id']) ? intval(sanitize_text_field($_POST['ticket_id'])) : 0 ;
ob_start();
?>

<div class="row">
    <form id="frn_add_timer_note">
        <div class="form-group">
            <label for="wpsc_timer_note"><?php _e('Add note for this stop','wpsc-timer')?></label>
            <input type="text"  class="form-control" id="wpsc_timer_note" name="wpsc_timer_note" value="" autocomplete="off"  >
        </div>

        <input type="hidden" name="action"  value='set_add_timer_note'>
        <input type="hidden" name="ticket_id" id="ticket_id" value="<?php echo $ticket_id ?>" />

    </form>
</div>


<?php
$body = ob_get_clean();
ob_start();
?>

<button type="button" class="btn wpsc_popup_close" onclick="wpsc_modal_close();"><?php _e('Skip','wpsc-timer');?></button>
<button type="button" id="add_note" class="btn wpsc_popup_action"  onclick="wpsc_set_add_timer_note(<?php echo $ticket_id;?>);"><?php _e('Add Note','wpsc-timer');?></button>

		

<?php
$footer = ob_get_clean();

$response = array(
    'body'      => $body,
    'footer'    => $footer
);

echo json_encode($response);