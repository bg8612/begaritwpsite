<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $wpdb;

$ticket_id = isset($_POST) && isset($_POST['ticket_id']) ? intval($_POST['ticket_id']) : 0;
$note      = isset($_POST) && isset($_POST['wpsc_timer_note']) ? sanitize_text_field($_POST['wpsc_timer_note']) : '';
$timer     = $wpdb->get_row("SELECT id FROM {$wpdb->prefix}wpsc_timer WHERE post_id='".$ticket_id."' ORDER BY id DESC LIMIT 1");

$values  = array(
        'note' => $note
        );

$wpdb->update($wpdb->prefix.'wpsc_timer',$values,array('id'=>$timer->id));

