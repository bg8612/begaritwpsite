<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
 
global $wpscfunction,$current_user,$wpsctimer,$wpdb;

$ticket_id = isset($_POST['ticket_id']) ? intval(sanitize_text_field($_POST['ticket_id'])) :0 ;
$log_id    = isset($_POST['logid']) ? sanitize_text_field($_POST['logid']) : 0 ;
$count_id   = isset($_POST['countid']) ? sanitize_text_field($_POST['countid']) : 0 ;

$startime  = array();
$entime	   = array();
$note      = array();
$timer_log = $wpdb->get_results( "select * from {$wpdb->prefix}wpsc_timer where post_id='".$ticket_id."'");
ob_start();
?>
<form id="frm_ticket_timer_log">
  <?php
    if(!empty($timer_log)){
				$count = 0;
				foreach ($timer_log as  $log) {
					++$count;
          $time_spend=$wpsctimer->sec_to_min_hrs($log->time_spend);
					if(isset($log->end_time)){
							$startime[$log->id]=$log->start_time;
      				$entime[$log->id]=$log->end_time;
				$last_log_id=$log->id;
				$note[$log->id] = $log->note;
							
          }
  			}
    }

  	if (isset($last_log_id) || !empty($last_log_id)): ?>

  				<div class="form-group" style="padding-left:2px;">
						<table id=""   class="table table-striped table-bordered"  cellspacing="5" cellpadding="5">
  		            <tr>
  				            <th><b><?php _e('Timer Log ID :', 'wpsc-timer'); ?></b></th>
  		                <td><?php echo $log_id;?></td>
  		            </tr>
  		            <tr>
  		                <th><b><?php _e('Start Time :', 'wpsc-timer'); ?></b></th>
  		                <td>
  											<input type="text" id="start_time_log" name="start_time_log" value="<?php echo $wpsctimer->get_time_utc_to_local($startime[$log_id]); ?>">
  										</td>
  		            </tr>
  		            <tr>
  		                <th><b><?php _e('End Time :', 'wpsc-timer'); ?><b></th>
  		                <td><input type="text" id="end_time_log" name="end_time_log" value="<?php echo $wpsctimer->get_time_utc_to_local($entime[$log_id]);?>"></td>
					  </tr>
					
					<tr>
  		                <th><b><?php _e('Note :', 'wpsc-timer'); ?><b></th>
  		                <td><input type="text" style=" width:500px " id="timer_note" name="timer_note" value="<?php echo $note[$log_id];?>"></td>
  		            </tr>  
  		      </table>
  		    </div>
  		<?php endif; ?>

    <input type="hidden" name="ticket_id" id="wpsc_post_id" value="<?php echo $ticket_id ?>" />
</form>
<style>
	.fa-edit{
    cursor: pointer;
  }
</style>
<script>

	jQuery(document).ready(function() {
		
		jQuery('#start_time_log').datetimepicker({
			 dateFormat : '<?php echo get_option('wpsc_calender_date_format')?>',
				showAnim : 'slideDown',
				changeMonth: true,
				changeYear: true,
			 timeFormat: 'HH:mm:ss'
		 });
		 
		 jQuery('#end_time_log').datetimepicker({
			 dateFormat : '<?php echo get_option('wpsc_calender_date_format')?>',
				showAnim : 'slideDown',
				changeMonth: true,
				changeYear: true,
			 timeFormat: 'HH:mm:ss'
		 });
	});

function wpsc_timer_log_update(e,logid,ticket_id){
	flag = true;
	sdate = jQuery('#start_time_log').val();
	edate = jQuery('#end_time_log').val();
	note  = jQuery('#timer_note').val();
	var startDate = new Date(sdate);
	var endDate 	= new Date(edate);
	if (endDate < startDate || sdate.length == 0 || edate.length == 0 ||isNaN(startDate) || isNaN(endDate) ){
			alert('<?php _e('Please Enter Valid Date','wpsc-timer')?>');
			flag = false;
	}
	
	if(flag){
		var data = {
        action: 'update_ticket_timer_log',
        edate : edate,
		sdate : sdate,
        log_id : logid,
		ticket_id : ticket_id,
		note:note
    };
    jQuery.post(wpsc_admin.ajax_url, data, function(response_str) {
		 var response = JSON.parse(response_str);
		 jQuery('.wpsc_submit_wait').hide();
	    if (response.sucess_status=='1') {
	      jQuery('#wpsc_alert_success .wpsc_alert_text').text(response.messege);
	    }
	    jQuery('#wpsc_alert_success').slideDown('fast',function(){});
	    setTimeout(function(){ jQuery('#wpsc_alert_success').slideUp('fast',function(){}); }, 3000);
		  wpsc_modal_close();
			wpsc_open_ticket(ticket_id);
	 	});
  }
    e.preventDefault();
}
</script>

<?php
$body = ob_get_clean();
ob_start();
?>

<button type="button" class="btn wpsc_popup_close" onclick="wpsc_modal_close();"><?php _e('Close','wpsc-timer');?></button>
<?php if (isset($last_log_id) || !empty($last_log_id)): ?>
		<button type="button" id="update_log" class="btn wpsc_popup_action"  onclick="wpsc_timer_log_update(event,<?php echo $log_id;?>,<?php echo $ticket_id;?>);"><?php _e('Update','wpsc-timer');?></button>
<?php endif; ?>
		

<?php
$footer = ob_get_clean();

$response = array(
    'body'      => $body,
    'footer'    => $footer
);

echo json_encode($response);
