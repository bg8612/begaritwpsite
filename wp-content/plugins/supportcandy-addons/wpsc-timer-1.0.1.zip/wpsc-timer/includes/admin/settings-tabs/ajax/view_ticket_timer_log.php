<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $wpscfunction, $wpsctimer,$wpdb;

$ticket_id = isset($_POST['ticket_id']) ? intval(sanitize_text_field($_POST['ticket_id'])) : 0 ;

$timer_log = $wpdb->get_results( "select * from {$wpdb->prefix}wpsc_timer where post_id='".$ticket_id."'");
$startime  = array();
$entime    = array();

ob_start();

?>
<form id="frm_ticket_timer_log">
	<?php
	 if(!empty($timer_log)){?>
		<div class="table-responsive" id="wpsc_timer_log_popup">
				
			<table class="table table-sm" id="wpsc_timer_table">
			<thead>
				<tr>
					<th><?php _e('Sr.No','wpsc-timer');?></th>
					<th><?php _e('Start Time','wpsc-timer');?></th>
					<th><?php _e('End TIme','wpsc-timer');?></th>
					<th><?php _e('Time Interval','wpsc-timer');?></th>
					<th><?php _e('Note','wpsc-timer');?></th>
				</tr>
			</thead>
			<tbody>
				<?php	
				$count =	0;
				foreach ($timer_log as  $log) {
								++$count;
						?>
						<tr>
							<td><?php echo $count; ?></td>
							<td><?php echo $wpsctimer->get_time_utc_to_local($log->start_time); ?></td>
							<td><?php echo $wpsctimer->get_time_utc_to_local($log->end_time); ?></td>
							<td><?php echo $wpsctimer->sec_to_min_hrs($log->time_spend);?></td>
							<td><?php echo $log->note ? $log->note :'Note not added' ?></td>
							<td class="wpsc_timer_edit_log">	
								<?php
								if (isset($log->end_time)) {
									$startime[$log->id] = $log->start_time;
									$entime[$log->id] = $log->end_time;
									$last_log_id = $log->id;
									?>
									<button id="wpsc_edit_ticket_timer" onclick="wpsc_edit_ticket_timer_log('<?php echo $ticket_id ?>', '<?php echo $log->id ?>', '<?php echo $count ?>');" class="btn btn-sm wpsc_action_btn"  ><i class="fas fa-edit"></i></button>
									<?php
								}
								?>
						</td>
						</tr>
				<?php
					}	
				?>
			</tbody>
		</table>
		</div>
	   <?php 
		}else{
			?>
			<div class="" style="text-align:center;font-size: 20px;margin-top:20px;"><?php _e('No log found ','wpsc-timer');?></div>
		  <?php		
		 }
		?> 

		<?php
		$totat_time_			= $wpdb->get_results( "select * from {$wpdb->prefix}wpsc_timer where post_id='".$ticket_id."'");
		$time_spend 			= 0;
		$total_time_spend = 0;
		if(!empty($totat_time_)){
			foreach ($totat_time_ as $log){
				$time_spend += $log->time_spend;
			}
		}
		$total_time_spend += $time_spend
		 ?>
</form>
<script>
	function wpsc_edit_ticket_timer_log(ticket_id, logid, countid){
		wpsc_modal_open('<?php _e('Ticket Timer Log','wpsc-timer')?>');
		var data = {
				action: 'edit_ticket_timer_log',
				ticket_id : ticket_id,
			 	logid 	: logid,
			 	countid : countid,
		}
		jQuery.post(wpsc_admin.ajax_url, data, function(response_str) {
		 var response = JSON.parse(response_str);
		 jQuery('#wpsc_popup_body').html(response.body);
		 jQuery('#wpsc_popup_footer').html(response.footer);
	 	});
	}

	function wpsc_copy_timer_log(el){
		var range, selection;
		jQuery(el).find('.wpsc_timer_edit_log').remove();
		if (document.body.createTextRange) {
			range = document.body.createTextRange();
			range.moveToElementText(el);
			range.select();
		} else if (window.getSelection) {
			selection = window.getSelection();
			range     = document.createRange();
			range.selectNodeContents(el);
			selection.removeAllRanges();
			selection.addRange(range);
		}
		try {
			document.execCommand('copy');
			wpsc_modal_close();
		}
		catch (err) {
			alert('unable to copy text');
		}

   }
</script>
<?php

$body = ob_get_clean();

ob_start();

?>

<div class="row">
	<div class="col-md-7" style="text-align: left;padding-left: 0px">
		<?php 
		if($total_time_spend){?>
			<span style="font-size:16px;"><?php echo 'Total time spend on ticket : '.$wpsctimer->sec_to_min_hrs($total_time_spend) ;?></span>
		<?php
		}else{?>
			<span style="font-size:16px;"><?php echo 'Total time spend on ticket : '.'00:00:00' ;?></span>
		<?php
		}
		?>	
	</div>
	<button type="button" class="btn btn-sm  pull-right wpsc_popup_close" onclick="wpsc_modal_close();"><?php _e('Close','wpsc-timer');?></button>
	<?php 
	if($timer_log){
	  ?>
	    <button type="button" class="btn btn-sm  pull-right wpsc_popup_action" style="width: auto !important" onclick="wpsc_copy_timer_log(document.getElementById('wpsc_timer_log_popup'));"><?php _e('Copy logs to clipboard','wpsc-timer');?></button>		
	 <?php	
	}
	?>
	
</div>
    
<?php
$footer = ob_get_clean();

$response = array(
    'body'      => $body,
    'footer'    => $footer
);

echo json_encode($response);
