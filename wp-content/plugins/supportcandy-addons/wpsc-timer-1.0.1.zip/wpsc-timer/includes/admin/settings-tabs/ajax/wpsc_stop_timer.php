<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $wpdb;

$ticket_id = isset($_POST) && isset($_POST['ticket_id']) ? intval($_POST['ticket_id']) : 0;
$end_time  = date("Y-m-d H:i:s");
$timer     = $wpdb->get_row("SELECT * FROM {$wpdb->prefix}wpsc_timer WHERE post_id='".$ticket_id."' and timer_status=1");
$start_time = $timer->start_time;

$timeFirst  = strtotime($start_time);
$timeSecond = strtotime($end_time);
$differenceInSeconds = $timeSecond - $timeFirst;

$values=array(
            'end_time'      =>$end_time,
            'timer_status'  =>0,
            'time_spend'    =>$differenceInSeconds
        );
$wpdb->update($wpdb->prefix.'wpsc_timer',$values,array('id'=>$timer->id));