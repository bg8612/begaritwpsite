<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
 
global $wpscfunction,$current_user,$wpsctimer,$wpdb;

$ticket_id      = isset($_POST['ticket_id']) ? intval(sanitize_text_field($_POST['ticket_id'])) : 0 ;
$customer_email = $wpscfunction->get_ticket_fields($ticket_id,'customer_email');
$filter         = $wpscfunction->get_current_filter();

$wpsc_appearance_modal_window = get_option('wpsc_modal_window');
$wpsc_appearance_ticket_list = get_option('wpsc_appearance_ticket_list');
$wpsc_active_timer_color = get_option('wpsc_active_timer_color');

$meta_query = array(
	'relation' => 'AND',
);

$meta_query = array(
	'relation' => 'OR',
	array(
		'key'            => 'customer_email',
		'value'          => $customer_email,
		'compare'        => '='
	),
);

$sql = "SELECT DISTINCT t.*  FROM ".$wpdb->prefix."wpsc_ticket t ";

$where = " WHERE ";

$where .= $wpsctimer->get_where_query($meta_query);

$where .= " AND t.active = 1 ";

$orderby = " ORDER BY t.id ";
$sql = $sql  . $where .$orderby;

$tickets = $wpdb->get_results($sql);
$ticket_list = json_decode(json_encode($tickets), true);

ob_start();
?>
<form>
  <div class="table-responsive">
		<table id="tbl_ticket_created" class="table table-striped table-bordered" cellspacing="0" width="100%">
				<thead style="background-color:<?php echo $wpsc_appearance_ticket_list['wpsc_ticket_list_header_bg_color']?> !important;color:<?php echo $wpsc_appearance_ticket_list['wpsc_ticket_list_header_text_color']?> !important;">
  				<tr>
  					<th><?php _e('Ticket id','wpsc-timer');?> </th>
						<th><?php _e('Ticket Status','wpsc-timer');?> </th>
            <th><?php _e('Ticket Subject','wpsc-timer');?> </th>
            <th><?php _e('Ticket Category','wpsc-timer');?> </th>
            <th><?php _e('Timer Status','wpsc-timer');?> </th>
  				  <th><?php _e('Time Spend','wpsc-timer');?> </th>
          </tr>
        </thead>

				<tbody>
			     <?php
					   $total_time_spend = 0;
						foreach ($ticket_list as $list) {
             ?>
             <tr class="wpsc_tl_row_item" data-id="<?php echo $list['id']?>" onclick="if(link){wpsc_modal_close(); wpsc_get_individual_ticket(this);}" style= "cursor:pointer">
                <?php
                $ticket_id = $list['id'];
                echo "<td>".$ticket_id."</td>";
                
								$ticket_status = $wpscfunction->get_ticket_fields($list['id'],'ticket_status');
                $status_obj = get_term_by('id', $ticket_status,'wpsc_statuses');
								$status_color = get_term_meta( $status_obj->term_id, 'wpsc_status_color', true);
								$status_background_color = get_term_meta( $status_obj->term_id, 'wpsc_status_background_color', true);
                echo "<td> <span class='wpsp_admin_label' style='background-color:".$status_background_color.";color:".$status_color."'>".$status_obj->name."</span></td>";
								
                $ticket_subject = $wpscfunction->get_ticket_fields($list['id'],'ticket_subject');
                echo "<td>".$ticket_subject."</td>"; 
                
                $ticket_category = $wpscfunction->get_ticket_fields($list['id'],'ticket_category');
                $category_obj = get_term_by('id', $ticket_category,'wpsc_categories');
                echo "<td>".$category_obj->name."</td>";
                
								//timer status 
								$tm =__('Stopped','wpsc-timer');
								$timer_status = $wpdb->get_var("SELECT COUNT(id) FROM {$wpdb->prefix}wpsc_timer WHERE post_id=".$list['id']." AND timer_status=1");
								if($timer_status){
									$tm =__('Running','wpsc-timer');
									echo "<td> <span style='color:".$wpsc_active_timer_color."'>".$tm."</span></td>";
								}else{
									echo "<td>".$tm."</td>";
								}
								//total timer spend
								$timer_log = $wpdb->get_results( "select * from {$wpdb->prefix}wpsc_timer where post_id='".$list['id']."'");
								$time_spend = 0;
								if(!empty($timer_log)){
			 						foreach ($timer_log as $log){
										$time_spend += $log->time_spend;
									}
								}
								$total_time_spend += $time_spend;
								if($time_spend!=0){											
										echo '<td class="wpsc_timer_td_log">'.$wpsctimer->sec_to_min_hrs($time_spend).'</td>';
								}else{
										echo '<td class="wpsc_timer_td_log">-</td>';
								} 	
								?> 																
						 </tr>
								<?php	
            }
         ?>								
				</tbody>
		</table>
	</div>
</form>

<link rel="stylesheet" type="text/css" href="<?php echo WPSC_PLUGIN_URL.'asset/lib/DataTables/datatables.min.css';?>"/>
<script type="text/javascript" src="<?php echo WPSC_PLUGIN_URL.'asset/lib/DataTables/datatables.min.js';?>"></script>
<script>
 jQuery(document).ready(function() {
	 jQuery('#tbl_ticket_created').DataTable({
		 "aLengthMenu": [[4, 8, 12, -1], [4, 8, 12, "All"]]		
		});
} );
</script>
<?php
$body = ob_get_clean();
ob_start();
?>

<div class="col-md-9" style="text-align: left;">
		<?php 
		if($total_time_spend){?>
			<span style="font-size:16px;"><?php echo 'Total time spend on all tickets : '.$wpsctimer->sec_to_min_hrs($total_time_spend) ;?></span>
		<?php
		}else{?>
			<span style="font-size:16px;"><?php echo 'Total time spend on all tickets : '.'00:00:00' ;?></span>
		<?php
		}
	?>	
</div>
<div class="col-md-3" style="text-align: right;">
		<button type="button" class="btn wpsc_popup_close" onclick="wpsc_modal_close();"><?php _e('Close','wpsc-timer');?></button>
</div>


<?php

$footer = ob_get_clean();

$response = array(
    'body'      => $body,
		'footer'    => $footer
);

echo json_encode($response);