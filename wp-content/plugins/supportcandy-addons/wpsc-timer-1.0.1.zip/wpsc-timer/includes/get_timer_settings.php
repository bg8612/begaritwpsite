<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

?>
<form id="wpsc_timer_settings" method="post" action="javascript:wpsc_set_timer_settings();">
	<div class="form-group">
		<label for="wpsc_timer_enable"><?php _e('Timer Enable/Disable','wpsc-timer');?></label>
		<p class="help-block"><?php _e("Enable/Disable Timer start at ticket created.",'wpsc-timer');?></p>
		<select class="form-control" name="wpsc_timer_enable" id="wpsc_timer_enable">
			<?php
			$wpsc_timer_enable = get_option('wpsc_timer_enable');
			$selected = $wpsc_timer_enable == '1' ? 'selected="selected"' : '';
			echo '<option '.$selected.' value="1">'.__('Enable','supportcandy').'</option>';
			$selected = $wpsc_timer_enable == '0' ? 'selected="selected"' : '';
			echo '<option '.$selected.' value="0">'.__('Disable','supportcandy').'</option>';
			?>
		</select>
	</div>
	
	<div class="form-group">
		<label for="wpsc_timer_stop"><?php _e('Timer Auto Stop','wpsc-timer');?></label>
		<p class="help-block"><?php _e("Enable/Disable Timer stop at ticket closed.",'wpsc-timer');?></p>
		<select class="form-control" name="wpsc_timer_stop" id="wpsc_timer_stop">
			<?php
			$wpsc_timer_stop = get_option('wpsc_timer_stop');
			$selected = $wpsc_timer_stop == '1' ? 'selected="selected"' : '';
			echo '<option '.$selected.' value="1">'.__('Enable','supportcandy').'</option>';
			$selected = $wpsc_timer_stop == '0' ? 'selected="selected"' : '';
			echo '<option '.$selected.' value="0">'.__('Disable','supportcandy').'</option>';
			?>
		</select>
	</div>

	<div class="form-group">
		<label for="wpsc_timer_setting"><?php _e('Show Timer for customers','wpsc-timer');?></label>
		<p class="help-block"><?php _e("Enable/Disable Timer to show timer for customers.",'wpsc-timer');?></p>
		<select class="form-control" name="wpsc_timer_visibility" id="wpsc_timer_visibility">
			<?php
			$wpsc_timer_visibility_for_customer = get_option('wpsc_timer_visibility_for_customer');
			$selected = $wpsc_timer_visibility_for_customer == '1' ? 'selected="selected"' : '';
			echo '<option '.$selected.' value="1">'.__('Enable','supportcandy').'</option>';
			$selected = $wpsc_timer_visibility_for_customer == '0' ? 'selected="selected"' : '';
			echo '<option '.$selected.' value="0">'.__('Disable','supportcandy').'</option>';
			?>
		</select>
	</div>
	
	<div class="form-group">
	  <label for="wpsc_active_timer_color "><?php _e('Active Timer Color','wpsc-timer');?></label>
	  <p class="help-block"><?php _e('Select color of active timer on ticket list.','wpsc-pc');?></p>
		<?php 
		$wpsc_active_timer_color = get_option('wpsc_active_timer_color');
		 ?>
	  <input id="wpsc_active_timer_color" class="wpsc_color_picker" name="wpsc_active_timer_color" value= <?php echo $wpsc_active_timer_color; ?> >
	</div>
	
	<button type="submit" class="btn btn-success"><?php _e('Save Changes','wpsc-timer');?></button>
	<img class="wpsc_submit_wait" style="display:none;" src="<?php echo WPSC_PLUGIN_URL.'asset/images/ajax-loader@2x.gif';?>">
	<input type="hidden" name="action" value="wpsc_set_timer_settings" />
</form>
<script>
  jQuery(document).ready(function(){
      jQuery('.wpsc_color_picker').wpColorPicker();
  });
</script>
<script>
function wpsc_set_timer_settings(){
	jQuery('.wpsc_submit_wait').show();
  var dataform = new FormData(jQuery('#wpsc_timer_settings')[0]);  
  jQuery.ajax({
    url: wpsc_admin.ajax_url,
    type: 'POST',
    data: dataform,
    processData: false,
    contentType: false
  })
  .done(function (response_str) {
    var response = JSON.parse(response_str);
    jQuery('.wpsc_submit_wait').hide();
    if (response.sucess_status=='1') {
      jQuery('#wpsc_alert_success .wpsc_alert_text').text(response.messege);
    }
    jQuery('#wpsc_alert_success').slideDown('fast',function(){});
    setTimeout(function(){ jQuery('#wpsc_alert_success').slideUp('fast',function(){}); }, 3000);
  });  
}
</script>