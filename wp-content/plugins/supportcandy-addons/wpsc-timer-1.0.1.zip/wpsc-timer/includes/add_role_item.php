<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $current_user;
if (!($current_user->ID && $current_user->has_cap('manage_options'))) {exit;}

?>
<div class="form-group row" style="margin-bottom:30px;">
	<div class="col-sm-4">
		<label><?php _e('Timer unassigned','wpsc-timer');?></label>
		<p class="help-block"><?php _e('Timer unassigned ticket capability.','wpsc-timer');?></p>
		<select class="form-control" name="agentrole[view_unassigned_timer]">
			<option value="0"><?php _e('Disable','wpsc-timer');?></option>
			<option value="1"><?php _e('Enable','wpsc-timer');?></option>
		</select>
	</div>
	
	<div class="col-sm-4">
		<label><?php _e('Timer assigned me','wpsc-timer');?></label>
		<p class="help-block"><?php _e('Ticket assigned to user himself timer capability.','wpsc-timer');?></p>
		<select class="form-control" name="agentrole[view_assigned_me_timer]">
			<option value="0"><?php _e('Disable','wpsc-timer');?></option>
			<option value="1"><?php _e('Enable','wpsc-timer');?></option>
		</select>
	</div>
	
	<div class="col-sm-4">
		<label><?php _e('Timer assigned others','wpsc-timer');?></label>
		<p class="help-block"><?php _e('Ticket assigned to all other agents timer capability.','wpsc-timer');?></p>
		<select class="form-control" name="agentrole[view_assigned_others_timer]">
			<option value="0"><?php _e('Disable','wpsc-timer');?></option>
			<option value="1"><?php _e('Enable','wpsc-timer');?></option>
		</select>
	</div>
</div>  