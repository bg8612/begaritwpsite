<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if ( ! class_exists( 'WPSC_Timer_Ajax' ) ) :
    final class WPSC_Timer_Ajax{
      public function __construct(){
        $ajax_events = array(
          'wpsc_start_timer' 				=>  false,
          'wpsc_stop_timer'	 				=>	false,
          'wpsc_check_timer_status'	=>	true,
          'view_ticket_timer_log'		=>	false,
          'update_ticket_timer_log'	=>	false,
					'edit_ticket_timer_log'		=>	false,
          'get_all_tickets_time'		=>	false
        );
         
				foreach ($ajax_events as $ajax_event => $nopriv) {
					add_action('wp_ajax_' . $ajax_event, array($this, $ajax_event));
					if ($nopriv) {
						add_action('wp_ajax_nopriv_' . $ajax_event, array($this, $ajax_event));
					}
				}
      }
      
      function wpsc_start_timer(){
        include WPSC_TR_ABSPATH . 'includes/admin/settings-tabs/ajax/wpsc_start_timer.php';
        die();
      }
      
      function wpsc_stop_timer(){
        include WPSC_TR_ABSPATH . 'includes/admin/settings-tabs/ajax/wpsc_stop_timer.php';
        die();
      }
      
      function wpsc_check_timer_status(){
        include WPSC_TR_ABSPATH . 'includes/admin/settings-tabs/ajax/wpsc_check_timer_status.php';
        die();
      }
        
      function view_ticket_timer_log(){
				include WPSC_TR_ABSPATH . 'includes/admin/settings-tabs/ajax/view_ticket_timer_log.php';
        die();
      }
        
      function update_ticket_timer_log(){
        include WPSC_TR_ABSPATH . 'includes/admin/settings-tabs/ajax/update_ticket_timer_log.php';
        die();
      }
			
			function edit_ticket_timer_log(){
				include WPSC_TR_ABSPATH . 'includes/admin/settings-tabs/ajax/edit_ticket_timer_log.php';
				die();
			}
			
			function get_all_tickets_time(){
				include WPSC_TR_ABSPATH . 'includes/admin/settings-tabs/ajax/get_all_tickets_time.php';
				die();
			}  
    }
endif;  