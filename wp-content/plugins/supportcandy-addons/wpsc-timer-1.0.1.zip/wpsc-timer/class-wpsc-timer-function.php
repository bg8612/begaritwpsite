<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if ( ! class_exists( 'WPSC_Timer_Functions' ) ) :
    
  /**
   * Functions class for WPSC.
   * @class WPSC_Export_Functions
   */
   
   final class WPSC_Timer_Functions{
     
     public function sec_to_min_hrs($sec){
          $ms = 0;
          $s  = 0;
          $m  = 0;
          $h  = 0;
					$d  = 0;	

          // calculate seconds
          $s = $sec;
          if ($s < 1) {
              $s = 0;
          } else {
              // calculate minutes   
              $m = ($s-($s%60))/60;
              if ($m < 1) {
                  $m = 0;
              } else {
                  // calculate hours
                  $h = ($m-($m%60))/60;
                  if ($h < 1) {
                      $h = 0;
                  } else {
										//calculate days 
										$d = ($h-($h%24))/24;
										if ($d < 1) {
											  $d = 0;
										}
									}                            
              }    
          }


          // substract elapsed minutes, hours and days
          $ms = round($ms/100);
          $s  = $s-($m*60);
          $m  = $m-($h*60); 
					$h  = $h-($d*24);
          $time="";
					if($d){
              $time.=$d." days  ";
          }
          if($h){
              $time.=$h." hrs  ";
          }
          if($m){
              $time.=$m." mins  ";
          }
          if($s){
              $time.=$s." sec";
          }
          return $time;
          
        }
			
			public function get_time_utc_to_local($time){
				if($time){
					$local_time = date_i18n( 'Y-m-d H:i:s', strtotime( get_date_from_gmt( $time, 'Y-m-d H:i:s') ) );	
				}else{
					$local_time = '';
				}
				
				return $local_time;
			}
			
			public function get_time_local_to_utc($time){
				return get_gmt_from_date($time);
			}	
			
			public function get_where_query($meta_query){
				$sSql =' '; 
				foreach ($meta_query as $key => $value) {
					if(is_array($value)){
						$sSql .= " t." .$value['key']. " " .$value['compare']."'".$value['value']."'";
					}
				}
				return $sSql;
			}
		}
    
endif;  
$GLOBALS['wpsctimer'] =  new WPSC_Timer_Functions();