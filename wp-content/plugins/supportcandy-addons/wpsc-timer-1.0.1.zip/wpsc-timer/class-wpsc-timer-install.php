<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if ( ! class_exists( 'WPSC_Timer_Install' ) ) :
  
  final class WPSC_Timer_Install {
    
    public function __construct() {
			$this->check_version();
    }
    
    /**
     * Check version of Timer
     */
    public function check_version(){
        $installed_version = get_option( 'wpsc_tr_current_version', 0 );
				if( $installed_version != WPSC_TR_VERSION ){
						$this->create_db_tables();
            add_action( 'init', array($this,'upgrade'), 101 );
        }
    }
    
		/**
		 * Create mysql tables
		 */
		public function create_db_tables() {
			
			global $wpdb;

			require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );

			$collate = 'CHARACTER SET utf8 COLLATE utf8_general_ci';
			
			$tables = "CREATE TABLE {$wpdb->prefix}wpsc_timer (
				id int(11) NOT NULL AUTO_INCREMENT,
				post_id int(11) NULL DEFAULT NULL,
				start_time VARCHAR(100) NULL DEFAULT NULL,
				end_time VARCHAR(100) NULL DEFAULT NULL,
				timer_status int(11) DEFAULT 1,
				time_spend VARCHAR(100) NULL DEFAULT NULL,
				note LONGTEXT NULL DEFAULT NULL,
				PRIMARY KEY  (id)
			) $collate; ";
			
			dbDelta( $tables );
		}
		
    // Upgrade
		public function upgrade(){
      	$installed_version = get_option( 'wpsc_tr_current_version', 0 );
				$installed_version = $installed_version ? $installed_version : 0;
				if ( $installed_version < '1.0.0' ) {
					
					update_option('wpsc_timer_enable',0);
					update_option('wpsc_timer_stop',0);
					update_option('wpsc_active_timer_color','#5cb85c');
					
					$agent_role = get_option('wpsc_agent_role');
					foreach ($agent_role as $key => $capabilities){
						if ($key == 1) {
							$capabilities['view_unassigned_timer'] = 1;
							$capabilities['view_assigned_me_timer'] = 1;
							$capabilities['view_assigned_others_timer'] = 1;
						} else {
							$capabilities['view_unassigned_timer'] = 0;
							$capabilities['view_assigned_me_timer'] = 1;
							$capabilities['view_assigned_others_timer'] = 0;
						}
						
						$agent_role[$key] = $capabilities;
						update_option('wpsc_agent_role',$agent_role);
						
					}
				}
				
      	update_option( 'wpsc_tr_current_version', WPSC_TR_VERSION );	  
    }
}
endif; 

new WPSC_Timer_Install ;