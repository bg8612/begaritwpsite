<?php 
/**
 * Plugin Name: SupportCandy - Timer
 * Plugin URI:  https://supportcandy.net/
 * Description: Timer add-on for SupportCandy
 * Version: 1.0.1
 * Author: Support Candy
 * Author URI:  https://supportcandy.net/
 * Text Domain: wpsc-timer
 * Domain Path: /lang
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
if ( ! class_exists( 'WPSC_TIMER' ) ) :
	final class WPSC_TIMER {
	  
	  public $version = '1.0.1';
	  
	  public function __construct() {
				$this->define_constants();
				$this->includes();
				add_action( 'init', array($this,'load_textdomain') );
				if ( class_exists( 'Support_Candy' ) ) :
					register_activation_hook(__FILE__,array($this,'activation'));
					register_deactivation_hook( __FILE__, array($this,'deactivate') );
				endif;
		}
	  
	  function define_constants(){
	      $this->define('WPSC_TR_ABSPATH', dirname(__FILE__) . '/');
				$this->define('WPSC_TR_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
				$this->define('WPSC_TR_PLUGIN_BASENAME', plugin_basename(__FILE__));
				$this->define('WPSC_TR_STORE_ID', '23906');
				$this->define('WPSC_TR_VERSION', $this->version);
			}
	    
	  function load_textdomain(){
				$locale = apply_filters( 'plugin_locale', get_locale(), 'wpsc-timer' );
				load_textdomain( 'wpsc-timer', WP_LANG_DIR . '/wpsc/wpsc-timer-' . $locale . '.mo' );
				load_plugin_textdomain( 'wpsc-timer', false, plugin_basename( dirname( __FILE__ ) ) . '/lang' );
		}
	  
	  public function includes() {
	    include_once( WPSC_TR_ABSPATH . 'class-wpsc-timer-install.php' );
			include_once( WPSC_TR_ABSPATH . 'includes/admin/class-wpsc-timer-admin.php' );
			include_once( WPSC_TR_ABSPATH . 'class-wpsc-timer-function.php' );
	    include_once( WPSC_TR_ABSPATH . 'class-wpsc-timer-ajax.php' );
			
	    $admin = new WPSC_TR_Admin();
	    
	    $this->set_class_objects();
	    
	    add_action('wpsc_add_ticket_widget',array($admin,'wpsc_timer_sidebar_module'),10,3);
			
			//Ticket list
			add_action('wpsc_print_default_tl_field', array($admin, 'print_ticket_list_item'));
			add_action('wpsc_set_edit_ticket_widget', array($admin, 'print_ticket_list_header'));
			
			//Export Data
			add_filter('wpsc_timer_export_ticket_fields', array($admin ,'wpsc_export_timer_fields' ),10,3);
			
			//Start timer when ticket created 
			add_filter('wpsc_ticket_created', array($admin,'auto_start_timer'),10,1);
			
			//Stop timer after ticket closed
			add_action('wpsc_set_change_status',array($admin,'auto_stop_timer'),10,3);


			//settings
			add_action('wpsc_after_setting_pills',array($admin,'timer_setting_pill'));
			add_action('wp_ajax_wpsc_get_timer_settings',array($admin,'get_timer_settings'));
			add_action( 'wp_ajax_wpsc_set_timer_settings', array($admin,'set_timer_settings'));
			
			add_filter('wpsc_get_all_meta_keys', array($admin,'wpsc_get_all_meta_keys'),10,1);
			
			add_action('wpsc_db_upgrade_data',array($admin,'db_upgrade_data'),10,2);
			add_action('wpsc_add_agent_role_item',array($admin,'wpsc_add_agent_role_item'));
			add_action('wpsc_edit_agent_role_item',array($admin,'wpsc_edit_agent_role_item'),10,1);
			add_filter('wpsc_has_permission',array($admin,'wpsc_has_permission'),10,3);
			add_filter('wpsc_agent_has_permission',array($admin,'wpsc_agent_has_permission'),10,3);

			// add note to timer after timer stop
			add_action('wp_ajax_get_add_timer_note',array($admin,'get_add_timer_note'));
			add_action('wp_ajax_set_add_timer_note',array($admin,'set_add_timer_note'));
			
	  	 //License 
			add_filter( 'wpsc_is_add_on_installed', array($admin,'is_add_on_installed'));
			add_action( 'wpsc_addon_license_area', array($admin,'addon_license_area'));
			add_action( 'wp_ajax_wpsc_tr_activate_license', array($admin,'license_activate'));
			add_action( 'wp_ajax_wpsc_tr_deactivate_license', array($admin,'license_deactivate'));
			add_action( 'admin_init', array($this, 'plugin_updator'));
	  }
	  
	  private function set_class_objects(){
	  	$this->functions = new WPSC_Timer_Functions();
	    $this->ajax      = new WPSC_Timer_Ajax();
	  }
	  
	  private function define($name, $value) {
			if (!defined($name)) {
					define($name, $value);
			}
		}
		
		function activation(){
			//add timer widget at activation
			$agent_role_ids 	 = array();
			$agent_role 			 = get_option('wpsc_agent_role');
			foreach ($agent_role as $key => $agent) {
				$agent_role_ids[] = $key;
			}
			$customer_access= array();
			$customer_access 	 = $agent_role_ids;
			$customer_access[] = 'customer';
			
			$term = wp_insert_term('Timer', 'wpsc_ticket_widget' );
			if (!is_wp_error($term) && isset($term['term_id'])) {
					add_term_meta ($term['term_id'], 'wpsc_label', __('Timer','wpsc-timer'));
					add_term_meta ($term['term_id'], 'wpsc_ticket_widget_load_order', '6');
					add_term_meta($term['term_id'], 'wpsc_ticket_widget_type', '1');
					add_term_meta($term['term_id'],'wpsc_ticket_widget_role', $customer_access);
					$wpsc_custom_widget_localize = get_option('wpsc_custom_widget_localize');
        	$wpsc_custom_widget_localize['custom_widget_'.$term['term_id']] = get_term_meta($term['term_id'], 'wpsc_label', true);
        	update_option('wpsc_custom_widget_localize', $wpsc_custom_widget_localize);
			}
			$term = wp_insert_term( 'timer', 'wpsc_ticket_custom_fields' );
			if (!is_wp_error($term) && isset($term['term_id'])) {
				add_term_meta ($term['term_id'], 'wpsc_tf_label', __('Timer','wpsc-timer'));
				add_term_meta ($term['term_id'], 'agentonly', '2');
				add_term_meta ($term['term_id'], 'wpsc_tf_type', '0');
				add_term_meta ($term['term_id'], 'wpsc_conditional', '1');
				add_term_meta ($term['term_id'], 'wpsc_allow_ticket_list', '1');
				add_term_meta ($term['term_id'], 'wpsc_customer_ticket_list_status', '0');
				add_term_meta ($term['term_id'], 'wpsc_agent_ticket_list_status', '0');
				add_term_meta ($term['term_id'], 'wpsc_tl_customer_load_order', '10');
				add_term_meta ($term['term_id'], 'wpsc_tl_agent_load_order', '10');
				add_term_meta ($term['term_id'], 'wpsc_filter_customer_load_order', '10');
				add_term_meta ($term['term_id'], 'wpsc_filter_agent_load_order', '10');
				$custom_fields_localize = get_option('wpsc_custom_fields_localize');
				$custom_fields_localize['custom_fields_' . $term['term_id']] = get_term_meta($term['term_id'], 'wpsc_tf_label', true);
				update_option('wpsc_custom_fields_localize', $custom_fields_localize);
			}	
		}
		/*
	     * This will be called while plugin deactivation
	     * You can write code for removing something after plugin deactivate etc.
	     */
	  function deactivate(){
	     include( WPSC_TR_ABSPATH.'class-wpsc-timer-uninstall.php' );
	  }
		
		function plugin_updator(){
			$license_key    = get_option('wpsc_timer_license_key','');
			$license_expiry = get_option('wpsc_timer_license_expiry','');
			if ( class_exists('Support_Candy') && $license_key && $license_expiry ) {
				$edd_updater = new EDD_SL_Plugin_Updater( WPSC_STORE_URL, __FILE__, array(
								'version' => WPSC_TR_VERSION,
								'license' => $license_key,
								'item_id' => WPSC_TR_STORE_ID,
								'author'  => 'Pradeep Makone',
								'url'     => site_url()
				) );
			}	
		}
		
	}

endif;
new WPSC_TIMER();