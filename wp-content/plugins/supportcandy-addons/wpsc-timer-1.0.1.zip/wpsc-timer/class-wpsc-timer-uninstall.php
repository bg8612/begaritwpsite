<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

$timer = get_term_by( 'slug', 'timer', 'wpsc_ticket_widget' );

if($timer){
	wp_delete_term( $timer->term_id, 'wpsc_ticket_widget' );
	$wpsc_custom_widget_localize = get_option('wpsc_custom_widget_localize');
	unset($wpsc_custom_widget_localize['custom_widget_' .$timer->term_id]);
  update_option('wpsc_custom_widget_localize', $wpsc_custom_widget_localize);
}

$ticket_list_items = get_term_by('slug','timer','wpsc_ticket_custom_fields');
if($ticket_list_items){
	wp_delete_term( $ticket_list_items->term_id, 'wpsc_ticket_custom_fields' );
	$custom_fields_localize = get_option('wpsc_custom_fields_localize');
  unset($custom_fields_localize['custom_fields_' .$ticket_list_items->term_id]);
  update_option('wpsc_custom_fields_localize', $custom_fields_localize);
}