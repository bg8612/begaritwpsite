<?php
if ( ! defined( 'ABSPATH' ) ) {
  exit; // Exit if accessed directly
}

global $wpscfunction,$wpdb;

$wpsc_ticket_id_type = get_option('wpsc_ticket_id_type');

// Ticket Status
$default_status = get_option('wpsc_default_ticket_status');

// Priority
$default_priority = get_option('wpsc_default_ticket_priority');

// Category
$default_category = get_option('wpsc_default_ticket_category');

$check_flag = false;
$last_check = get_option('wpsc_st_cron_last_check');
if($last_check){
  $now = time();
  $ago = strtotime($last_check);
  $diff = $now - $ago;
  $diff_minutes = round( $diff / 60 );
	if( $diff_minutes >= 60 ){
		$check_flag = true;
	}
}

if(!(!$last_check || $check_flag)){
	 return;
} else {
  update_option('wpsc_st_cron_last_check', date("Y-m-d H:i:s") );
}

$schedule_ticket = get_terms([
	'taxonomy'   => 'wpsc_schedule_tickets',
	'hide_empty' => false,
]);

foreach ($schedule_ticket as $ticket) {

  $repeat_every_time_unit = get_term_meta( $ticket->term_id, 'repeat_every_time_unit',true);
  $start_date         = get_term_meta( $ticket->term_id, 'start_date',true);
  $customer_name      = get_term_meta( $ticket->term_id, 'customer_name',true);
  $customer_email     = get_term_meta( $ticket->term_id, 'customer_email',true);
  $ticket_subject     = get_term_meta( $ticket->term_id, 'ticket_subject',true);
  $ticket_description = get_term_meta( $ticket->term_id, 'ticket_description',true);
  $ticket_category    = get_term_meta( $ticket->term_id, 'ticket_category',true);
  $ticket_priority    = get_term_meta( $ticket->term_id, 'ticket_priority',true);
  
  $ticket_priority    = $ticket_priority ? $ticket_priority : $default_priority;
  $ticket_category    = $ticket_category ? $ticket_category : $default_category;
  
  $now = time();
  
  if(strtotime($start_date) <= $now) {
    
    $values = array(
      
    	  'ticket_subject'     => $ticket_subject,
        'ticket_description' => $ticket_description,
        'customer_name'      => $customer_name,
        'customer_email'     => $customer_email,
        'ticket_status'      => $default_status,
        'ticket_category'    => $ticket_category,
        'ticket_priority'    => $ticket_priority,
        'reply_source'       => 'schedule_ticket'
      );

    $custom_fields = get_terms([
    	'taxonomy'   => 'wpsc_ticket_custom_fields',
    	'hide_empty' => false,
    	'orderby'    => 'meta_value_num',
    	'meta_key'	 => 'wpsc_tf_visibility',
    	'order'    	 => 'ASC',
    	'meta_query' => array(
    		 array(
          'key'       => 'agentonly',
          'value'     => '0',
          'compare'   => '='
         )
    	 ),
    ]);

    if($custom_fields){
    	 foreach ($custom_fields as $field) {
    			$value = get_term_meta($ticket->term_id, $field->slug, true );
    			if($value){
    				$values[$field->slug]=$value;
    		 	}
    	 }
    }
    
    if(!$wpsc_ticket_id_type){
      $id = 0;
      do {
          $id = rand(11111111, 99999999);
          $sql = "select id from {$wpdb->prefix}wpsc_ticket where id=" . $id;
          $result = $wpdb->get_var($sql);
      } while ($result);
      $values['id'] = $id;
    }
    
    if($repeat_every_time_unit == 'days') {
      
      $now = time();
      $start_date = strtotime($start_date);
      
      $no_of_recurrence = get_term_meta( $ticket->term_id, 'no_of_recurrence',true);
      $diff = $now - $start_date;
      
      $diff_days = intval( $diff/(60*60*24) );
      $days = intval($diff_days / $no_of_recurrence);
      
      $recurrence_days = get_term_meta($ticket->term_id, 'wpsc_schedule_tickets_diff',true);
      
      if( !is_numeric($recurrence_days) || $days > $recurrence_days ) {
        $ticket_id = $wpscfunction->create_ticket($values);
        $agent_only_fields = get_terms([
        	'taxonomy'   => 'wpsc_ticket_custom_fields',
        	'hide_empty' => false,
        	'orderby'    => 'meta_value_num',
        	'meta_key'	 => 'wpsc_tf_load_order',
        	'order'    	 => 'ASC',
        	'meta_query' => array(
        		array(
              'key'       => 'agentonly',
              'value'     => '1',
              'compare'   => '='
            )
        	),
        ]);
        if($agent_only_fields){
        	 foreach ($agent_only_fields as $field) {
              $wpsc_tf_type = get_term_meta( $field->term_id, 'wpsc_tf_type',true);
              $value = get_term_meta($ticket->term_id, $field->slug, true );
              if($wpsc_tf_type==3) {
                $chk_value = get_term_meta($ticket->term_id, $field->slug, true );
                $value = implode(", ", $chk_value);
              }
        			if($value){
                $wpscfunction->add_ticket_meta($ticket_id,$field->slug,$value);
              }
        	 }
        }
        update_term_meta($ticket->term_id , 'wpsc_schedule_tickets_diff' ,$days );
      }

    } elseif ($repeat_every_time_unit=='months') {
        
        $now        = new DateTime();
        $start_date = new DateTime($start_date);
        
        $no_of_recurrence = get_term_meta( $ticket->term_id, 'no_of_recurrence',true);
        
        $diff = $now->diff($start_date);
        
        $months = ($diff->y*12) + $diff->m;
        $months = intval($months / $no_of_recurrence);

        $recurrence_months = get_term_meta($ticket->term_id, 'wpsc_schedule_tickets_diff', true);
        if(!is_numeric($recurrence_months) || $months > $recurrence_months ) {
          $ticket_id = $wpscfunction->create_ticket($values);
          $agent_only_fields = get_terms([
          	'taxonomy'   => 'wpsc_ticket_custom_fields',
          	'hide_empty' => false,
          	'orderby'    => 'meta_value_num',
          	'meta_key'	 => 'wpsc_tf_load_order',
          	'order'    	 => 'ASC',
          	'meta_query' => array(
          		array(
                'key'       => 'agentonly',
                'value'     => '1',
                'compare'   => '='
              )
          	),
          ]);
          if($agent_only_fields){
          	 foreach ($agent_only_fields as $field) {
                $wpsc_tf_type = get_term_meta( $field->term_id, 'wpsc_tf_type',true);
          			$value = get_term_meta($ticket->term_id, $field->slug, true );
                if($wpsc_tf_type==3) {
                  $chk_value = get_term_meta($ticket->term_id, $field->slug, true );
                  $value = implode(", ", $chk_value);
                }
          			if($value){
                  $wpscfunction->add_ticket_meta($ticket_id,$field->slug,$value);
          		 	}
          	 }
          }
          update_term_meta($ticket->term_id , 'wpsc_schedule_tickets_diff' ,$months );
        }
     } elseif($repeat_every_time_unit == 'year'){

        $now = new DateTime();
        $start_date = new DateTime($start_date);
    
        $no_of_recurrence = get_term_meta( $ticket->term_id, 'no_of_recurrence',true);
    
        $diff = $now->diff($start_date);
    
        $year = intval($diff->y / $no_of_recurrence);

        $recurrence_year = get_term_meta($ticket->term_id, 'wpsc_schedule_tickets_diff', true);
    
        if(is_numeric($year) && $year > $recurrence_year ) {
          $ticket_id = $wpscfunction->create_ticket($values);
          $agent_only_fields = get_terms([
            'taxonomy'   => 'wpsc_ticket_custom_fields',
            'hide_empty' => false,
            'orderby'    => 'meta_value_num',
            'meta_key'	 => 'wpsc_tf_load_order',
            'order'    	 => 'ASC',
            'meta_query' => array(
              array(
                'key'       => 'agentonly',
                'value'     => '1',
                'compare'   => '='
              )
            ),
          ]);
      
          if($agent_only_fields){
            foreach ($agent_only_fields as $field) {
              $wpsc_tf_type = get_term_meta( $field->term_id, 'wpsc_tf_type',true);
              $value = get_term_meta($ticket->term_id, $field->slug, true );

              if($wpsc_tf_type==3) {
                $chk_value = get_term_meta($ticket->term_id, $field->slug, true );
                $value = implode(", ", $chk_value);
              }
          
              if($value){
                $wpscfunction->add_ticket_meta($ticket_id,$field->slug,$value);
              }
            }
          } 
        update_term_meta($ticket->term_id , 'wpsc_schedule_tickets_diff' ,$year );
      }
    }

  }
}
