<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $wpdb, $current_user, $wpscfunction;

$default_category = get_option('wpsc_default_ticket_category');
$default_priority = get_option('wpsc_default_ticket_priority');
if (!($current_user->ID && $current_user->has_cap('manage_options'))) {exit;}

//Get Schedule Ticket Title
$title = isset($_POST) && isset($_POST['wpsc_schedule_ticket_title']) ? sanitize_text_field($_POST['wpsc_schedule_ticket_title']) : '';
if (!$title) {exit;}

//Ticket ID
$ticket_id = isset($_POST['ticket_id']) ? sanitize_text_field($_POST['ticket_id']) : '' ;
$ticket_data = $wpscfunction->get_ticket($ticket_id);

// Customer name
$customer_name = $ticket_data['customer_name'];
if (!$customer_name) {exit;}

// Customer email
$customer_email = $ticket_data['customer_email'];
if (!$customer_email) {exit;}

// Subject
$ticket_subject = $ticket_data['ticket_subject'];
if (!$ticket_subject) {exit;}

 // Description
$ticket_desc = $wpscfunction->get_ticket_description($ticket_id);
$ticket_description = $ticket_desc['description'];
if (!$ticket_description) {exit;}

 // Category
$ticket_category = $ticket_data['ticket_category'] ? intval($ticket_data['ticket_category']) : $default_category;
 
 // Priority
$ticket_priority = $ticket_data['ticket_priority'] ? intval($ticket_data['ticket_priority']) : $default_priority;

//Time Unit
$time_unit = isset($_POST) && isset($_POST['wpsc_repeat_every_time_unit']) ? sanitize_text_field($_POST['wpsc_repeat_every_time_unit']) : '';
if (!$time_unit) {exit;}

// Start Date
$start_date = isset($_POST['wpsc_start_date']) ? sanitize_text_field($_POST['wpsc_start_date']) : '';
if ($start_date =='') {
	$now = date('Y-m-d');
	$start_date = $now; 
}

// No Of Days / No of Months
$wpsc_repeat_every_no_of_recurrence = isset($_POST['wpsc_repeat_every_no_of_recurrence']) ? intval($_POST['wpsc_repeat_every_no_of_recurrence']) : '';
if($wpsc_repeat_every_no_of_recurrence=='') {
	$wpsc_repeat_every_no_of_recurrence = '1';
}

// Custom Fields
$fields = get_terms([
	'taxonomy'   => 'wpsc_ticket_custom_fields',
	'hide_empty' => false,
	'orderby'    => 'meta_value_num',
	'meta_key'	 => 'wpsc_tf_load_order',
	'order'    	 => 'ASC',
	'meta_query' => array(
		'relation' => 'AND',
		array(
			'key'       => 'agentonly',
			'value'     => array(0,1),
			'compare'   => 'IN'
		)
	),
]);
 
$term = wp_insert_term($title, 'wpsc_schedule_tickets' );

if (!is_wp_error($term) && isset($term['term_id'])) {
  add_term_meta ($term['term_id'], 'customer_name', $customer_name);
  add_term_meta ($term['term_id'], 'customer_email', $customer_email);
  add_term_meta ($term['term_id'], 'ticket_subject', $ticket_subject);
  add_term_meta ($term['term_id'], 'ticket_description', $ticket_description);
  add_term_meta ($term['term_id'], 'ticket_category', $ticket_category);
	add_term_meta ($term['term_id'], 'ticket_priority', $ticket_priority);
  add_term_meta ($term['term_id'], 'repeat_every_time_unit', $time_unit);
  add_term_meta ($term['term_id'], 'start_date', $start_date);
  add_term_meta ($term['term_id'], 'no_of_recurrence', $wpsc_repeat_every_no_of_recurrence);

	foreach ($fields as $field) {

		$tf_type = get_term_meta( $field->term_id, 'wpsc_tf_type', true);
		switch ($tf_type) {

			case '1':
			case '2':
			case '4':
			case '7':
			case '8':
      		case '5':
			case '18':
				$text = $wpscfunction->get_ticket_meta($ticket_id,$field->slug,true);
				if($text) $args[$field->slug] = $text;
				add_term_meta ($term['term_id'], $field->slug, $text);
				break;

			case '3':
				$text = $wpscfunction->get_ticket_meta($ticket_id,$field->slug);
				if($text) $args[$field->slug] = $text;
				add_term_meta ($term['term_id'], $field->slug, $text);
				break;

			case '9':
				$number = $wpscfunction->get_ticket_meta($ticket_id,$field->slug,true);
        $number = intval($number);
        if($number) $args[$field->slug] = $number;
				add_term_meta ($term['term_id'], $field->slug, $number);
				break;
			
			case '6':
				$text = $wpscfunction->get_ticket_meta($ticket_id,$field->slug,true);
				if($text){
					$args[$field->slug] = $text;
					$text = $wpscfunction->datetimeToCalenderFormat($text);
				}
				add_term_meta ($term['term_id'], $field->slug, $text);
				break;
			
			case '21':
				$text = $wpscfunction->get_ticket_meta($ticket_id,$field->slug,true);
				if($text) $args[$field->slug]  = date("H:i:s " ,strtotime($text));;
				add_term_meta ($term['term_id'], $field->slug, $text);
				break;	

			default:
				do_action('wpsc_add_st_meta_c_field',$term['term_id'],$field,$tf_type);
			break;
		}
    
	}

  do_action('set_add_schedule_ticket',$term['term_id']);
	echo '{ "sucess_status":"1","messege":"'.__('Schedule Ticket added successfully.','wpsc-st').'" }';
} else {
	echo '{ "sucess_status":"0","messege":"'.__('An error occured while creating schedule ticket.','wpsc-st').'" }';
}