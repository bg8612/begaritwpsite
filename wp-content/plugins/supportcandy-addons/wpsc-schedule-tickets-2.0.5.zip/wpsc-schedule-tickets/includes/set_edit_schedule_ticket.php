<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $wpdb, $current_user, $wpscfunction;
if (!($current_user->ID && $current_user->has_cap('manage_options'))) {exit;}

$term_id = isset($_POST) && isset($_POST['term_id']) ? intval($_POST['term_id']) : 0;
if (!$term_id) {exit;}

$title = isset($_POST) && isset($_POST['wpsc_schedule_ticket_title']) ? sanitize_text_field($_POST['wpsc_schedule_ticket_title']) : '';
if (!$title) {exit;}

// Customer name
$customer_name = isset($_POST['customer_name']) ? sanitize_text_field($_POST['customer_name']) : '';
if (!$customer_name) {exit;}

// Customer email
$customer_email = isset($_POST['customer_email']) ? sanitize_text_field($_POST['customer_email']) : '';
if (!$customer_email) {exit;}

// Subject
$subject          = get_term_by('slug', 'ticket_subject', 'wpsc_ticket_custom_fields' );
$wpsc_default_sub = get_term_meta( $subject->term_id,'wpsc_tf_default_subject',true);
$ticket_subject   = isset($_POST['ticket_subject']) ? sanitize_text_field($_POST['ticket_subject']) : apply_filters( 'wpsc_default_subject_text', $wpsc_default_sub,$_POST );
if (!$ticket_subject) {exit;}

// Description
$description            = get_term_by('slug', 'ticket_description', 'wpsc_ticket_custom_fields' );
$wpsc_default_desc      = get_term_meta( $description->term_id,'wpsc_tf_default_description',true);
$ticket_description     = isset($_POST['ticket_description']) ? $_POST['ticket_description'] : apply_filters( 'wpsc_default_description_text', $wpsc_default_desc );	
if (!$ticket_description) {exit;}

// Category
$ticket_category = isset($_POST['ticket_category']) ? intval($_POST['ticket_category']) : get_option('wpsc_default_ticket_category');
if (!$ticket_category) {exit;}

//Priority
$ticket_priority = isset($_POST['ticket_priority']) ? intval($_POST['ticket_priority']) : get_option('wpsc_default_ticket_priority');
if (!$ticket_priority) {exit;}

$time_unit = isset($_POST) && isset($_POST['wpsc_repeat_every_time_unit']) ? sanitize_text_field($_POST['wpsc_repeat_every_time_unit']) : '';
if (!$time_unit) {exit;}

// Start Date
$start_date = isset($_POST['wpsc_start_date']) ? sanitize_text_field($_POST['wpsc_start_date']) : '';
if ($start_date =='') {
	$now = date('Y-m-d');
	$start_date = $now; 
}

// No Of Days
$wpsc_repeat_every_no_of_recurrence = isset($_POST['wpsc_repeat_every_no_of_recurrence']) ? intval($_POST['wpsc_repeat_every_no_of_recurrence']) : '';
if($wpsc_repeat_every_no_of_recurrence=='') {
	$wpsc_repeat_every_no_of_recurrence = '1';
}

$fields = get_terms([
	'taxonomy'   => 'wpsc_ticket_custom_fields',
	'hide_empty' => false,
	'orderby'    => 'meta_value_num',
	'meta_key'	 => 'wpsc_tf_load_order',
	'order'    	 => 'ASC',
	'meta_query' => array(
		'relation' => 'AND',
		array(
			'key'       => 'agentonly',
			'value'     => array(0,1),
			'compare'   => 'IN'
		)
	),
]);

wp_update_term($term_id, 'wpsc_schedule_tickets', array(
  'name' => $title
));
update_term_meta ($term_id, 'customer_name', $customer_name);
update_term_meta ($term_id, 'customer_email', $customer_email);
update_term_meta ($term_id, 'ticket_subject', $ticket_subject);
update_term_meta ($term_id, 'ticket_description',$ticket_description);
update_term_meta ($term_id, 'ticket_category', $ticket_category);
update_term_meta ($term_id, 'ticket_priority', $ticket_priority);
update_term_meta ($term_id, 'repeat_every_time_unit', $time_unit);
update_term_meta ($term_id, 'start_date', $start_date);
update_term_meta ($term_id, 'no_of_recurrence', $wpsc_repeat_every_no_of_recurrence);

foreach ($fields as $field) {
	$tf_type = get_term_meta( $field->term_id, 'wpsc_tf_type', true);
	switch ($tf_type) {
		case '1':
		case '2':
		case '4':
		case '6':
		case '7':
		case '8':
		case '18':
			$text = isset($_POST[$field->slug]) ? sanitize_text_field($_POST[$field->slug]) : '';
			if($text) $args[$field->slug] = $text;
			update_term_meta ($term_id, $field->slug, $text);
			break;

		case '3':
		case '5':
			$text = isset($_POST[$field->slug]) ? wp_kses_post($_POST[$field->slug]) : '';
			if($text) $args[$field->slug] = $text;
			update_term_meta ($term_id, $field->slug, $text);
			break;

		case '9':
			$number = isset($_POST[$field->slug]) ? intval($_POST[$field->slug]) : '';
			if($number) $args[$field->slug] = $number;
			update_term_meta ($term_id, $field->slug, $number);
			break;
		
		case '21':
			$text = isset($_POST[$field->slug]) ? sanitize_text_field($_POST[$field->slug]) : '';
			if($text) $args[$field->slug] = date("H:i:s " ,strtotime($text));;
			update_term_meta ($term_id, $field->slug, $text);
			break;

		default:do_action('wpsc_edit_st_rule_meta_custom_field',$term_id, $field,$tf_type);
		break;
	}
}

delete_term_meta($term_id, 'wpsc_schedule_tickets_diff');

do_action('wpsc_set_edit_schedule_tickets_condition',$term_id,$field);
echo '{ "sucess_status":"1","messege":"'.__('Ticket updated successfully.','wpsc-st').'" }';
