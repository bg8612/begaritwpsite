<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
?>
<div>
	<ul class="nav nav-tabs">
		<li role="presentation" class="tab active" onclick="wpsc_change_tab(this,'add_st_settings');"><a href="#"><?php _e('Schedule Tickets','wpsc-st');?></a></li>
		<li role="presentation" class="tab" onclick="wpsc_change_tab(this,'wpsc_other_settings');"><a href="#"><?php _e('Other Settings','wpsc-st');?></a></li>
	</ul>
</div>

<div id="add_st_settings" class="tab_content visible" style="margin-top:20px;">

	<button type="button" style="margin-bottom:6px; float:right;" id="add_new_schedule_ticket_btn" onclick="wpsc_get_add_new_schedule_ticket();" class="btn btn-sm btn-success"><?php _e('+ Add New','wpsc-st');?></button>
	<?php do_action('wpsc_get_st_settings');?>

	<?php
	$schedule_ticket = get_terms([
		'taxonomy'   => 'wpsc_schedule_tickets',
		'hide_empty' => false,
		]); 	?>
	
	<div class="wpsc_padding_space"></div>
	<table class="table table-striped table-hover" id="schedule_ticket_tbl">
		<tr>
			<th><?php _e('Title','wpsc-st')?></th>
			<th><?php _e('Start Date','wpsc-st')?></th>
			<th><?php _e('No Of Days/Month/Year','wpsc-st')?></th>
			<th><?php _e('Action','wpsc-st')?></th>
		</tr>
		<?php 
			foreach ( $schedule_ticket as $ticket ) :
				$repeat_every_time_unit = get_term_meta( $ticket->term_id, 'repeat_every_time_unit',true);
				$start_date   = get_term_meta( $ticket->term_id, 'start_date',true);
				$no_of_recurrence = get_term_meta( $ticket->term_id, 'no_of_recurrence',true);
				
				if($repeat_every_time_unit=='months') {
					$no_of_recurrence = $no_of_recurrence.'&nbsp'.'Months';
				}
				 
				if($repeat_every_time_unit=='days') {
					$no_of_recurrence = $no_of_recurrence.'&nbsp'.'Days';
				}

				if($repeat_every_time_unit=='year') {
					$no_of_recurrence = $no_of_recurrence.'&nbsp'.'Year';
				}

				?>
				<tr>
					<td><?php echo $ticket->name ?></td>
					<td><?php echo $start_date?></td>
					<td><?php echo $no_of_recurrence?></td>
					<td>
						<div class="wpsc_flex">
							<div onclick="wpsp_get_edit_schedule_ticket(<?php echo $ticket->term_id;?>);" style="cursor:pointer;"><i class="fa fa-edit"></i></div>
							<div onclick="wpsc_clone_schedule_ticket(<?php echo $ticket->term_id; ?>);" style="cursor:pointer;padding-left : 10px;"><i class="far fa-clone"></i></div>
							<div onclick="wpsc_delete_schedule_tickets(<?php echo $ticket->term_id;?>);" style="cursor:pointer; padding-left: 10px;"><i class="fa fa-trash"></i></div>
						</div>
					</td>
				</tr>
			<?php endforeach;?>
	</table>
</div>

<div id="wpsc_other_settings" class="tab_content hidden" style="margin-top:20px;">
	
	<form id="wpsc_st_other_settings" method="post" action="javascript:wpsc_set_other_settings()">
		
		<div class="form-group">
			<label for="visibility_for_st_btn"><?php _e('Schedule Existing Ticket','wpsc-st')?></label>
			<p class="help-block"><?php _e('Allow agents to schedule existing ticket from open ticket.','wpsc-st') ?></p>
			<select class="form-control" name="wpsc_schedule_ticket_btn" id="wpsc_schedule_ticket_btn">
				<option <?php echo get_option('wpsc_schedule_ticket_btn')=="0"?'selected="selected"':''; ?> value="0"><?php _e('Disable','wpsc-st')?></option>
				<option <?php echo get_option('wpsc_schedule_ticket_btn')=="1"?'selected="selected"':''; ?> value="1"><?php _e('Enable','wpsc-st')?></option>
			</select>
		
		</div>
		
		<button type="submit" class="btn btn-success" id="wpsc_other_settings_btn"><?php _e('Save Changes','wpsc-st');?></button>
		<img class="wpsc_submit_wait" style="display:none;" src="<?php echo WPSC_PLUGIN_URL.'asset/images/ajax-loader@2x.gif';?>">
		<input type="hidden" name="action" value="wpsc_set_st_other_settings" />
	</form>

</div>
	
<script>

	function wpsc_change_tab(e,content_id){
		jQuery('.tab').removeClass('active');
		jQuery(e).addClass('active');
		jQuery('.tab_content').removeClass('visible').addClass('hidden');
		jQuery('#'+content_id).removeClass('hidden').addClass('visible');
	}
	
	function wpsc_get_add_new_schedule_ticket() {
	  jQuery('#schedule_ticket_tbl').hide();
	  var data = {
	    action : 'wpsc_get_add_schedule_ticket_form_field'
	  };
	  jQuery.post(wpsc_admin.ajax_url, data, function(response_str){
			jQuery('.wpsc_setting_col2').html(response_str);
	  });
	}

	function wpsp_get_edit_schedule_ticket(term_id) {
		jQuery('.wpsc_setting_col2').html(wpsc_admin.loading_html);	
		var data = {
			action: 'wpsp_get_edit_schedule_ticket',
			term_id : term_id
		};
		jQuery.post(wpsc_admin.ajax_url, data, function(response_str){
			jQuery('.wpsc_setting_col2').html(response_str);
		});
	}

	function wpsc_delete_schedule_tickets(term_id) {
		if(!confirm('<?php _e('Are you sure?','wpsc-st')?>')) return;
		var data = {
			action : 'wpsc_delete_schedule_ticket',
			term_id : term_id
		};
		jQuery.post(wpsc_admin.ajax_url, data, function(response_str){
			var response = JSON.parse(response_str);
			if (response.sucess_status=='1') {
				jQuery('#wpsc_alert_success .wpsc_alert_text').text(response.messege);
				jQuery('#wpsc_alert_success').slideDown('fast',function(){});
				setTimeout(function(){ jQuery('#wpsc_alert_success').slideUp('fast',function(){}); }, 3000);
				wpsc_get_st_settings();
			}
		});
	}
	
	function wpsc_set_other_settings(){
	
		jQuery('.wpsc_submit_wait').show();
		var dataform = new FormData(jQuery('#wpsc_st_other_settings')[0]);
		jQuery.ajax({
			url: wpsc_admin.ajax_url,
			type: 'POST',
			data: dataform,
			processData: false,
			contentType: false
		})
		.done(function (response_str) {
			var response = JSON.parse(response_str);
			jQuery('.wpsc_submit_wait').hide();
			jQuery('#wpsc_alert_success .wpsc_alert_text').text(response.message);
			jQuery('#wpsc_alert_success').slideDown('fast',function(){});
			setTimeout(function(){ jQuery('#wpsc_alert_success').slideUp('fast',function(){}); }, 3000);
		});
	}

	function wpsc_clone_schedule_ticket(term_id){
		var data = {
			action : 'wpsc_clone_schedule_ticket',
			term_id : term_id
		};
		jQuery.post(wpsc_admin.ajax_url, data, function(response_str){
			var response = JSON.parse(response_str);
			if (response.sucess_status=='1') {
				jQuery('#wpsc_alert_success .wpsc_alert_text').text(response.messege);
				jQuery('#wpsc_alert_success').slideDown('fast',function(){});
				setTimeout(function(){ jQuery('#wpsc_alert_success').slideUp('fast',function(){}); }, 3000);
				wpsp_get_edit_schedule_ticket(response.term_id);
			}
		});
	}
</script>
