<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
global $current_user,$wpscfunction;

if (!($current_user->ID && $current_user->has_cap('wpsc_agent'))) {
 exit;
}

$ticket_id     = isset($_POST['ticket_id']) ? sanitize_text_field($_POST['ticket_id']) : '' ;
$wpsc_appearance_modal_window = get_option('wpsc_modal_window');

ob_start();
?>
<form id="frm_schedule_ticket" method="post">
	<div class="form-group">
		<label for="wpsc_schedule_ticket_title"><?php _e('Title','wpsc-st');?></label>
		<p class="help-block"><?php _e('Title to show in schedule ticket list.','wpsc-st');?></p>
		<input id="wpsc_schedule_ticket_title" class="form-control wpsc_title" name="wpsc_schedule_ticket_title" value=""/>
	</div>

	<div class="form-group">
		<label for="wpsc_repeat_every_time_unit"><?php _e('Repeat Type','wpsc-st');?></label>
		<select class="form-control" id="wpsc_repeat_every_time_unit" style="margin-top:7px;" name="wpsc_repeat_every_time_unit">
			<option value="days"><?php _e('Day','wpsc-st');?></option>
			<option value="months"><?php _e('Month','wpsc-st');?></option>
			<option value = "year"><?php _e('Year','wpsc-st'); ?></option>
		</select>
	</div>

	<div id="wpsc_repeat_every_no_of_recurrence" class="form-group">
		<label for="wpsc_repeat_every_no_of_recurrence"><?php _e('Repeat Days/Months/Year:','wpsc-st');?></label>
		<p class="help-block"><?php _e("No of days/months/years to repeat depending on repeat type. 'Default 1'.","wpsc-st");?></p>
		<input type="number" id="wpsc_repeat_every_no_of_recurrence" class="form-control wpsc_repeat_every_no_of_recurrence" name="wpsc_repeat_every_no_of_recurrence" value=""/>
	</div>

	<div class="form-group">
		<label for="wpsc_start_date"><?php _e('Start Date','wpsc-st');?></label>
		<p class="help-block"><?php _e("Select start date. Default 'Current Date'.","wpsc-st");?></p>
		<input type="text" id="wpsc_start_date" class="form-control wpsc_date" name="wpsc_start_date" autocomplete="off" value=""  onkeypress='return false'>
	</div>
	
	<input type="hidden" name="ticket_id" value="<?php echo htmlentities($ticket_id) ?>" />

</form>
<script type="text/javascript">
  jQuery(document).ready(function(){
    jQuery( ".wpsc_date" ).datepicker({
  			dateFormat : 'yy-mm-dd',
  			showAnim : 'slideDown',
  			changeMonth: true,
  			changeYear: true,
  			yearRange: "-50:+50",
	  });
	});
	
	function wpsc_set_schedule_ticket(ticket_id){
		
		validation = false;
		jQuery('.wpsc_title').each(function(e){
			var title = jQuery(this).val().trim();
			if(title.length > 0) {
				validation = true;
			}
			if (!validation) return;
		});
		
		jQuery('.wpsc_repeat_every_no_of_recurrence').each(function(e){
			var wpsc_repeat_every_no_of_recurrence = jQuery(this).val().trim();
			if(wpsc_repeat_every_no_of_recurrence.length > 0) {
				validation = true;
			}
			if (!validation) return;
		});
		
		jQuery('.wpsc_date').each(function(e){
			var wpsc_date = jQuery(this).val().trim();
			if(wpsc_date.length > 0) {
				validation = true;
			}
			if (!validation) return;
		});
		
		if (!validation) {
			alert("<?php _e('Please enter required fields!','wpsc-st')?>");
			return false;
		}
			
		var dataform = new FormData(jQuery('#frm_schedule_ticket')[0]);
		dataform.append('action', 'wpsc_set_schedule_ticket');
		wpsc_modal_close();
		jQuery.ajax({
			url: wpsc_admin.ajax_url,
			type: 'POST',
			data: dataform,
			processData: false,
			contentType: false
		})
		.done(function (response_str) {
			
			var response = JSON.parse(response_str);
	    jQuery('.wpsc_submit_wait').hide();
	    if (response.sucess_status=='1') {
	      jQuery('#wpsc_alert_success .wpsc_alert_text').text(response.messege);
	    }
	    jQuery('#wpsc_alert_success').slideDown('fast',function(){});
	    setTimeout(function(){ jQuery('#wpsc_alert_success').slideUp('fast',function(){}); }, 3000);
		});
	}
</script>
<?php

$body = ob_get_clean();

ob_start();

?>
<button type="button" class="btn wpsc_popup_close"  style="background-color:<?php echo $wpsc_appearance_modal_window['wpsc_close_button_bg_color']?> !important;color:<?php echo $wpsc_appearance_modal_window['wpsc_close_button_text_color']?> !important;"     onclick="wpsc_modal_close();"><?php _e('Cancel','supportcandy');?></button>
<button type="button" class="btn wpsc_popup_action" style="background-color:<?php echo $wpsc_appearance_modal_window['wpsc_action_button_bg_color']?> !important;color:<?php echo $wpsc_appearance_modal_window['wpsc_action_button_text_color']?> !important;" onclick="wpsc_set_schedule_ticket(<?php echo $ticket_id ?>);" ><?php _e('Schedule Ticket','supportcandy');?></button>
<?php

$footer = ob_get_clean();

$response = array(
    'body'      => $body,
    'footer'    => $footer
);
echo json_encode($response);