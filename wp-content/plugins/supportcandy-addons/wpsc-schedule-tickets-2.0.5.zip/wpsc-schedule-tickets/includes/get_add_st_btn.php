<?php 
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $current_user,$wpscfunction;
$ticket_id     = isset($_POST['ticket_id']) ? sanitize_text_field($_POST['ticket_id']) : '' ;
$ticket_status = $wpscfunction->get_ticket_status($ticket_id);

$general_appearance = get_option('wpsc_appearance_general_settings');
$action_default_btn_css = 'background-color:'.$general_appearance['wpsc_default_btn_action_bar_bg_color'].' !important;color:'.$general_appearance['wpsc_default_btn_action_bar_text_color'].' !important;';

if ( $ticket_status && ($current_user->has_cap('manage_options') ) || ($current_user->has_cap('wpsc_agent') && (!$current_user->has_cap('manage_options')) && get_option('wpsc_schedule_ticket_btn'))):
	?>
  <button type="button" id="wpsc_schedule_btn" onclick="wpsc_get_schedule_ticket(<?php echo $ticket_id?>);" class="btn btn-sm wpsc_action_btn" style="<?php echo $action_default_btn_css?>"> <i class="fas fa-clock"></i> <?php _e('Schedule','supportcandy')?></button>
	<?php
endif;
?>
<script>
  function wpsc_get_schedule_ticket(ticket_id){
    wpsc_modal_open('Schedule Ticket');
    var data = {
      action: 'wpsc_get_add_st_form',
      ticket_id:ticket_id
    }
    jQuery.post(wpsc_admin.ajax_url, data, function(response_str) {
      var response = JSON.parse(response_str);
      jQuery('#wpsc_popup_body').html(response.body);
      jQuery('#wpsc_popup_footer').html(response.footer);
    });
  }
</script>