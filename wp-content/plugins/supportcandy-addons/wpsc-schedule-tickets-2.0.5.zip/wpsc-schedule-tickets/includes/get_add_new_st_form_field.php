<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $current_user, $wpdb,$post,$wpscfunction;
if (!($current_user->ID && $current_user->has_cap('manage_options'))) {
	exit;
}

$fields = get_terms([
	'taxonomy'   => 'wpsc_ticket_custom_fields',
	'hide_empty' => false,
	'orderby'    => 'meta_value_num',
	'order'    	 => 'ASC',
	'meta_query' => array(
		'relation' => 'AND',
		array(
			'key'       => 'agentonly',
			'value'     => array(0,1),
			'compare'   => 'IN'
		)
	),
]);

include WPSC_ST_ABSPATH . 'includes/class-st-ticket-form-field-format.php';
$form_field = new WPSC_ST_CR_Ticket_Form_Field();
?>

<h4 class="form-group" style="margin-bottom:30px;"><?php _e('Create New Schedule Ticket','wpsc-st')?></h4>

<form id="wpsc_frm_create_ticket" action="javascript:wpsc_submit_schedule_ticket();" method="post">

	<div class="form-group">
		<label for="wpsc_schedule_ticket_title"><?php _e('Title','wpsc-st');?></label>
		<span style="color:red;">*</span>
		<p class="help-block"><?php _e('Title to show in schedule ticket list.','wpsc-st');?></p>
		<input id="wpsc_schedule_ticket_title" class="form-control" name="wpsc_schedule_ticket_title" value=""/>
	</div>

	<div class="form-group">
		<label for="wpsc_repeat_every_time_unit"><?php _e('Repeat Type','wpsc-st');?></label>
		<select class="form-control" id="wpsc_repeat_every_time_unit" style="margin-top:7px;" name="wpsc_repeat_every_time_unit">
			<option value="days"><?php _e('Day','wpsc-st');?></option>
			<option value="months"><?php _e('Month','wpsc-st');?></option>
			<option value = "year"><?php _e('Year','wpsc-st');?></option>
		</select>
	</div>

	<div id="wpsc_repeat_every_no_of_recurrence" class="form-group">
		<label for="wpsc_repeat_every_no_of_recurrence"><?php _e('Repeat Days/Months/Year:','wpsc-st');?></label>
		<p class="help-block"><?php _e("No of days/months/year to repeat depending on repeat type. 'Default 1'.","wpsc-st");?></p>
		<input type="number" id="wpsc_repeat_every_no_of_recurrence" class="form-control" name="wpsc_repeat_every_no_of_recurrence" value=""/>
	</div>

	<div class="form-group">
		<label for="wpsc_start_date"><?php _e('Start Date','wpsc-st');?></label>
		<p class="help-block"><?php _e("Select start date. Default 'Current Date'.","wpsc-st");?></p>
		<input type="text" id="wpsc_start_date" class="form-control wpsc_date" name="wpsc_start_date" autocomplete="off" value=""  onkeypress='return false'>
	</div>
	
	<h4 class="form-group" style="margin:50px 0 30px;"><?php _e('Select Fields','wpsc-st')?></h4>

	<?php
	foreach ($fields as $field) {
		$form_field->print_field($field);
	}
	?>

	<div class="form-group">
		<button type="submit" class="btn btn-success" id="wpsc_create_st_btn"><?php _e('Save Changes','wpsc-st');?></button>
		<img class="wpsc_submit_wait" style="display:none;" src="<?php echo WPSC_PLUGIN_URL.'asset/images/ajax-loader@2x.gif';?>">
		<input type="hidden" name="action" value="set_new_st_from_field" />
	</div>

</form>

<script type="text/javascript">
  jQuery(document).ready(function(){
    jQuery( ".wpsc_date" ).datepicker({
  			dateFormat : 'yy-mm-dd',
  			showAnim : 'slideDown',
  			changeMonth: true,
  			changeYear: true,
  			yearRange: "-50:+50",
  	});
		
		jQuery('.wpsc_datetime').datetimepicker({
		 dateFormat : '<?php echo get_option('wpsc_calender_date_format')?>',
			showAnim : 'slideDown',
			changeMonth: true,
			changeYear: true,
		 timeFormat: 'HH:mm:ss'
	 });

		jQuery( "#customer_name" ).autocomplete({
			minLength: 1,
			appendTo: jQuery("#wpsc_agent_name").parent(),
			source: function( request, response ) {
				var term = request.term;
				request = {
					action: 'wpsc_tickets',
					setting_action : 'get_users',
					term : term
				}
				jQuery.getJSON( wpsc_admin.ajax_url, request, function( data, status, xhr ) {
					response(data);
				});	
			},
			select: function (event, ui) {
				jQuery('#customer_name').val(ui.item.value);
				jQuery('#customer_email').val(ui.item.email);
			}
		});
  });
  
  function wpsc_submit_schedule_ticket(){
		var validation = true;
		jQuery('.wpsc_required').each(function(e){
			var field_type = jQuery(this).data('fieldtype');
			switch (field_type) {
				case 'text':
					if(jQuery(this).find('input').val()=='') validation=false;
					break;
				case 'tinymce':
					 <?php 
					 $rich_editing = $wpscfunction->rich_editing_status($current_user);

					 if($rich_editing){
					?>
						var description = tinyMCE.activeEditor.getContent();
						if(description.trim().length==0) validation=false;
						break;
					<?php 
					}else {?>
						var description = jQuery('#ticket_description').val();
						if(jQuery('#ticket_description').val().trim()=='') validation=false;
						break;
						<?php 
					}?>
			}
			if (!validation) return;
		});
		if(jQuery('#wpsc_schedule_ticket_title').val()==''){
			alert("<?php _e('Required fields can not be empty!','supportcandy')?>");
			return false;
		}
		if (!validation) {
			alert("<?php _e('Required fields can not be empty!','supportcandy')?>");
			return false;
		}
		
    var dataform = new FormData(jQuery('#wpsc_frm_create_ticket')[0]);
    dataform.append('action', 'wpsc_set_new_st_from_field');
    
    jQuery.ajax({
      url: wpsc_admin.ajax_url,
      type: 'POST',
      data: dataform,
      processData: false,
      contentType: false
    })
    .done(function (response_str) {
      wpsc_modal_close();
      var response = JSON.parse(response_str);
      if (response.sucess_status=='1') {
        jQuery('#wpsc_alert_success .wpsc_alert_text').text(response.messege);
        wpsc_get_st_settings();
      } 
      jQuery('#wpsc_alert_success').slideDown('fast',function(){});
      setTimeout(function(){ jQuery('#wpsc_alert_success').slideUp('fast',function(){}); }, 3000);
    });
  }
</script>