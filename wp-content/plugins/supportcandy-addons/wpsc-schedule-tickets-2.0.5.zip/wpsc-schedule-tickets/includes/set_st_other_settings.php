<?php 
if ( ! defined( 'ABSPATH' ) ) {
  exit; // Exit if accessed directly
}

global $current_user,$wpscfunction;

$wpsc_schedule_ticket_btn = isset($_POST) && isset($_POST['wpsc_schedule_ticket_btn']) ? sanitize_text_field($_POST['wpsc_schedule_ticket_btn']) : '0';
update_option('wpsc_schedule_ticket_btn',$wpsc_schedule_ticket_btn);

$response = array(
  'message' => __('Setting saved!','wpsc-st')
);
echo json_encode($response);