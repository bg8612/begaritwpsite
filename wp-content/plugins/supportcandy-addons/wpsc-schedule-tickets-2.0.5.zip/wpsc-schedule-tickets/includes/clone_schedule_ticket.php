<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $current_user, $wpscfunction;
if (!($current_user->ID && $current_user->has_cap('manage_options'))) {
	exit;
}

$term_id = isset($_POST) && isset($_POST['term_id']) ? intval($_POST['term_id']) : 0;
if(!$term_id) die();

$schedule_ticket = get_term_by('id',$term_id,'wpsc_schedule_tickets');

//Get Schedule Ticket Title
$title = $schedule_ticket->name.' clone';
$repeat_every_time_unit = get_term_meta( $term_id, 'repeat_every_time_unit',true);
$start_date   = get_term_meta($term_id, 'start_date',true);
$wpsc_repeat_every_no_of_recurrence = get_term_meta($term_id, 'no_of_recurrence',true);

// Customer name
$customer_name = get_term_meta($term_id,'customer_name',true);

// Customer email
$customer_email = get_term_meta($term_id,'customer_email',true);

// Subject
$ticket_subject = get_term_meta($term_id,'ticket_subject',true);

// Description
$ticket_description = get_term_meta($term_id,'ticket_description',true);

// Category
$ticket_category = get_term_meta($term_id,'ticket_category',true);

// Priority
$ticket_priority = get_term_meta($term_id,'ticket_priority',true);

// Custom Fields

$fields = get_terms([
	'taxonomy'   => 'wpsc_ticket_custom_fields',
	'hide_empty' => false,
	'orderby'    => 'meta_value_num',
	'meta_key'	 => 'wpsc_tf_load_order',
	'order'    	 => 'ASC',
	'meta_query' => array(
		'relation' => 'AND',
		array(
			'key'       => 'agentonly',
			'value'     => array(0,1),
			'compare'   => 'IN'
		)
	),
]);

$term = wp_insert_term($title, 'wpsc_schedule_tickets' );
 
if (!is_wp_error($term) && isset($term['term_id'])) {
  add_term_meta ($term['term_id'], 'customer_name', $customer_name);
  add_term_meta ($term['term_id'], 'customer_email', $customer_email);
  add_term_meta ($term['term_id'], 'ticket_subject', $ticket_subject);
  add_term_meta ($term['term_id'], 'ticket_description', $ticket_description);
  add_term_meta ($term['term_id'], 'ticket_category', $ticket_category);
	add_term_meta ($term['term_id'], 'ticket_priority', $ticket_priority);
  add_term_meta ($term['term_id'], 'repeat_every_time_unit', $repeat_every_time_unit);
  add_term_meta ($term['term_id'], 'start_date', $start_date);
  add_term_meta ($term['term_id'], 'no_of_recurrence', $wpsc_repeat_every_no_of_recurrence);

	foreach ($fields as $field) {

		$tf_type = get_term_meta( $field->term_id, 'wpsc_tf_type', true);
		switch ($tf_type) {

			case '1':
			case '2':
			case '4':
			case '7':
			case '8':
      case '5':
			case '18':
				$text = get_term_meta($term_id,$field->slug,true);
				if($text) $args[$field->slug] = $text;
				add_term_meta ($term['term_id'], $field->slug, $text);
				break;

			case '3':
				$text = get_term_meta($term_id,$field->slug);
				if($text) $args[$field->slug] = $text;
				add_term_meta ($term['term_id'], $field->slug, $text);
				break;

			case '9':
        $number = get_term_meta($term_id,$field->slug,true);
        $number = intval($number);
        if($number) $args[$field->slug] = $number;
				add_term_meta ($term['term_id'], $field->slug, $number);
				break;

			case '6':
				$text = get_term_meta($term_id,$field->slug,true);
				if($text){
					$args[$field->slug] = $text;
					$text = $wpscfunction->datetimeToCalenderFormat($text);
				}
				add_term_meta ($term['term_id'], $field->slug, $text);
				break;

			default:
				do_action('wpsc_add_clone_meta_c_field',$term['term_id'],$field,$tf_type);
			break;
		}

	}
  echo '{ "sucess_status":"1","messege":"'.__('Schedule ticket clone successfull.','wpsc-st').'" ,"term_id" : "'.$term['term_id'].'" }';
} else {
	echo '{ "sucess_status":"0","messege":"'.__('An error occured while cloning schedule ticket.','wpsc-st').'" }';
}