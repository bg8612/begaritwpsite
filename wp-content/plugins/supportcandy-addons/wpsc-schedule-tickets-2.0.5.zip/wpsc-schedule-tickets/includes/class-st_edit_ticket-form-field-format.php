<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
?>
<style>
	.wpsc_ct_field_label {
		font-size: 13px !important;
	}
</style>
<?php
if ( ! class_exists( 'WPSC_ST_Ticket_Form_Field' ) ) :

    class WPSC_ST_Ticket_Form_Field {

        var $slug;
        var $type;
        var $label;
        var $extra_info;
				var $status;
				var $options;
        var $required;
        var $width;
        var $col_class;
				var $visibility;
				var $visibility_conditions;

        function print_field($field,$term_id){

          $this->slug = $field->slug;
					$this->term_id = $term_id;
          $this->type = get_term_meta( $field->term_id, 'wpsc_tf_type', true);
          $this->label = get_term_meta( $field->term_id, 'wpsc_tf_label', true);
          $this->extra_info = get_term_meta( $field->term_id, 'wpsc_tf_extra_info', true);
					$this->status = get_term_meta( $field->term_id, 'wpsc_tf_status', true);
					$this->options = get_term_meta( $field->term_id, 'wpsc_tf_options', true);
          $this->required = get_term_meta( $field->term_id, 'wpsc_tf_required', true);
          $this->width = get_term_meta( $field->term_id, 'wpsc_tf_width', true);
					$this->visibility = get_term_meta( $field->term_id, 'wpsc_tf_visibility', true);
					$this->visibility_conditions = is_array($this->visibility) && $this->visibility ? implode(';;', $this->visibility) : '';
					$this->visibility_conditions = str_replace('"','&quot;',$this->visibility_conditions);
					$this->col_class = 'col-sm-12';

          if ($this->type=='0') {
            switch ($field->slug) {

              case 'customer_name':
								$this->print_customer_name($field);
								break;

              case 'customer_email':
                $this->print_customer_email($field);
                break;

              case 'ticket_subject':
                if ($this->status == '1') {
									$this->print_ticket_subject($field);
								}
                break;

              case 'ticket_description':
                if ($this->status == '1') {
									$this->print_ticket_description($field);
								}
                break;

              case 'ticket_category':
                if ($this->status == '1') {
                	$this->print_ticket_category($field);
                }
                break;

							case 'ticket_priority':
                if ($this->status == '1') {
									$this->print_ticket_priority($field);
								}
                break;

              default:
                do_action('wpsc_print_default_form_field', $field, $this);
                break;
            }

          } else {

						switch ($this->type) {

							case '1':
								$this->print_text_field($field);
								break;

							case '2':
								$this->print_drop_down($field);
								break;

							case '3':
								$this->print_checkbox($field);
								break;

							case '4':
								$this->print_radio_btn($field);
								break;

							case '5':
								$this->print_textarea($field);
								break;

							case '6':
								$this->print_date($field);
								break;

							case '7':
								$this->print_url($field);
								break;

							case '8':
								$this->print_email($field);
								break;

							case '9':
								$this->print_numberonly($field);
								break;
							
							case '18':
								$this->print_date_time($field);
								break;
							
							case '21':
								$this->print_time($field);
								break;	
								
          		default:
								do_action('wpsc_print_sl_edit_custom_form_field', $field, $this);
								break;
						}

					}

        }

				function print_text_field($field){
					global $wpscfunction;
					$label = get_option('wpsc_custom_fields_localize');
					$extra_info = get_option('wpsc_custom_fields_extra_info');
					$field_value = get_term_meta($this->term_id, $field->slug, true );
          ?>
          <div class="form-group">
            <label class="wpsc_ct_field_label" for="<?php echo $this->slug;?>">
              <?php  echo $label['custom_fields_'.$field->term_id]; ?>
            </label>
            <?php if($extra_info['custom_fields_extra_info_'.$field->term_id]){ ?><p class="help-block"><?php echo $extra_info['custom_fields_extra_info_'.$field->term_id]; ?></p><?php }?>
            <input type="text" id="<?php echo $this->slug;?>" class="form-control wpsc_textfield" name="<?php echo $this->slug;?>" autocomplete="off" value="<?php echo $field_value; ?>">
          </div>
          <?php
        }

				function print_drop_down($field){
					$label = get_option('wpsc_custom_fields_localize');
					$extra_info = get_option('wpsc_custom_fields_extra_info');
					$field_value = get_term_meta($this->term_id, $field->slug, true );
					?>
          <div class="form-group">
            <label class="wpsc_ct_field_label" for="<?php echo $this->slug;?>">
              <?php echo $label['custom_fields_'.$field->term_id];?>
            </label>
            <?php if($extra_info['custom_fields_extra_info_'.$field->term_id]){ ?><p class="help-block"><?php echo $extra_info['custom_fields_extra_info_'.$field->term_id]; ?></p><?php }?>
						<select id="<?php echo $this->slug;?>" class="form-control wpsc_drop_down" name="<?php echo $this->slug;?>">
			        <option value=""></option>
							<?php
							foreach ( $this->options as $key => $val ) :
									$value = trim(stripcslashes($val));
									$selected = $value == $field_value ? 'selected="selected"' : '';
                    ?>

										<option <?php echo $selected?> value="<?php echo $value?>"><?php echo stripcslashes($val)?></option>

                    <?php
              endforeach;
			        ?>
			      </select>
          </div>
          <?php
				}

				function print_checkbox($field){
					$label = get_option('wpsc_custom_fields_localize');
					$extra_info = get_option('wpsc_custom_fields_extra_info');
					
					$field_value = get_term_meta($this->term_id, $field->slug,true);
					if(empty($field_value)){
						$field_value = array();
					}
					?>
          <div class="form-group">
            <label class="wpsc_ct_field_label" for="<?php echo $this->slug;?>">
              <?php echo $label['custom_fields_'.$field->term_id]; ?>
            </label>
            <?php if($extra_info['custom_fields_extra_info_'.$field->term_id]){ ?><p class="help-block"><?php echo $extra_info['custom_fields_extra_info_'.$field->term_id]; ?></p><?php }?>
						<?php
						foreach ( $this->options as $key => $value ) :
							$checked =in_array( $value, $field_value) ? 'checked="checked"' : '';
							?>
							<div class="row">
				        <div class="col-sm-12" style="margin-bottom:10px; display:flex;">
				          <div style="width:25px;"><input <?php echo $checked ?> type="checkbox" class="wpsc_checkbox" name="<?php echo $this->slug?>[]" value="<?php echo str_replace('"','&quot;',$value)?>"></div>
				          <div style="padding-top:3px;"><?php echo $value?></div>
				        </div>
              </div>
							<?php
						endforeach;
						?>
          </div>
          <?php
				}

				function print_radio_btn($field){
					
					$label = get_option('wpsc_custom_fields_localize');
					$extra_info = get_option('wpsc_custom_fields_extra_info');
					$field_value = get_term_meta($this->term_id, $field->slug, true );
					?>
          <div class="form-group">
            <label class="wpsc_ct_field_label" for="<?php echo $this->slug;?>">
              <?php echo $label['custom_fields_'.$field->term_id]; ?>
            </label>
            <?php if($extra_info['custom_fields_extra_info_'.$field->term_id]){ ?><p class="help-block"><?php echo $extra_info['custom_fields_extra_info_'.$field->term_id]; ?></p><?php }?>
						<?php
						foreach ( $this->options as $key => $value ) :
							$checked = $value == $field_value ? 'checked="checked"' : '';
              ?>
							<div class="row">
				        <div class="col-sm-12" style="margin-bottom:10px; display:flex;">
				          <div style="width:25px;"><input <?php echo $checked ?>type="radio" class="wpsc_radio_btn" name="<?php echo $this->slug?>" value="<?php echo str_replace('"','&quot;',$value)?>"></div>
				          <div style="padding-top:3px;"><?php echo $value?></div>
				        </div>
              </div>
							<?php
						endforeach;
						?>
          </div>
          <?php
				}

				function print_textarea($field){
					$label = get_option('wpsc_custom_fields_localize');
					$extra_info = get_option('wpsc_custom_fields_extra_info');
					$field_value = get_term_meta($this->term_id, $field->slug, true );
					$data  = stripslashes($field_value);
					?>
          <div class="form-group">
            <label class="wpsc_ct_field_label" for="<?php echo $this->slug;?>">
              <?php echo $label['custom_fields_'.$field->term_id];?>
            </label>
            <?php if($extra_info['custom_fields_extra_info_'.$field->term_id]){  ?><p class="help-block"><?php echo $extra_info['custom_fields_extra_info_'.$field->term_id]; ?></p><?php }?>
            <textarea id="<?php echo $this->slug;?>" class="wpsc_textarea" name="<?php echo $this->slug;?>"><?php echo $data ?></textarea>
          </div>
          <?php
				}

				function print_date($field){
					global $wpscfunction;
					$label = get_option('wpsc_custom_fields_localize');
					$extra_info = get_option('wpsc_custom_fields_extra_info');
				    $field_value = get_term_meta($this->term_id, $field->slug, true );
				    $date='';
					$date_range = get_term_meta ($field->term_id, 'wpsc_date_range',true);
					if( strlen($field_value) != 0 ){
						$date = $wpscfunction->datetimeToCalenderFormat($field_value);
					}
					$dr = "";
					if($date_range == 'future'){
						$dr = "minDate: 0";
					}elseif($date_range == 'past'){
						$dr = "maxDate: 0";
					}
					?>
          <div class="form-group">
            <label class="wpsc_ct_field_label" for="<?php echo $this->slug;?>">
              <?php echo $label['custom_fields_'.$field->term_id]; ?>
            </label>
            <?php  if($extra_info['custom_fields_extra_info_'.$field->term_id]){ ?><p class="help-block"><?php echo $extra_info['custom_fields_extra_info_'.$field->term_id]; ?></p><?php }?>
            <input type="text" id="<?php echo $this->slug;?>" class="form-control wpsc_date" name="<?php echo $this->slug;?>" autocomplete="off" value="<?php  echo $field_value;?>" onkeypress='return false'>
          </div>
					<script type="text/javascript">
						jQuery(document).ready(function(){
							jQuery("#<?php echo $this->slug?>").datepicker({
					        dateFormat : 'yy-mm-dd',
					        showAnim : 'slideDown',
					        changeMonth: true,
					        changeYear: true,
					        yearRange: "-50:+50",
							<?php echo $dr?>
					    });
						});
					</script>
          <?php
				}

				function print_url($field){
					$label = get_option('wpsc_custom_fields_localize');
					$extra_info = get_option('wpsc_custom_fields_extra_info');
					$field_value = get_term_meta($this->term_id, $field->slug, true );
					?>
          <div class="form-group">
            <label class="wpsc_ct_field_label" for="<?php echo $this->slug;?>">
              <?php echo $label['custom_fields_'.$field->term_id]; ?>
            </label>
						<?php if($extra_info['custom_fields_extra_info_'.$field->term_id]){ ?><p class="help-block"><?php  echo $extra_info['custom_fields_extra_info_'.$field->term_id]; ?></p><?php }?>
            <input type="text" id="<?php echo $this->slug;?>" class="form-control wpsc_url" name="<?php echo $this->slug;?>" autocomplete="off" value="<?php echo $field_value ?>">
          </div>
          <?php
				}

				function print_email($field){
					$label = get_option('wpsc_custom_fields_localize');
					$extra_info = get_option('wpsc_custom_fields_extra_info');
					$field_value = get_term_meta($this->term_id, $field->slug, true );
					?>
          <div class="form-group">
            <label class="wpsc_ct_field_label" for="<?php echo $this->slug;?>">
							<?php echo $label['custom_fields_'.$field->term_id]; ?>
            </label>
						<?php if($extra_info['custom_fields_extra_info_'.$field->term_id]){ ?><p class="help-block"><?php echo $extra_info['custom_fields_extra_info_'.$field->term_id]; ?></p><?php }?>
            <input type="text" id="<?php echo $this->slug;?>" class="form-control wpsc_email" name="<?php echo $this->slug;?>" autocomplete="off" value="<?php echo $field_value ?>">
          </div>
          <?php
				}

				function print_numberonly($field){
					$label = get_option('wpsc_custom_fields_localize');
					$extra_info = get_option('wpsc_custom_fields_extra_info');
				  $field_value = get_term_meta($this->term_id, $field->slug, true );
					?>
          <div class="form-group">
            <label class="wpsc_ct_field_label" for="<?php echo $this->slug;?>">
							<?php echo $label['custom_fields_'.$field->term_id];?>
            </label>
						<?php  if($extra_info['custom_fields_extra_info_'.$field->term_id]){?><p class="help-block"><?php echo $extra_info['custom_fields_extra_info_'.$field->term_id]; ?></p><?php }?>
            <input type="number" id="<?php echo $this->slug;?>" class="form-control wpsc_numberonly" name="<?php echo $this->slug;?>" autocomplete="off" value="<?php echo $field_value; ?>">
          </div>
          <?php
				}

				function print_customer_name($field){
					$label = get_option('wpsc_custom_fields_localize');
					$extra_info = get_option('wpsc_custom_fields_extra_info');
					$user_name = get_term_meta($this->term_id, $field->slug, true );
					global $current_user;

          ?>
          <div data-fieldtype="text" class="form-group <?php echo $this->required? 'wpsc_required':''?>">
            <label class="wpsc_ct_field_label" for="<?php echo $this->slug;?>">
              <?php echo $label['custom_fields_'.$field->term_id]; ?> <?php echo $this->required? '<span style="color:red;">*</span>':'';?>
            </label>
						<?php if($extra_info['custom_fields_extra_info_'.$field->term_id]){ ?><p class="help-block"><?php echo $extra_info['custom_fields_extra_info_'.$field->term_id]; ?></p><?php }?>
            <input type="text" id="<?php echo $this->slug;?>" class="form-control wpsc_customer_name" name="<?php echo $this->slug;?>" autocomplete="off" value="<?php echo is_user_logged_in() ? $user_name :'' ?>">
          </div>
          <?php
        }

				function print_customer_email($field){
					$label = get_option('wpsc_custom_fields_localize');
					$extra_info = get_option('wpsc_custom_fields_extra_info');
					$user_email = get_term_meta($this->term_id, $field->slug, true );
					global $current_user;
          ?>
          <div data-fieldtype="text" class="form-group <?php echo $this->required? 'wpsc_required':''?>">
            <label class="wpsc_ct_field_label" for="<?php echo $this->slug;?>">
              <?php  echo $label['custom_fields_'.$field->term_id];  ?> <?php echo $this->required? '<span style="color:red;">*</span>':'';?>
            </label>
						<?php if($extra_info['custom_fields_extra_info_'.$field->term_id]){ ?><p class="help-block"><?php echo $extra_info['custom_fields_extra_info_'.$field->term_id]; ?></p><?php }?>
            <input type="text" id="<?php echo $this->slug;?>" class="form-control wpsc_email" name="<?php echo $this->slug;?>" autocomplete="off" value="<?php echo is_user_logged_in() ? $user_email :'' ?>">
          </div>
          <?php
        }

        function print_ticket_subject($field){
					$label = get_option('wpsc_custom_fields_localize');
					$extra_info = get_option('wpsc_custom_fields_extra_info');
					$field_value = get_term_meta($this->term_id, $field->slug, true );
          ?>
          <div data-fieldtype="text" class="form-group <?php echo $this->required? 'wpsc_required':''?>">
            <label class="wpsc_ct_field_label" for="<?php echo $this->slug;?>">
              <?php echo $label['custom_fields_'.$field->term_id]; ?> <?php echo $this->required? '<span style="color:red;">*</span>':'';?>
            </label>
						<?php if($extra_info['custom_fields_extra_info_'.$field->term_id]){ ?><p class="help-block"><?php echo $extra_info['custom_fields_extra_info_'.$field->term_id]; ?></p><?php }?>
            <input type="text" id="<?php echo $this->slug;?>" class="form-control wpsc_subject" name="<?php echo $this->slug;?>" autocomplete="off" value="<?php echo $field_value ?>">
          </div>
          <?php
        }
				
				function print_ticket_category($field){
					$label = get_option('wpsc_custom_fields_localize');
					$extra_info = get_option('wpsc_custom_fields_extra_info');
         	$field_value = get_term_meta($this->term_id,$field->slug, true);
          $term  = get_term($field_value);
					?>
          <div class="form-group">
            <label class="wpsc_ct_field_label" for="<?php echo $this->slug;?>">
              <?php echo $label['custom_fields_'.$field->term_id]; ?>
            </label>
						<?php if($extra_info['custom_fields_extra_info_'.$field->term_id]){?> <p class="help-block"><?php echo $extra_info['custom_fields_extra_info_'.$field->term_id]; ?></p><?php }?>
						<select id="<?php echo $this->slug;?>" class="form-control wpsc_category" name="<?php echo $this->slug;?>">
			   
							<?php
							$categories = get_terms([
							  'taxonomy'   => 'wpsc_categories',
							  'hide_empty' => false,
								'orderby'    => 'meta_value_num',
							  'order'    	 => 'ASC',
								'meta_query' => array('order_clause' => array('key' => 'wpsc_category_load_order')),
							]);
							foreach ( $categories as $category ) :
								$selected = $category->term_id == $field_value ? 'selected="selected"' : '';
			          echo '<option '.$selected.'value="'.$category->term_id.'">'.$category->name.'</option>';
			        endforeach;
			        ?>
			      </select>
          </div>
          <?php
				}

				function print_ticket_priority($field){
					$label = get_option('wpsc_custom_fields_localize');
					$extra_info = get_option('wpsc_custom_fields_extra_info');
					$field_value = get_term_meta($this->term_id,$field->slug, true);
          $term  = get_term($field_value);
					?>
          <div class="form-group">
            <label class="wpsc_ct_field_label" for="<?php echo $this->slug;?>">
              <?php echo $label['custom_fields_'.$field->term_id];?>
            </label>
						<?php if($extra_info['custom_fields_extra_info_'.$field->term_id]){ ?><p class="help-block"><?php  echo $extra_info['custom_fields_extra_info_'.$field->term_id]; ?></p><?php }?>
						<select id="<?php echo $this->slug;?>" class="form-control wpsc_priority" name="<?php echo $this->slug;?>">
							<?php
			 				$priorities = get_terms([
			 				  'taxonomy'   => 'wpsc_priorities',
			 				  'hide_empty' => false,
			 					'orderby'    => 'meta_value_num',
			 				  'order'    	 => 'ASC',
			 					'meta_query' => array('order_clause' => array('key' => 'wpsc_priority_load_order')),
			 				]);
			 				foreach ( $priorities as $priority ) :
			           $selected = $priority->term_id == $field_value ? 'selected="selected"' : '';
								 echo '<option '.$selected.' value="'.$priority->term_id.'">'.$priority->name.'</option>';
		          endforeach;
			         ?>
			      </select>
          </div>
          <?php
				}

        function print_ticket_description($field){
			global $current_user,$wpscfunction;
			$label = get_option('wpsc_custom_fields_localize');
			$extra_info = get_option('wpsc_custom_fields_extra_info');
			$field_value = get_term_meta($this->term_id,'ticket_description',true);
			$directionality = $wpscfunction->check_rtl();
			?>
          <div data-fieldtype="tinymce" class="form-group <?php echo $this->required? 'wpsc_required':''?>">
            <label class="wpsc_ct_field_label">
              <?php echo $label['custom_fields_'.$field->term_id]; ?> <?php echo $this->required? '<span style="color:red;">*</span>':'';?>
            </label>
						<?php if($extra_info['custom_fields_extra_info_'.$field->term_id]){?> <p class="help-block"><?php echo $extra_info['custom_fields_extra_info_'.$field->term_id]; ?></p><?php }?>
            <textarea id="<?php echo $this->slug;?>" class="form-control wpsc_description" name="<?php echo $this->slug;?>"><?php echo $field_value ?></textarea>
				  </div>
				<?php
					$rich_editing = $wpscfunction->rich_editing_status($current_user);
					if($rich_editing){ ?>
	  
          <script type="text/javascript">
          	tinymce.remove();
          	tinymce.init({
          	  selector:'#<?php echo $this->slug;?>',
				body_id: '<?php echo $this->slug;?>',
			  directionality : '<?php echo $directionality; ?>',
          	  menubar: false,
          	  height : '150',
          	  plugins: [
          	      'lists link image directionality'
          	  ],
          	  toolbar: 'bold italic underline blockquote | alignleft aligncenter alignright | bullist numlist | rtl | link image | wpsc_templates',
          	  branding: false,
          	  autoresize_bottom_margin: 20,
          	  browser_spellcheck : true,
          	  relative_urls : false,
          	  remove_script_host : false,
          	  convert_urls : true
          	});
					</script>
          <?php
		  }
        }
				
				function print_date_time($field){
					$label = get_option('wpsc_custom_fields_localize');
					$extra_info = get_option('wpsc_custom_fields_extra_info');
					$field_value = get_term_meta($this->term_id, $field->slug, true );
					?>
          <div class = "form-group">
            <label class="wpsc_ct_field_label" for="<?php echo $this->slug;?>">
              <?php echo $label['custom_fields_'.$field->term_id];?> <?php echo $this->required? '<span style="color:red;">*</span>':'';?>
            </label>
            <?php if($extra_info['custom_fields_extra_info_'.$field->term_id]){?><p class="help-block" style="<?php echo $extra_info_css?>"><?php echo $extra_info['custom_fields_extra_info_'.$field->term_id];?></p><?php }?>
            <input type="text" id="<?php echo $this->slug;?>" class="form-control wpsc_datetime" name="<?php echo $this->slug;?>" autocomplete="off" value="<?php echo $field_value; ?>">
          </div>
          <?php
				}                                           

			
			function print_time($field){
				global $wpscfunction;
				$label = get_option('wpsc_custom_fields_localize');
				$extra_info = get_option('wpsc_custom_fields_extra_info');
				$value = get_term_meta($this->term_id, $field->slug, true );
				$time_format = get_term_meta($field->term_id,'wpsc_time_format',true);
				$time = '';
				if( strlen($value) != 0 ){
					if($time_format == '12'){
						$time = date("h:i:s a", strtotime($value));
					}else{
						$time = $value;
					}
				}
				?>
				<div class="form-group">
					<label class="wpsc_ct_field_label" for="<?php echo $this->slug;?>">
					<?php echo $label['custom_fields_'.$field->term_id];?> 
					</label>
					<?php if($extra_info['custom_fields_extra_info_'.$field->term_id]){?><p class="help-block"><?php echo $extra_info['custom_fields_extra_info_'.$field->term_id];?></p><?php }?>
					<input type="text" id="<?php echo $this->slug;?>" onkeypress='return false' class="form-control <?php echo $this->slug;?>" name="<?php echo $this->slug;?>" autocomplete="off" value="<?php echo $time;?>">
				</div>
				<script type="text/javascript">
					jQuery(document).ready(function(){
						jQuery('.<?php echo $this->slug ?>').timepicker({
							<?php 
							if($time_format == '12'){
								?>
								timeFormat:'hh:mm:ss tt',
								<?php	
							}else{
								?>
								timeFormat:'HH:mm:ss'
								<?php
							}
							?>
						});	
					});
					
				</script>
				<?php
			}
		
		}


endif;
