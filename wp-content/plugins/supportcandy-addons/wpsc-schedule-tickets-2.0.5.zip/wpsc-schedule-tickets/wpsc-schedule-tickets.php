<?php
/**
 * Plugin Name: SupportCandy - Schedule Tickets
 * Plugin URI: https://supportcandy.net/
 * Description: Customers can scheduled tickets.
 * Version: 2.0.5
 * Author: Support Candy
 * Author URI: https://supportcandy.net/
 * Requires at least: 4.4
 * Tested up to: 4.9
 * Text Domain: wpsc-st
 * Domain Path: /lang
 */

 if ( ! defined( 'ABSPATH' ) ) {
 	exit; // Exit if accessed directly
 }

 if ( ! class_exists( 'Support_Candy_ST' ) ) :

   final class Support_Candy_ST {

     public $version = '2.0.5';

     public function __construct() {
       
       $this->define_constants();
       $this->includes();
       add_action( 'init', array($this,'load_textdomain') );
       
     }

     function define_constants() {
        define('WPSC_ST_PLUGIN_FILE', __FILE__);
        define('WPSC_ST_ABSPATH', dirname(__FILE__) . '/');
        define('WPSC_ST_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
        define('WPSC_ST_PLUGIN_BASENAME', plugin_basename(__FILE__));
 			  define('WPSC_ST_STORE_ID', '1658');
 			  define('WPSC_ST_VERSION', $this->version);
     }

     public function load_textdomain() {
       $locale = apply_filters( 'plugin_locale', get_locale(), 'wpsc-st' );
       load_textdomain( 'wpsc', WP_LANG_DIR . '/wpsc/wpsc-st-' . $locale . '.mo' );
       load_plugin_textdomain( 'wpsc-st', false, plugin_basename( dirname( __FILE__ ) ) . '/lang' );
     }

     public function includes() {

       include_once( WPSC_ST_ABSPATH . 'class-wpsc-st-install.php' );
       include_once( WPSC_ST_ABSPATH . 'class-wpsc-st.php' );

       $st = new WPSC_ST();

       // Setting
       add_action( 'wpsc_after_setting_pills', array($st,'st_setting_pill'));
       add_action( 'wp_ajax_wpsc_get_st_settings', array($st,'get_add_st_setting'));

       //Add Schedule Tickets
       add_action( 'wp_ajax_wpsc_get_add_new_schedule_ticket', array($st,'get_add_new_st_setting'));
       add_action( 'wp_ajax_wpsc_get_add_schedule_ticket_form_field', array($st,'get_add_new_st_form_field'));
       add_action( 'wp_ajax_wpsc_set_new_st_from_field', array($st,'set_new_st_from_field'));
       add_action( 'wp_ajax_wpsp_get_edit_schedule_ticket', array($st,'wpsp_get_edit_schedule_ticket'));
       add_action( 'wp_ajax_wpsc_set_edit_schedule_ticket', array($st,'wpsc_set_edit_schedule_ticket'));
       add_action( 'wp_ajax_wpsc_delete_schedule_ticket', array($st,'wpsc_delete_schedule_ticket'));
       add_action(  'wp_ajax_wpsc_clone_schedule_ticket',array($st,'wpsc_clone_schedule_ticket'));
       
      // Cron
 			add_action('wpsc_cron', array($st, 'st_cron'));
      
      add_filter('wpsc_ticket_thread_reply_source',array($st,'wpsc_ticket_thread_reply_source'),10,4);
      
      add_action( 'wpsc_after_indidual_ticket_action_btn', array($st,'wpsc_schedule_ticket_btn'));
      add_action( 'wp_ajax_wpsc_get_add_st_form', array($st,'wpsc_get_add_st_form'));
      add_action('wp_ajax_wpsc_set_schedule_ticket',array($st,'wpsc_set_schedule_ticket'));
      add_action('wp_ajax_wpsc_set_st_other_settings',array($st,'set_st_settings'));
      
      // License
      add_filter( 'wpsc_is_add_on_installed', array($st,'is_add_on_installed'));
      add_action( 'wpsc_addon_license_area', array($st,'addon_license_area'));
      add_action( 'wp_ajax_wpsc_st_activate_license', array($st,'license_activate'));
      add_action( 'wp_ajax_wpsc_st_deactivate_license', array($st,'license_deactivate'));
      add_action( 'admin_init', array($this, 'plugin_updator'));

     }
     
     private function define($name, $value) {
       if (!defined($name)) {
         define($name, $value);
       }
     }
 		
 		function plugin_updator(){
 			$license_key    = get_option('wpsc_st_license_key','');
 			$license_expiry = get_option('wpsc_st_license_expiry','');
 			if(class_exists('Support_candy') && $license_key && $license_expiry ) {
 				$edd_updater = new EDD_SL_Plugin_Updater( WPSC_STORE_URL, __FILE__, array(
 								'version' => WPSC_ST_VERSION,
 								'license' => $license_key,
 								'item_id' => WPSC_ST_STORE_ID,
 								'author'  => 'Pradeep Makone',
 								'url'     => site_url()
 				) );
 			}	
     }

   }

 endif;


 new Support_Candy_ST();
