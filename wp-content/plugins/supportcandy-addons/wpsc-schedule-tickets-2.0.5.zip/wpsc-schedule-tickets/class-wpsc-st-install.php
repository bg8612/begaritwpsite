<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if ( ! class_exists( 'WPSC_ST_Install' ) ) :
  
   final class WPSC_ST_Install {
     
     public function __construct() {
       add_action( 'init', array($this,'register_post_type'), 100 );
       $this->check_version();
     }
     
     // Register post types and texonomies
     public function register_post_type(){
       
       // Register rating texonomy
      $args = array(
           'public'             => false,
           'rewrite'            => false
       );
       register_taxonomy( 'wpsc_schedule_tickets', 'wpsc_ticket', $args );
     }
     
     /**
      * Check version of WPSC
      */
     public function check_version(){
         $installed_version = get_option( 'wpsc_st_current_version', 0 );
         if( $installed_version != WPSC_ST_VERSION ){
             add_action( 'init', array($this,'upgrade'), 101 );
         }
     }
     
     
     // Upgrade
 		public function upgrade(){
      
        $installed_version = get_option( 'wpsc_st_current_version', 0 );
        $installed_version = $installed_version ? $installed_version : 0;
        
        if ( $installed_version < '1.0.0' ) {
           
          $term = wp_insert_term( 'schedule_tickets', 'wpsc_ticket_custom_fields' );
					if (!is_wp_error($term) && isset($term['term_id'])) {
						add_term_meta ($term['term_id'], 'wpsc_tf_label', __('Schedule Tickets','wpsc-st'));
            add_term_meta ($term['term_id'], 'type','schedule_ticket');
					}
        }
        
        update_option( 'wpsc_st_current_version', WPSC_ST_VERSION );
    }
     
   }
  
endif;  

new WPSC_ST_Install();