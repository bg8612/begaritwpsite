<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if ( ! class_exists( 'WPSC_ST' ) ) :

  final class WPSC_ST {

    // Add new menu WPSC settings.
    function st_setting_pill(){
      include WPSC_ST_ABSPATH . 'includes/st_setting_pill.php';
    }

    //Add New Schedule Tickets
    function get_add_st_setting() {
      include WPSC_ST_ABSPATH . 'includes/get_add_st_setting.php';
      die();
    }

		function get_add_new_st_form_field() {
			include WPSC_ST_ABSPATH . 'includes/get_add_new_st_form_field.php';
      die();
		}

    function set_new_st_from_field() {
      include WPSC_ST_ABSPATH . 'includes/set_new_st_setting.php';
      die();
    }

		function wpsp_get_edit_schedule_ticket() {
			include WPSC_ST_ABSPATH . 'includes/get_edit_schedule_ticket.php';
      die();
		}

		function wpsc_set_edit_schedule_ticket() {
			include WPSC_ST_ABSPATH . 'includes/set_edit_schedule_ticket.php';
      die();
		}

		function wpsc_delete_schedule_ticket() {
			include WPSC_ST_ABSPATH . 'includes/delete_schedule_ticket.php';
      die();
		}

		function st_cron() {
			include WPSC_ST_ABSPATH . 'includes/st_cron.php';
		}
		
		// Add-on installed or not for licensing
		function is_add_on_installed($flag){
			return true;
		}
		
		// Print license functionlity for this add-on
		function addon_license_area(){
			include WPSC_ST_ABSPATH . 'includes/addon_license_area.php';
		}
		
		// Activate Schedule Tickets license
		function license_activate(){
			include WPSC_ST_ABSPATH . 'includes/license_activate.php';
      die();
		}
		
		// Deactivate Schedule Tickets license
		function license_deactivate(){
			include WPSC_ST_ABSPATH . 'includes/license_deactivate.php';
      die();
		}
		
		function wpsc_ticket_thread_reply_source($reply_type, $reply_source,$thread_id,$ticket_id){
			if ($reply_source == 'schedule_ticket') {
				 $reply_type = "Schedule Ticket" ;
			} 
			return $reply_type;
		}
		
		function wpsc_schedule_ticket_btn(){
			include WPSC_ST_ABSPATH . 'includes/get_add_st_btn.php';
		}
		
		function wpsc_get_add_st_form(){
			include WPSC_ST_ABSPATH . 'includes/get_add_st_form.php';
			die();
		}
		
		function wpsc_set_schedule_ticket(){
			include WPSC_ST_ABSPATH . 'includes/set_add_schedule_ticket.php';
			die();
		}
		
		function set_st_settings(){
			include WPSC_ST_ABSPATH . 'includes/set_st_other_settings.php';
			die();
		}
		
		function wpsc_clone_schedule_ticket(){
			include WPSC_ST_ABSPATH . 'includes/clone_schedule_ticket.php';
			die();
		}
  }
endif;
