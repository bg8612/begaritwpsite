function wpsc_get_agent_groups(){
  jQuery('.wpsc_setting_pills li').removeClass('active');
  jQuery('#wpsc_settings_agent_groups').addClass('active');
  
  var data = {
    action : 'wpsc_get_agent_groups'
  };

  jQuery.post(wpsc_admin.ajax_url, data, function(response) {
    jQuery('.wpsc_setting_col2').html(response);
  });
}

function wpsc_get_add_agent_settings(){
  var data = {
    action: 'wpsc_get_add_agent_settings'
  };
  jQuery.post(wpsc_admin.ajax_url, data, function(response_str) {
		jQuery('.wpsc_setting_col2').html(response_str);
  });
}

function wpsc_edit_agentgroup(agentgroup_id){
    var data = {
        'action':        'wpsc_edit_agentgroup',
        'agentgroup_id': agentgroup_id
    };

    jQuery.post(wpsc_admin.ajax_url, data, function(response_str) {
      jQuery('.wpsc_setting_col2').html(response_str);
    });
}



function wpsc_delete_agentgroup(agentgroup_id){
    if (confirm('Are you sure?')) {
        var data = {
            'action'       : 'wpsc_delete_agentgroup',
            'agentgroup_id':  agentgroup_id
        };

        jQuery.post(wpsc_admin.ajax_url, data, function(response_str) {
          jQuery('.wpsc_setting_col2').html(response_str);
          wpsc_get_agent_groups();
        });
    }
}

function wpsc_back_agentgroup_list(e){
    e.preventDefault();
    wpsc_get_agent_groups();
}