<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if ( ! class_exists( 'WPSC_Agentgroup_Install' ) ) :
  
  final class WPSC_Agentgroup_Install {
    
    public function __construct() {
      add_action( 'init', array($this,'register_post_type'), 100 );
    	$this->check_version();
    }
    
    // Register texonomies
    public function register_post_type(){
      
			// Register status taxonomy
			$args = array(
          'public'             => false,
          'rewrite'            => false
      );
      register_taxonomy( 'wpsc_agentgroup_data', 'wpsc_ticket', $args );
		}
		
		/**
    *  Check Version of AG
    */
    public function check_version() {
      $installed_version = get_option('wpsc_ag_current_version', 0 );
      if($installed_version!= WPSC_AGENTGROUP_VERSION){
        add_action('init', array($this, 'upgrade'), 101);
      }
    }
		
		// Upgrade
    public function upgrade() {
      
      $installed_version = get_option('wpsc_ag_current_version', 0 );
      $installed_version = $installed_version ? $installed_version : 0;
      
      if($installed_version < '1.0.5') {
				$agentgroups = get_terms([
					'taxonomy'   => 'wpsc_agents',
					'hide_empty' => false,
				  'meta_query' => array(
				    'relation' => 'AND',
				      array(
				        'key'     => 'agentgroup',
				        'value'   =>  1,
				        'compare' => '='
				      ),
				  ),
				]);
				
				foreach($agentgroups as $agentgroup){
			    $wpsc_agentgroup_userid = get_term_meta( $agentgroup->term_id, 'agentgroup_user_id');
					delete_term_meta($agentgroup->term_id, 'agentgroup_user_id');
					foreach ($wpsc_agentgroup_userid as $key => $id) {
						$user_term = get_term_by('slug','agent_'.$id,'wpsc_agents');
				    if($user_term)
				      add_term_meta ($agentgroup->term_id, 'agentgroup_user_id', $user_term->term_id);
					}
				}
			}
			
			update_option( 'wpsc_ag_current_version', WPSC_AGENTGROUP_VERSION );
		}
		
  }
endif;

new WPSC_Agentgroup_Install();