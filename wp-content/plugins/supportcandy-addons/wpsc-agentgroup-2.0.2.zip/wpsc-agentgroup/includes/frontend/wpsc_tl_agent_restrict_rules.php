<?php
if ( ! defined( 'ABSPATH' ) ) {
  exit; // Exit if accessed directly
}

global $current_user,$wpscfunction;
$agentgroups = get_terms([
	'taxonomy'   => 'wpsc_agents',
	'hide_empty' => false,
  'meta_query' => array(
    'relation' => 'AND',
      array(
        'key'     => 'agentgroup',
        'value'   =>  1,
        'compare' => '='
      ),
  ),
]);

$agent_permissions = $wpscfunction->get_current_agent_permissions();
foreach($agentgroups as $agentgroup){
    $wpsc_agentgroup_userid = get_term_meta( $agentgroup->term_id, 'agentgroup_user_id');
    $user_term = get_term_by('slug','agent_'.$current_user->ID,'wpsc_agents');
    if(in_array($user_term->term_id, $wpsc_agentgroup_userid)){
        if ($agent_permissions['view_assigned_me']) {
            $restrict_rules[] = array(
        			'key'            => 'assigned_agent',
        			'value'          => $agentgroup->term_id,
        			'compare'        => '='
        		);
        }
    }
}

