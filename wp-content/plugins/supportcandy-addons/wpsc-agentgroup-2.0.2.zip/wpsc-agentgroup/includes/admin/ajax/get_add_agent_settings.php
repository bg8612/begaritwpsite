<?php
if ( ! defined( 'ABSPATH' ) )
    exit; // Exit if accessed directly
?>
<div id="tab_container" style="clear: both;">

    <div class="wpsp_company_setting_div">

        <form id="wpsc_frm_get_add_agent_settings" method="post">

            <h3><?php echo __('Add New Agentgroup','wpsc-agentgroup') ?></h3>
            <hr>

            <table class="table table-striped table-hover">
								<tr>
                    <th><?php _e('Title','wpsc-agentgroup');?>:</th>
                    <td><input type="text" id="wpsp_add_usergroup_name" name="wpsp_agentgroup_name"></td>
                </tr>
                <tr>
                    <th><?php _e('Add Agent','wpsc-agentgroup');?>:</th>
                    <td>
                      <input id="agentgroup_agents" class="form-control form-control wpsc_agentegroup_agents ui-autocomplete-input" name="usergroup_users" type="text" autocomplete="off" placeholder="<?php _e('Search Agents ...','wpsc-agentgroup')?>" />
                      <ui class="wpsp_filter_display_container"></ui>
                    </td>
                </tr>
                <tr>
                    <th><?php _e('Agents','wpsc-agentgroup');?>:</th>
                    <td>
                        <table id="wpsp_company_selected_users">
                            <thead>
                                <tr>
                                    <th><?php _e('Name','wpsc-agentgroup');?></th>
                                    <th style="width: 50px;"><?php _e('Action','wpsc-agentgroup');?></th>
                                </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </table>
            <input type="hidden" name="action" value="wpsc_set_add_agent_settings" />
            <button type="submit" id="wpsc_back_agentgroup_list_sub_btn" onclick="set_add_agent_settings(event);" class="btn btn-success"><?php _e('Save Changes','wpsc-agentgroup');?></button>
            <button class="btn btn-success" id="wpsc_back_agentgroup_list_can_btn" onclick="wpsc_back_agentgroup_list(event);"><?php _e('Cancel','wpsc-agentgroup');?></button>
            <img class="wpsc_submit_wait" style="display:none;" src="<?php echo WPSC_PLUGIN_URL.'asset/images/ajax-loader@2x.gif';?>">
        </form>
    </div>
</div>

<script>
jQuery(document).ready(function(){
	
  	jQuery( ".wpsc_agentegroup_agents" ).autocomplete({
  			minLength: 1,
  			appendTo: jQuery('.wpsc_agentegroup_agents').parent(),
  			source: function( request, response ) {
  				var term = request.term;
  				request = {
  					'action' : 'wpsc_filter_autocomplete',
             term    :  term
					}
  				jQuery.getJSON( wpsc_admin.ajax_url, request, function( data, status, xhr ) {
  					response( data );
  				});
  			},
  			select: function (event, ui) {
          if(ui.item.label=='No matching users'){
            return;
          }
          var html_str = "<tr><td>"+ ui.item.label + "</td>"
          +"<input type='hidden' name='user_id[]' value='"+ ui.item.id +"'/>"+
                        "<td><span class='delete-row'>Remove</span></td></tr>";
  				jQuery("#wpsp_company_selected_users tbody").append(html_str);
  			  jQuery(this).val(''); return false;
  				}		
  	});
  
    jQuery(document).on('click', '.delete-row', function () {
        jQuery(this).closest("tr").remove();

    });
});

function set_add_agent_settings(e){
  e.preventDefault();
  if (jQuery('#wpsp_add_usergroup_name').val() == ""){
    alert("<?php _e('Please enter title!','wpsc-agentgroup')?>");
    return;
  }
  var rows= jQuery('#wpsp_company_selected_users tbody tr').length;
  if(rows==0){
    alert("<?php _e('Please select at least one user!','wpsc-agentgroup')?>");
    return;
  }
  jQuery('.wpsc_submit_wait').show();
    var dataform = new FormData(jQuery('#wpsc_frm_get_add_agent_settings')[0]);
    jQuery.ajax({
      url: wpsc_admin.ajax_url,
      type: 'POST',
      data: dataform,
      processData: false,
      contentType: false
    })
    .done(function (response_str) {
       var response = JSON.parse(response_str);
       jQuery('.wpsc_submit_wait').hide();
       jQuery('#wpsc_alert_success .wpsc_alert_text').text(response.messege);
       jQuery('#wpsc_alert_success').slideDown('fast',function(){});
       setTimeout(function(){ jQuery('#wpsc_alert_success').slideUp('fast',function(){}); }, 3000);
       wpsc_get_agent_groups();
    });  
}
</script>