<?php
if ( ! defined( 'ABSPATH' ) )
      exit; // Exit if accessed directly
?>
<?php 
$agentgroups = get_terms([
	'taxonomy'    => 'wpsc_agents',
	'hide_empty'  => false,
  'meta_query' => array(
    'relation' => 'AND',
      array(
        'key'     => 'agentgroup',
        'value'   => 1,
        'compare' => '='
      ),
  ),
]);
?>
<div style="clear: both; text-align: right;padding: 5px 0;">
<button class="btn btn-success" id="wpsc_add_agent_settings_addon_btn" onclick="wpsc_get_add_agent_settings();"><?php _e('+ Add New','wpsc-usergroup');?></button>
</div>

<div id="tab_container">

    <form method="post" action="">
        <table class="table table-striped table-hover">
            <thead>
                <tr>
                    <th><?php _e('Tittle','wpsc-agentgroup');?></th>
                    <th><?php _e('Agent Name','wpsc-agentgroup');?></th>
                    <th><?php _e('Action','wpsc-agentgroup');?></th>
                </tr>
            </thead>
            <?php 
            if($agentgroups){
                $count=0;
                foreach ($agentgroups as $agentgroup){
                  $wpsc_agentgroup_user_id = get_term_meta( $agentgroup->term_id, 'agentgroup_user_id');
                  $agents                  = implode(",",$wpsc_agentgroup_user_id);
                  $agent_explode           = explode(",",$agents);
                  $name                    = array();
                  if($wpsc_agentgroup_user_id){
                      foreach($agent_explode as $agent){
                        $user_id = get_term_meta($agent,'user_id',true);
                        if($user_id){
                          $user_data = get_userdata($user_id);
                          $name[]    = $user_data->display_name;
                        }
                        
                      }
                  }
                  $agent_name = implode(", ",$name);
                    ?>
                    <tr>
                        <td><img style="width:20px" src="<?php echo WPSC_AGENTGROUP_URL.'asset/images/agentgroup.png'?>"> <?php echo $agentgroup->name; ?></td>
                        <td><?php echo $agent_name; ?></td>
                        <td>
                          <span class="dashicons dashicons-edit wpsp_pointer" onclick="wpsc_edit_agentgroup(<?php echo $agentgroup->term_id; ?>);"></span>
                          <span class="dashicons dashicons-trash wpsp_pointer" onclick="wpsc_delete_agentgroup(<?php echo $agentgroup->term_id; ?>);"></span>
                        </td>
                    </tr>
                    <?php
                  }
            }else{
                echo '<tr><td colspan="4">No records found.</td></tr>';
            }
            ?>
          </table>
    </form>
</div>
