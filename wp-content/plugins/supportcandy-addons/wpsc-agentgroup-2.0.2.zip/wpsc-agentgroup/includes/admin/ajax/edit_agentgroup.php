<?php
if ( ! defined( 'ABSPATH' ) )
      exit; // Exit if accessed directly
?>
<?php 
$agentgroup_id = isset($_POST) && isset($_POST['agentgroup_id']) ? intval($_POST['agentgroup_id']) : 0;
$agentgroup    = get_term_by('id', $agentgroup_id, 'wpsc_agents');
?>
<div id="wpsc_alert_success" class="alert alert-success wpsc_alert" style="display:none;" role="alert">
    <i class="fa fa-check-circle"></i> <span class="wpsc_alert_text"></span>
</div>
<br>
<div id="tab_container" style="clear: both;">

    <div class="wpsp_company_setting_div">

        <form id="wpsc_frm_update_agentgroup_settings" method="post">

            <h3><?php echo __('Update Agentgroup','wpsc-agentgroup') ?></h3>
            <hr>
            <table class="table table-striped table-hover">

                <tr>
                    <th><?php _e('Title','wpsc-agentgroup');?>:</th>
                    <td><input type="text" id="wpsp_agentgroup_name" name="wpsp_agentgroup_name" value="<?php echo $agentgroup->name; ?>"></td>
                </tr>

                <tr>
                    <th><?php _e('Add Agent','wpsc-agentgroup');?>:</th>
                    <td>
                      <input id="usergroup_users" class="form-control form-control wpsc_usergroup_users ui-autocomplete-input" type="text" autocomplete="off" placeholder="<?php _e('Search Agents ...','wpsc-agentgroup')?>" />
                      <ui class="wpsp_filter_display_container"></ui>
                    </td>
                </tr>

                <tr>
                    <th><?php _e('Agents','wpsc-agentgroup');?>:</th>
                    <td>
                        <?php
                        ?>
                        <table id="wpsp_company_selected_users">
                            <thead>
                                <tr>
                                  <th><?php _e('Name','wpsc-agentgroup');?></th>
                                  <th style="width: 50px;"><?php _e('Action','wpsc-agentgroup');?></th>
                                </tr>
                            </thead>
                            <tbody>
                              <?php
                                $wpsc_agentgroup_agents     = get_term_meta( $agentgroup->term_id, 'agentgroup_user_id');
                                foreach ($wpsc_agentgroup_agents as $userid){
                                    $name = '';
                                    $user_id = get_term_meta($userid,'user_id',true);
                                    if($user_id){
                                      $user_data = get_userdata($user_id);
                                      $name      = $user_data->display_name;
                                    }
                                    echo "<tr><td>" . $name . "</td>".
                                            "<input type='hidden' name='user_id[]' value='".$user_id."'/>".
                                            "<td><span class='delete-row'>Remove</span></td></tr>";
                                }
                              ?>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </table>
            <input type="hidden" name="agentgroup_id" value="<?php echo $agentgroup->term_id ?>" />
            <input type="hidden" name="action" value="wpsc_set_update_agentgroup" />
            <button type="submit" onclick="set_update_agentgroup(event);" class="btn btn-success"><?php _e('Save Changes','wpsc-agentgroup');?></button>
            <button class="btn btn-success" onclick="wpsc_back_agentgroup_list(event);"><?php _e('Cancel','wpsc-agentgroup');?></button>
            <img class="wpsc_submit_wait" style="display:none;" src="<?php echo WPSC_PLUGIN_URL.'asset/images/ajax-loader@2x.gif';?>">
        </form>
    </div>
</div>

<script>
jQuery(document).ready(function(){
    jQuery( ".wpsc_usergroup_users" ).autocomplete({
  			minLength: 1,
  			appendTo: jQuery('.wpsc_usergroup_users').parent(),
  			source: function( request, response ) {
  				var term = request.term;
  				request = {
  					'action' : 'wpsc_filter_autocomplete',
             term    :  term
  				}
  				jQuery.getJSON( wpsc_admin.ajax_url, request, function( data, status, xhr ) {
  					response( data );
  				});
  			},
  			select: function (event, ui) {
          if(ui.item.label=='No matching users'){
            return;
          }
          var html_str = "<tr><td>" + ui.item.label + "</td>"+
                         "<input type='hidden' name='user_id[]' value='"+ui.item.id+"'/>"+
                         "<td><span class='delete-row'>Remove</span></td></tr>";
  				jQuery("#wpsp_company_selected_users tbody").append(html_str);
  			  jQuery(this).val(''); return false;
  			}		
  	});

    jQuery(document).on('click', '.delete-row', function () {
        jQuery(this).closest("tr").remove();

    });

});

function set_update_agentgroup(e){
    e.preventDefault();
    if (jQuery('#wpsp_agentgroup_name').val() == ""){
      alert("<?php _e('Please enter title!','wpsc-agentgroup')?>");
      return;
    }
    var rows= jQuery('#wpsp_company_selected_users tbody tr').length;
    if(rows==0){
      alert("<?php _e('Please select at least one user!','wpsc-agentgroup')?>");
      return;
    }
    jQuery('.wpsc_submit_wait').show();
    var dataform = new FormData(jQuery('#wpsc_frm_update_agentgroup_settings')[0]);
    
    jQuery.ajax({
      url: wpsc_admin.ajax_url,
      type: 'POST',
      data: dataform,
      processData: false,
      contentType: false
    })
    .done(function (response_str) {
      var response = JSON.parse(response_str);
      jQuery('.wpsc_submit_wait').hide();
      jQuery('#wpsc_alert_success .wpsc_alert_text').text(response.messege);
      jQuery('#wpsc_alert_success').slideDown('fast',function(){});
      setTimeout(function(){ jQuery('#wpsc_alert_success').slideUp('fast',function(){}); }, 3000);
      wpsc_get_agent_groups();
    });
}
</script>