<?php
if ( ! defined( 'ABSPATH' ) )
    exit; // Exit if accessed directly
?>
<?php
global $current_user;
if (!($current_user->ID && $current_user->has_cap('manage_options'))) 
{exit;}

$agentgroup_name = isset($_POST['wpsp_agentgroup_name']) ? sanitize_text_field($_POST['wpsp_agentgroup_name']) : '';
$user_id         = isset($_POST['user_id']) ? $_POST['user_id'] : array();
 
$term = wp_insert_term( $agentgroup_name, 'wpsc_agents' );
if (!is_wp_error($term) && isset($term['term_id'])) {
  add_term_meta ($term['term_id'], 'label', $agentgroup_name);
  add_term_meta ($term['term_id'], 'agentgroup', 1);
  foreach($user_id as $id){
    $user_term = get_term_by('slug','agent_'.$id,'wpsc_agents');
    if($user_term)
      add_term_meta ($term['term_id'], 'agentgroup_user_id', $user_term->term_id);
  }
  $response = array(
    'messege' => __('Setting saved!','wpsc-agentgroup'),
  );
  echo json_encode( $response );
}
