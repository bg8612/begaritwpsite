<?php
if ( ! defined( 'ABSPATH' ) )
    exit; // Exit if accessed directly
?>
<?php
global $current_user;
if (!($current_user->ID && $current_user->has_cap('manage_options'))) 
{exit;}
$wpsp_agentgroup_name = isset($_POST['wpsp_agentgroup_name']) ? sanitize_text_field($_POST['wpsp_agentgroup_name']) : '';
$user_id              = isset($_POST['user_id']) ? $_POST['user_id'] : array();
if(!$user_id) exit;
$term_id = isset($_POST) && isset($_POST['agentgroup_id']) ? intval($_POST['agentgroup_id']) : 0;
if(!$term_id) exit;

wp_update_term($term_id, 'wpsc_agents', array('name' => $wpsp_agentgroup_name));

if (isset($_POST['agentgroup_id'])) {
  delete_term_meta($term_id, 'agentgroup_user_id');
  update_term_meta ($term_id, 'label', $wpsp_agentgroup_name);
  foreach($user_id as $id){
    $user_term = get_term_by('slug','agent_'.$id,'wpsc_agents');
    if($user_term)
      add_term_meta ($term_id, 'agentgroup_user_id', $user_term->term_id);
  }
  $response = array(
    'messege' => __('Setting saved!','wpsc-agentgroup'),
  );
  echo json_encode( $response );
}
