<?php
if ( ! defined( 'ABSPATH' ) )
    exit; // Exit if accessed directly
?>
<?php
wp_delete_term($_POST['agentgroup_id'], 'wpsc_agents');