<?php
if ( ! defined( 'ABSPATH' ) ) {
  exit; // Exit if accessed directly
}

// $mine_decrease_flag,$ticket_id,$agent,$user_id,$prev_assigned,$event

foreach ($prev_assigned as $agent_id) {
  $agentgroup_flag = get_term_meta($agent_id,'agentgroup',true);
  if($agentgroup_flag){
    $agentgroup_agent_ids = get_term_meta($agent_id,'agentgroup_user_id');
    if(in_array($user_id, $agentgroup_agent_ids)){
      $mine_decrease_flag = true;
      break;
    }
  }
}
