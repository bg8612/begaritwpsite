<?php
if ( ! defined( 'ABSPATH' ) ) {
  exit; // Exit if accessed directly
}
global $wpscfunction;

$assigned_agents = $wpscfunction->get_ticket_meta($ticket_id,'assigned_agent');

foreach ($assigned_agents as $agent_id) {
  $agentgroup_flag = get_term_meta($agent_id,'agentgroup',true);
  if($agentgroup_flag){
    $agentgroup_agent_ids = get_term_meta($agent_id,'agentgroup_user_id');
    if(in_array($user_id, $agentgroup_agent_ids)){
      $mine_increase_flag = true;
      break;
    }
  }
}
