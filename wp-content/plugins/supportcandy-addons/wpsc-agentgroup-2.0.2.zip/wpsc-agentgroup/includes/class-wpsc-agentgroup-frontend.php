<?php
if ( ! defined( 'ABSPATH' ) ) {
  exit; // Exit if accessed directly
}

if ( ! class_exists( 'WPSC_Agentgroup_Frontend' ) ) :
  
  final class WPSC_Agentgroup_Frontend {
    
    function wpsc_tl_agent_restrict_rules($restrict_rules){
      include_once( WPSC_AGENTGROUP_ABSPATH . 'includes/frontend/wpsc_tl_agent_restrict_rules.php' );
      return $restrict_rules;
    }
      
    function wpsc_agent_name_in_individual_ticket($agent){
      $user            = get_term_meta($agent);
      if($user){
		    $agentgroup_name = $user['label'][0];
				?>
				<td style="width:25px !important;">
          <div style="padding:2px 0;">
            <img style="width:20px" src="<?php echo WPSC_AGENTGROUP_URL.'asset/images/agentgroup.png'?>">
            <?php echo $agentgroup_name?>
          </div>
        </td>
  			<?php
      }
		}
      
    function wpsc_get_assigned_agent_emails($agent_emails,$ticket_id){
      global $wpscfunction;
      
      $agentgroup_emails = array();
      
      $assigned_agents = $wpscfunction->get_ticket_meta($ticket_id,'assigned_agent');
      
      foreach ($assigned_agents as $key => $value) {
        $agent_group = get_term_by( 'id', $value ,'wpsc_agents' );
        if($agent_group){
          $is_group = get_term_meta ($agent_group->term_id, 'agentgroup',true);
          if($is_group){
            $agentgroup_user_id = get_term_meta( $agent_group->term_id, 'agentgroup_user_id');
            foreach($agentgroup_user_id as $agent_id){
              $user_id             = get_term_meta( $agent_id, 'user_id', true);
              $user                = get_user_by('id',$user_id);
              $agentgroup_emails[] = $user->user_email;
            }
          }
        }
      }
      
      $agent_emails = array_merge($agentgroup_emails,$agent_emails);
      return array_unique($agent_emails);
    }
      
    function wpsc_agent_has_permission($response, $permission, $ticket_id){
      global $current_user,$wpscfunction;
      $agent_permissions = $wpscfunction->get_current_agent_permissions();
      $assigned_agents_ticket = $wpscfunction->get_ticket_meta($ticket_id,'assigned_agent');
      $current_user_term = get_term_by('slug','agent_'.$current_user->ID,'wpsc_agents');
        
      $assigned_agents = $assigned_agents_ticket;
      if($assigned_agents_ticket){
        foreach ($assigned_agents_ticket as $key => $agent_id) {
          $agentgroup    = get_term_by('id', $agent_id, 'wpsc_agents');
          if($agentgroup){
            $group_user_ids = get_term_meta($agentgroup->term_id,'agentgroup_user_id');
            $assigned_agents = array_merge($assigned_agents,$group_user_ids);
          }
        }
        switch ($permission) {
          case 'view_unassigned':
          case 'assign_unassigned':
          case 'reply_unassigned':
          case 'cng_tkt_sts_unassigned':
          case 'cng_tkt_field_unassigned':
          case 'cng_tkt_ao_unassigned':
          case 'cng_tkt_rb_unassigned':
          case 'delete_unassigned':
          case 'view_unassigned_private_note':
            $response = ($agent_permissions[$permission] && in_array(0,$assigned_agents)) ? true : false;
            break;
                  
          case 'view_assigned_me':
          case 'assign_assigned_me':
          case 'reply_assigned_me':
          case 'cng_tkt_sts_assigned_me':
          case 'cng_tkt_field_assigned_me':
          case 'cng_tkt_ao_assigned_me':
          case 'cng_tkt_rb_assigned_me':
          case 'delete_assigned_me':
          case 'view_assigned_me_private_note':
            $response = ($agent_permissions[$permission] && in_array($current_user_term->term_id,$assigned_agents)) ? true : false;
            break;
                  
          case 'view_assigned_others':
          case 'assign_assigned_others':
          case 'reply_assigned_others':
          case 'cng_tkt_sts_assigned_others':
          case 'cng_tkt_field_assigned_others':
          case 'cng_tkt_ao_assigned_others':
          case 'cng_tkt_rb_assigned_others':
          case 'delete_assigned_others':
          case 'view_assigned_others_private_note':
            $response = ($agent_permissions[$permission] && !in_array($current_user_term->term_id,$assigned_agents) && !in_array(0,$assigned_agents)) ? true : false;
            break;
          }
        }
        
        return $response;
    }
    
    function agents_tickets_in_agentgroups($query,$label_key){
      include WPSC_AGENTGROUP_ABSPATH . 'includes/admin/agents_tickets_in_agentgroups.php';
      return $query;
    }
  }
  
endif;
