<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if ( ! class_exists( 'WPSC_Agentgroup_Ajax' ) ) :
    
    /**
     * Ajax class for WPSC.
     * @class WPSC_Usergroup_Ajax
     */
    class WPSC_Agentgroup_Ajax {
        
        /**
         * Constructor
         */
        public function __construct(){
            
						$ajax_events = array(
							'get_agent_groups'       => false,
							'get_add_agent_settings' => false,
							'filter_autocomplete'    => false,
							'set_add_agent_settings' => false,
							'edit_agentgroup'        => false,
							'delete_agentgroup'      => false,
							'set_update_agentgroup'  => false
						);
            
            foreach ($ajax_events as $ajax_event => $nopriv) {
								add_action('wp_ajax_wpsc_' . $ajax_event, array($this, $ajax_event));
                if ($nopriv) {
                    add_action('wp_ajax_nopriv_wpsc_' . $ajax_event, array($this, $ajax_event));
                }
            }
        }
        
        /**
         * Tickets ajax
         */
				 public function get_agent_groups(){
           include WPSC_AGENTGROUP_ABSPATH . 'includes/admin/ajax/get_agent_groups.php';
           die();
         }
				 
				 public function get_add_agent_settings(){
           include WPSC_AGENTGROUP_ABSPATH . 'includes/admin/ajax/get_add_agent_settings.php';
           die();
         }
				 
				 public function filter_autocomplete(){
           include WPSC_AGENTGROUP_ABSPATH . 'includes/admin/ajax/filter_autocomplete.php';
           die();
         }
				 
				 public function set_add_agent_settings(){
           include WPSC_AGENTGROUP_ABSPATH . 'includes/admin/ajax/set_add_agent_settings.php';
           die();
         }
				 
				 public function edit_agentgroup(){
           include WPSC_AGENTGROUP_ABSPATH . 'includes/admin/ajax/edit_agentgroup.php';
           die();
         }
				 
				 public function delete_agentgroup(){
           include WPSC_AGENTGROUP_ABSPATH . 'includes/admin/ajax/delete_agentgroup.php';
           die();
         }
				 
				 public function set_update_agentgroup(){
           include WPSC_AGENTGROUP_ABSPATH . 'includes/admin/ajax/set_update_agentgroup.php';
           die();
         }
		}
    
endif;

new WPSC_Agentgroup_Ajax();
