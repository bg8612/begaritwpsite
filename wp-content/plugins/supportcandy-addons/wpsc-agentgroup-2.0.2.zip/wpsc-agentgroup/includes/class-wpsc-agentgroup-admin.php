<?php
if ( ! defined( 'ABSPATH' ) ) {
  exit; // Exit if accessed directly
}

if ( ! class_exists( 'WPSC_Agentgroup_Admin' ) ) :
  
  final class WPSC_Agentgroup_Admin {
    
    public function __construct() {
      add_action( 'admin_enqueue_scripts', array( $this, 'loadScripts') );
    }
    
    // Load admin scripts
    public function loadScripts(){
       wp_enqueue_script('jquery');
       wp_enqueue_script('jquery-ui-core');
       wp_enqueue_script('wpsc_agentgroup_admin', WPSC_AGENTGROUP_URL.'asset/js/admin.js?version='.WPSC_AGENTGROUP_VERSION, array('jquery'), null, true);
       wp_enqueue_style('wpsc_agentgroup_admin', WPSC_AGENTGROUP_URL . 'asset/css/admin.css?version='.WPSC_AGENTGROUP_VERSION );
      
      $loading_html         = '<div class="wpsc_loading_icon"><img src="'.WPSC_PLUGIN_URL.'asset/images/ajax-loader@2x.gif"></div>';
      $localize_script_data = apply_filters( 'wpsc_admin_localize_script', array(
          'ajax_url'          => admin_url( 'admin-ajax.php' ),
          'loading_html'      => $loading_html,
      ));
      wp_localize_script( 'wpsc_agentgroup_admin', 'wpsc_agentgroup_data', $localize_script_data );
    }
    
    function wpsc_after_support_agent_pills(){
      ?>
      <li id="wpsc_settings_agent_groups" role="presentation"><a href="javascript:wpsc_get_agent_groups();"><?php _e('Agentgroup','wpsc-agentgroup');?></a></li>
      <?php
    }
    
    function is_add_on_installed($flag){
			return true;
		}
		
		// Print license functionlity for this add-on
		function addon_license_area(){
			include WPSC_AGENTGROUP_ABSPATH . 'includes/addon_license_area.php';
		}
		
		// Activate SLA license
		function license_activate(){
			include WPSC_AGENTGROUP_ABSPATH . 'includes/license_activate.php';
      die();
		}
		
		// Deactivate SLA license
		function license_deactivate(){
			include WPSC_AGENTGROUP_ABSPATH . 'includes/license_deactivate.php';
      die();
		}
    
    function unresolved_count_decrease($mine_decrease_flag,$ticket_id,$agent,$user_id,$prev_assigned,$event){
      if(!$mine_decrease_flag){
        include WPSC_AGENTGROUP_ABSPATH . 'includes/admin/unresolved_count_decrease.php';
      }
      return $mine_decrease_flag;
    }
    
    function unresolved_count_increase($mine_increase_flag,$ticket_id,$agent,$user_id,$new_assigned,$event){
      if(!$mine_increase_flag){
        include WPSC_AGENTGROUP_ABSPATH . 'includes/admin/unresolved_count_increase.php';
      }
      return $mine_increase_flag;
    }
    
  }
  
endif;