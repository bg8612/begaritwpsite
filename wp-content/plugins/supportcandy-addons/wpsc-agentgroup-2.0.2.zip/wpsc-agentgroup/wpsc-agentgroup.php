<?php 
/**
 * Plugin Name: SupportCandy - Agentgroup
 * Plugin URI: https://www.supportcandy.net/
 * Description: Agentgroup add-on for SupportCandy
 * Version: 2.0.2
 * Author: Support Candy
 * Author URI: https://www.supportcandy.net/
 * Text Domain: wpsc-agentgroup
 * Domain Path: /lang
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

final class WPSC_AGENTGROUP {
	
		public $version = '2.0.2';
		
		public function __construct() {
				
				$this->define_constants();
				$this->includes();
				add_action( 'init', array($this,'load_textdomain') );
				
		}
		
		function define_constants() {
				$this->define('WPSC_AGENTGROUP_FILE', __FILE__);
				$this->define('WPSC_AGENTGROUP_ABSPATH', dirname(__FILE__) . '/');
				$this->define('WPSC_AGENTGROUP_URL', plugin_dir_url( __FILE__ ) );
				$this->define('WPSC_AGENTGROUP_BASENAME', plugin_basename(__FILE__));
				$this->define('WPSC_AGENTGROUP_STORE_ID', '203');
				$this->define('WPSC_AGENTGROUP_VERSION', $this->version);
		}
		
		function load_textdomain(){
				$locale = apply_filters( 'plugin_locale', get_locale(), 'wpsc-agentgroup' );
				load_textdomain( 'wpsc-agentgroup', WP_LANG_DIR . '/wpsc/wpsc-agentgroup-' . $locale . '.mo' );
				load_plugin_textdomain( 'wpsc-agentgroup', false, plugin_basename( dirname( __FILE__ ) ) . '/lang' );
		}
		
		public function includes() {
			
				include_once( WPSC_AGENTGROUP_ABSPATH . 'includes/class-wpsc-agentgroup-install.php' );
				include_once( WPSC_AGENTGROUP_ABSPATH . 'includes/class-wpsc-agentgroup_ajax.php' );
				include_once( WPSC_AGENTGROUP_ABSPATH . 'includes/class-wpsc-agentgroup-admin.php' );
				include_once( WPSC_AGENTGROUP_ABSPATH . 'includes/class-wpsc-agentgroup-frontend.php' );
				
				$admin    = new WPSC_Agentgroup_Admin();
				$frontend = new WPSC_Agentgroup_Frontend();
				
				add_action('wpsc_after_support_agent_pills', array($admin,'wpsc_after_support_agent_pills'));
				add_filter('wpsc_tl_agent_restrict_rules', array($frontend, 'wpsc_tl_agent_restrict_rules'), 10, 1 );
				add_action('wpsc_agent_name_in_individual_ticket', array($frontend,'wpsc_agent_name_in_individual_ticket'), 10, 1);
				add_filter('wpsc_get_assigned_agent_emails', array($frontend, 'wpsc_get_assigned_agent_emails'), 10, 2 );
				add_filter('wpsc_agent_has_permission', array($frontend, 'wpsc_agent_has_permission'), 10, 3 );
				
				// Label Count
				add_filter('wpsc_unresolved_count_decrease', array($admin, 'unresolved_count_decrease'), 10, 6 );
				add_filter('wpsc_unresolved_count_increase', array($admin, 'unresolved_count_increase'), 10, 6 );
				
				//add_filter('wpsc_filter_label_mine',array($frontend,'agents_tickets_in_agentgroups'),10,2);
				
				// License
				add_filter( 'wpsc_is_add_on_installed', array($admin,'is_add_on_installed'));
				add_action( 'wpsc_addon_license_area', array($admin,'addon_license_area'));
				add_action( 'wp_ajax_wpsc_agentgroup_activate_license', array($admin,'license_activate'));
				add_action( 'wp_ajax_wpsc_agentgroup_deactivate_license', array($admin,'license_deactivate'));
				add_action( 'admin_init', array($this, 'plugin_updator'));
		}
		
		private function define($name, $value) {
				if (!defined($name)) {
						define($name, $value);
				}
		}
		
		function plugin_updator(){
			$license_key    = get_option('wpsc_agentgroup_license_key','');
			$license_expiry = get_option('wpsc_agentgroup_license_expiry','');
			if ( class_exists('Support_Candy') && $license_key && $license_expiry ) {
				$edd_updater = new EDD_SL_Plugin_Updater( WPSC_STORE_URL, __FILE__, array(
								'version' => WPSC_AGENTGROUP_VERSION,
								'license' => $license_key,
								'item_id' => WPSC_AGENTGROUP_STORE_ID,
								'author'  => 'Pradeep Makone',
								'url'     => site_url()
				) );
			}	
    }
		
		private function is_request($type) {
				switch ($type) {
						case 'admin' :
								return is_admin();
						case 'frontend' :
								return (!is_admin() || defined('DOING_AJAX') ) && !defined('DOING_CRON');
				}
		}
}

new WPSC_AGENTGROUP();
