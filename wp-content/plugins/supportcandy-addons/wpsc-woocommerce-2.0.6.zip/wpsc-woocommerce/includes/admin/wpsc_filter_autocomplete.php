<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
//$output,$term,$field_slug
if ($field_slug == 'id') {
	$field_slug = 'ticket_id';
}

$custom_field = get_term_by('slug', $field_slug, 'wpsc_ticket_custom_fields');

$type = get_term_meta( $custom_field->term_id, 'wpsc_tf_type', true);
if($type == "11"){
  $products = get_posts([
    'post_type'  => 'product',
    'hide_empty' => false,
    's'          => $term,
  ]);
  foreach($products as $product){
    $output[] = array(
      'label'    => $product->post_title,
      'value'    => '',
      'flag_val' => $product->ID,
      'slug'     => $field_slug,
    );
  }
}
