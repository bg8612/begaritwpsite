<?php 

global $wpdb,$current_user,$wpscfunction;

$type = get_term_meta( $field->term_id, 'wpsc_tf_type', true);

if( $type == 11 ){
  $wpscfunction->delete_ticket_meta($ticket_id,$field->slug);
  $field_val = get_term_meta($rule->term_id, $field->slug, true );
  $field_val = $field_val ? $field_val : '';
  $wpscfunction->add_ticket_meta($ticket_id,$field->slug,$field_val);
}