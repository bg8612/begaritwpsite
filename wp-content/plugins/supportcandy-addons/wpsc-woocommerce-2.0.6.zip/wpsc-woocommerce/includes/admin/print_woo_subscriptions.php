<?php 
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $current_user, $wpscfunction;
$role_id    = get_user_option('wpsc_agent_role');
$ticket_widgets = get_terms([
		'taxonomy'   => 'wpsc_ticket_widget',
		'hide_empty' => false,
	  'orderby'    => 'meta_value_num',
	  'order'    	 => 'ASC',
	  'meta_query' => array('order_clause' => array('key' => 'wpsc_ticket_widget_load_order')),
]);
$wpsc_appearance_individual_ticket_page = get_option('wpsc_individual_ticket_page');

$wpsc_ticket_widget_type = get_term_meta( $ticket_widget->term_id, 'wpsc_ticket_widget_type', true);
$wpsc_ticket_widget_role = get_term_meta( $ticket_widget->term_id, 'wpsc_ticket_widget_role', true);
$wpsc_custom_widget_localize = get_option('wpsc_custom_widget_localize');
$ticket_widget_name = $wpsc_custom_widget_localize['custom_widget_'.$ticket_widget->term_id];

if($wpsc_ticket_widget_type && (in_array($role_id,$wpsc_ticket_widget_role) || !$current_user->has_cap('wpsc_agent') && in_array('customer',$wpsc_ticket_widget_role))) {
?>
	<div class="row" style="background-color:<?php echo $wpsc_appearance_individual_ticket_page['wpsc_ticket_widgets_bg_color']?> !important;color:<?php echo $wpsc_appearance_individual_ticket_page['wpsc_ticket_widgets_text_color']?> !important;border-color:<?php echo $wpsc_appearance_individual_ticket_page['wpsc_ticket_widgets_border_color']?> !important;">
		<h4 class="widget_header"><i class="fas fa-shopping-cart"></i> <?php echo $ticket_widget_name;?></h4>
		<hr class="widget_divider">
		<?php 
	  $customer_email= $wpscfunction->get_ticket_fields($ticket_id,'customer_email');
	  $user = get_user_by('email',$customer_email);
	  if($user){
    	    $orders = array();
          // Get all customers subscriptions
    			$customer_subscriptions = get_posts( array(
    					 'numberposts' => -1,
    					 'meta_key'    => '_customer_user',
    					 'meta_value'  => $user->ID, 
    					 'post_type'   => 'shop_subscription', 
    					 'post_status' => array_keys(wcs_get_subscription_statuses()) 
    				));
					if ($customer_subscriptions) {
						?>
						<div style="overflow-y: auto;max-height: 130px;" id="wpsc_user_woo_orders">
							<?php
							foreach ( $customer_subscriptions as $customer_subscription ){
								$orders= wc_get_order( $customer_subscription ); 
								$item_count = $orders->get_item_count();
								$purchase_id = $orders->get_order_number();

								$value = '<a href="javascript:wpsc_get_subscriptions_details(\''.$customer_email.'\','.$purchase_id.',\''.wp_create_nonce($purchase_id).'\')">#'.$purchase_id .
								  	' ' .'(' .(esc_html( wc_format_datetime( $orders->get_date_created(),$format='j M Y'))).' '
									.'- '.(esc_html( wc_get_order_status_name( $orders->get_status()))).')'.'</a>';
								?>
							  <div class="wpsp_sidebar_labels"><?php echo $value ?>
									<?php 
									if ($current_user->has_cap('manage_options')) { 
										$edit_order_details = admin_url('post.php?post='. $customer_subscription->ID .'&action=edit');
										echo " - <a href='".$edit_order_details."' target='_blank'>".__('Visit','wpsc-woocommerce')."</a>"?><?php 
									} ?>
								</div>
				        <?php
				      }
							?>
						</div>
						<?php
					}else{
						?>
						<div class="wpsp_sidebar_labels">
							<?php	_e("No subscriptions found",'wpsc-woocommerce');	?>
						</div>
						<?php
				 }
		}
		?>
	</div>
<?php
}