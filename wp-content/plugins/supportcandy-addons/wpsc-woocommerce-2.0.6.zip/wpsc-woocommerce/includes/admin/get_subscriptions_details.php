<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $current_user, $wpscfunction;

$customer_name = isset($_POST['customer_name']) ? sanitize_text_field($_POST['customer_name']) : '' ;
$payment_id = isset($_POST['payment_id']) ? intval(sanitize_text_field($_POST['payment_id'])) : 0 ;
$nonce      = isset($_POST['nonce']) ? sanitize_text_field($_POST['nonce']) : '' ;

ob_start();

$order = wc_get_order( $payment_id );

?>
<p>
	<?php
    printf(
        __( 'Subscriptions #%1$s was taken   on %2$s and is currently %3$s.', 'woocommerce' ),
        '<mark class="order-number">' . $order->get_order_number() . '</mark>',
        '<mark class="order-date">' . wc_format_datetime( $order->get_date_created() ) . '</mark>',
        '<mark class="order-status">' . wc_get_order_status_name( $order->get_status() ) . '</mark>'
    );
	?>
</p>

<?php 
if ( $notes = $order->get_customer_order_notes() ) : ?>
    <h2><?php _e( 'Subscriptions Update', 'wpsc-woocommerce' ); ?></h2>
    <ol class="woocommerce-OrderUpdates commentlist notes">
      <?php 
			foreach ( $notes as $note ) : ?>
	      <li class="woocommerce-OrderUpdate comment note">
          <div class="woocommerce-OrderUpdate-inner comment_container">
            <div class="woocommerce-OrderUpdate-text comment-text">
              <p class="woocommerce-OrderUpdate-meta meta"><?php echo date_i18n( __( 'l jS \o\f F Y, h:ia', 'wpsc-woocommerce' ), strtotime( $note->comment_date ) ); ?></p>
              <div class="woocommerce-OrderUpdate-description description">
                  <?php echo wpautop( wptexturize( $note->comment_content ) ); ?>
              </div>
              <div class="clear"></div>
            </div>
            <div class="clear"></div>
          </div>
	      </li>
      <?php 
			endforeach; 
			?>
    </ol>
<?php 
endif; 

do_action( 'woocommerce_subscription_details_table', $order );

do_action( 'woocommerce_subscription_totals_table', $order );

wc_get_template( 'order/order-details-customer.php', array( 'order' => $order ) );

?>

<script>
    jQuery('.woocommerce-table').addClass('table table-striped table-hover');
    jQuery('.order-again').remove();
</script>
<?php
$body = ob_get_clean();

$response = array(
    'body'  => $body
);

echo json_encode($response);