<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $current_user, $wpscfunction;

if ($field_type == 11) {
  $args = array(
    'orderby'           => 'title',
    'order'             => 'ASC',
    'post_type'         => 'product',
    'post_status'       => 'publish',
    'posts_per_page'    => 100
  );
  $products = get_posts( $args );
  
  $wpsc_tf_options = get_term_meta( $custom_field->term_id, 'wpsc_tf_options', true);
	foreach ( $products as $option ){
    $options[] = array(
      'value' => str_replace('"', "&quot;", stripcslashes($option->ID)),
      'label' => stripcslashes($option->post_title),
    );
  }
}