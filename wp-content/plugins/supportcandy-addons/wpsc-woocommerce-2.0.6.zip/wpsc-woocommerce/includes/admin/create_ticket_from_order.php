<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
global $wpscfunction,$current_user;

$default_status = get_option('wpsc_default_ticket_status');

$ticket_category = get_option('wpsc_default_ticket_category');

$ticket_priority = get_option('wpsc_default_ticket_priority');

$wpsc_ticket_id_type = get_option('wpsc_ticket_id_type');

$fields = get_terms([
    'taxonomy'   => 'wpsc_ticket_custom_fields',
    'hide_empty' => false,
    'orderby'    => 'meta_value_num',
    'meta_key'	 => 'wpsc_tf_load_order',
    'order'    	 => 'ASC',
    'meta_query' => array(
        array(
            'key'       => 'agentonly',
            'value'     => array(0,1),
            'compare'   => 'IN'
        )
    ),
]);

$order = wc_get_order($post_id);

if ($order) {
    $subject = isset($_POST['wpsc_subject']) ? sanitize_text_field($_POST['wpsc_subject']) : '';
    $ticket_description = isset($_POST['wpsc_description']) ? sanitize_textarea_field($_POST['wpsc_description']) :'';
    
    if ( $subject && $ticket_description ) {

        $user_id = $order->get_user_id();
        $order_id = $order->get_id();
        $user = get_user_by('id', $user_id);

        if ($user) {
            $username   =  $user->user_nicename;
            $user_email =  $user->user_email;
            $user_type  =  "user";
        } else {
            $username   = get_post_meta($order_id, '_billing_first_name', true);
            $user_email = get_post_meta($order_id, '_billing_email', true);
            $user_type  = "guest";
        }

        $values = array(
            'ticket_status' => $default_status,
            'customer_name' => $username,
            'customer_email' => $user_email,
            'ticket_subject' => $subject,
            'user_type' => $user_type,
            'ticket_category' => $ticket_category,
            'ticket_priority' => $ticket_priority,
            'date_created' => date("Y-m-d H:i:s"),
            'date_updated' => date("Y-m-d H:i:s"),
            'ticket_auth_code' => $wpscfunction->getRandomString(10),
            'active' => '1'
        );

        if (!$wpsc_ticket_id_type) {
            $id = 0;
            do {
                $id  = rand(11111111, 99999999);
                $sql = "select id from {$wpdb->prefix}wpsc_ticket where id=" . $id;
                $result = $wpdb->get_var($sql);
            } while ($result);
            $values['id'] = $id;
        }
    
        $ticket_id = $wpscfunction->create_new_ticket($values);

        $wpscfunction->add_ticket_meta($ticket_id, 'assigned_agent', '0');
        $wpscfunction->add_ticket_meta($ticket_id, 'prev_assigned_agent', '0');

        foreach ($fields as $field) {
            $wpsc_tf_type = get_term_meta($field->term_id, 'wpsc_tf_type', true);
            if ($wpsc_tf_type == '12') {
                $wpscfunction->add_ticket_meta($ticket_id, $field->slug, $order_id);
            }
        }

        // Description
        $description = get_term_by('slug', 'ticket_description', 'wpsc_ticket_custom_fields');
        $wpsc_default_desc = get_term_meta($description->term_id, 'wpsc_tf_default_description', true);
        $ticket_description = isset($ticket_description) ? $ticket_description : apply_filters('wpsc_default_description_text', $wpsc_default_desc);


        $signature = get_user_meta($user_id, 'wpsc_agent_signature', true);
        if ($signature) {
            $signature= stripcslashes(htmlspecialchars_decode($signature, ENT_QUOTES));
            $ticket_description.= $signature;
        }

        $os_platform = $wpscfunction->get_os();
        $browser = $wpscfunction->get_browser();

        $ip_address	= isset($_SERVER) && isset($_SERVER['REMOTE_ADDR'])?$_SERVER['REMOTE_ADDR']:'';
        if (strlen($ip_address)>28 || $ip_address == '::1') {
            $ip_address = '';
        }

        $user_seen = 'null';
        if ($current_user->user_email == $user_email) {
            $user_seen = date("Y-m-d H:i:s");
        }

        $thread_args = array(
        'ticket_id'      => $ticket_id,
        'reply_body'     => $wpscfunction->replace_macro($ticket_description, $ticket_id),
        'customer_name'  => $username,
        'customer_email' => $user_email,
        'attachments'    => '',
        'thread_type'    => 'report',
        'ip_address'		 => $ip_address,
        'reply_source'	 => 'browser' ,
        'os' => $os_platform,
        'browser' => $browser,
        'user_seen'      => $user_seen
    );

        $thread_id = $wpscfunction->submit_ticket_thread($thread_args);
    }
}



