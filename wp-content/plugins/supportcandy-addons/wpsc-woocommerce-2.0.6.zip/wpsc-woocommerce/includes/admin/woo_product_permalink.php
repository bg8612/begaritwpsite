<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
global $wpscfunction;

$fields = get_terms([
    'taxonomy'     => 'wpsc_ticket_custom_fields',
    'hide_empty'   => false,
    'orderby'      => 'meta_value_num',
    'meta_key'     => 'wpsc_tf_load_order',
    'order'        => 'ASC',
    'meta_query'   => array(
        'relation' => 'AND',
        array(
            'key'     => 'wpsc_tf_type',
            'value'   => '11',
            'compare' => '=',
        ),
    ),
]);

foreach($fields as $field){
    
    $text = $wpscfunction->get_ticket_meta($ticket_id, $field->slug, true);
    if($text){
        $prod_url = get_permalink($text);
        $prod_url = '<a href="' . $prod_url . '" target="_blank">' . $prod_url . '</a>';
        
    }else{
        $prod_url = __('No woo product found', 'wpsc-woocommerce');
    }
    
}  
$str = preg_replace('/{woo_product_link}/', $prod_url, $str);


