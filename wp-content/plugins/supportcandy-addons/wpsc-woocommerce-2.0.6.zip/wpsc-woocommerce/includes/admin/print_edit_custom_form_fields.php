<?php 
global $wpdb,$current_user,$wpscfunction;


if( apply_filters('wpsc_allow_get_change_ticket_fields',true) ){
	if (!($current_user->ID && $current_user->has_cap('wpsc_agent'))) {exit;}
}
   
if( $custom_field_types->type == 11 ){
  
  $ticket_id = isset($_POST['ticket_id']) ? intval($_POST['ticket_id']) : 0;
  $args = array(
    'orderby'           => 'title',
    'order'             => 'ASC',
    'post_type'         => 'product',
    'post_status'       => 'publish',
    'posts_per_page'    => 100
  );
  $products = get_posts( $args );
  $label = $wpscfunction->get_ticket_meta($ticket_id,$field->slug,true);
  $name = get_term_meta( $field->term_id, 'wpsc_tf_label', true);
  ?>

  <div  data-fieldtype="dropdown" data-visibility="<?php echo $custom_field_types->visibility_conditions?>" class="<?php echo $custom_field_types->col_class?> <?php echo $custom_field_types->visibility? 'hidden':'visible'?> <?php echo $custom_field_types->required? 'wpsc_required':''?> form-group wpsc_form_field <?php echo 'field_'.$field->term_id?>">
    <label><?php echo $name;  ?></label>
    <select class="form-control" name="<?php echo $field->slug; ?>">
      <option value=""></option>
      <?php
      foreach( $products as $product ){
        $value = $product->ID;
        $selected = $value == $label ? 'selected="selected"' : '';
        ?>
        <option <?php echo $selected?> value="<?php echo $value?>"><?php echo $product->post_title?></option>
        <?php
      }
      ?>
    </select>
  </div>
  <?php
}
if($custom_field_types->type==12){

  $ticket_id = isset($_POST['ticket_id']) ? intval($_POST['ticket_id']) : 0;
  $orders = array();
  $label = $wpscfunction->get_ticket_meta($ticket_id,$field->slug,true);
  $customer_email = $wpscfunction->get_ticket_fields($ticket_id,'customer_email');
  $order_user = get_user_by('email',$customer_email);

  $purchases = array();
  if($order_user){
    $purchases = get_posts(array(
      'meta_key' => '_customer_user',
      'meta_value' => $order_user->ID,
      'post_type' => 'shop_order',
      'post_status' => array_keys(wc_get_order_statuses()),
      'numberposts' => -1
    ));  
  }
  
  if ( $purchases ){
    foreach ( $purchases as $post ) { 
      setup_postdata( $post );
      $orders[] = $post->ID ;
    }
    wp_reset_postdata();
  }
  $name = get_term_meta( $field->term_id, 'wpsc_tf_label', true);
  ?>
  <div  data-fieldtype="dropdown" data-visibility="<?php echo $custom_field_types->visibility_conditions?>" class="<?php echo $custom_field_types->col_class?> <?php echo $custom_field_types->visibility? 'hidden':'visible'?> <?php echo $custom_field_types->required? 'wpsc_required':''?> form-group wpsc_form_field <?php echo 'field_'.$field->term_id?>">
    <label class="wpsc_ct_field_label"><?php echo $name;?> </label>
    <select class="form-control" name="<?php echo $field->slug;?>">
      <option value=""></option>
      <?php
      foreach( $orders as $order ){
        $selected = $order == $label ? 'selected="selected"' : '';
        ?>
        <option <?php echo $selected?> value="<?php echo $order?>">#<?php echo $order?></option>
        <?php
      }
      ?>
    </select>
  </div>
  <?php
}
 ?>