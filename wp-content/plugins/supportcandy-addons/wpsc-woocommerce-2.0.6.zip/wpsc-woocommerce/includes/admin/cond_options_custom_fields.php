<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $current_user, $wpscfunction;

if($field_type == 11 ){
  $label      = get_term_meta( $field->term_id, 'wpsc_tf_label', true );
  $condition_options[] = array(
    'key'         => $field->term_id,
    'label'       => $label,
    'has_options' => 1,
  );
}