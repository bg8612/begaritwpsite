<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $wpdb,$current_user, $wpscfunction,$form_field;

 if( $custom_field_types->type == 11 ){
   $args = array(
     'orderby'           => 'title',
     'order'             => 'ASC',
     'post_type'         => 'product',
     'post_status'       => 'publish',
     'posts_per_page'    => 100
   );
   $products = get_posts( $args );
	 
   $class                = $custom_field_types->required ? 'wpsc_required' : '';
   $label                = get_term_meta( $field->term_id, 'wpsc_tf_label', true);
	 $visibility            = $custom_field_types->visibility;
	 $visibility_conditions = is_array($visibility) && $visibility ? implode(';;', $visibility) : '';
	 $visibility_conditions = str_replace('"','&quot;',$visibility_conditions);
   $wpsc_appearance_create_ticket = get_option('wpsc_create_ticket');
   $extra_info_css = 'color:'.$wpsc_appearance_create_ticket['wpsc_extra_info_text_color'].' !important;';
   ?>

	 <div  data-fieldtype="dropdown" data-visibility="<?php echo $visibility_conditions; ?>" class="<?php echo $custom_field_types->col_class; ?> <?php echo $visibility? 'hidden':'visible'?> <?php echo $class ?> form-group wpsc_form_field <?php echo 'field_'.$field->term_id?>">
      <label class="wpsc_ct_field_label" for="Product Name"><?php echo $label;?> 
         <?php echo $custom_field_types->required? '<span style="color:red;">*</span>':'';?>
     </label>
     <?php if($custom_field_types->extra_info){?><p class="help-block" style="<?php echo $extra_info_css?>"><?php echo $custom_field_types->extra_info;?></p><?php }?>
     <select id="<?php echo $field->slug; ?>" class="form-control" name="<?php echo $field->slug; ?>">
       <option value=""></option>
       <?php
       foreach( $products as $product ){
				 	$values = get_term_meta($field->term_id, $field->slug, true );
          $selected = isset($_REQUEST['woo_prod_id']) && $_REQUEST['woo_prod_id'] == $product->ID ? 'selected="selected"' : '';
         ?>
         <option <?php echo $selected?> value="<?php echo $product->ID?>"><?php echo $product->post_title?></option>
         <?php
       }
       ?>
     
     </select>
   </div>
   <?php 
 }
 
 if( $current_user->ID && $custom_field_types->type == 12 ){
   
   $orders = array();
   if( $current_user->ID ){
     
     $purchases = get_posts(array(
       'meta_key' => '_customer_user',
       'meta_value' => $current_user->ID,
       'post_type' => 'shop_order',
       'post_status' => array_keys(wc_get_order_statuses()),
       'numberposts' => -1
     ));
     if ( $purchases ){
       
       foreach ( $purchases as $post ){ 
         setup_postdata( $post );
         $orders[] = $post->ID ;
       }
       wp_reset_postdata();
     }
   }
   
   $class = $custom_field_types->required ? 'wpsc_required' : '';
	 $label = get_term_meta( $field->term_id, 'wpsc_tf_label', true);
	 $visibility            = $custom_field_types->visibility;
	 $visibility_conditions = is_array($visibility) && $visibility ? implode(';;', $visibility) : '';
	 $visibility_conditions = str_replace('"','&quot;',$visibility_conditions);
   $wpsc_appearance_create_ticket = get_option('wpsc_create_ticket');
   $extra_info_css = 'color:'.$wpsc_appearance_create_ticket['wpsc_extra_info_text_color'].' !important;';
   ?>

	 <div  data-fieldtype="dropdown" data-visibility="<?php echo $visibility_conditions; ?>" class="<?php echo $custom_field_types->col_class; ?> <?php echo $visibility? 'hidden':'visible'?> <?php echo $class ?> form-group wpsc_form_field <?php echo 'field_'.$field->term_id?>">
      <label class="wpsc_ct_field_label"><?php echo $label;?> 
       <?php echo $custom_field_types->required? '<span style="color:red;">*</span>':'';?>
     </label>
     <?php if($custom_field_types->extra_info){?><p class="help-block" style="<?php echo $extra_info_css?>"><?php echo $custom_field_types->extra_info;?></p><?php }?>
     <select data-field="woo_order" class="form-control" id="<?php echo $field->slug; ?>" name="<?php echo $field->slug; ?>">
       <option value=""></option>
       <?php
       foreach( $orders as $order ){
         $selected = isset($_REQUEST['woo_order_id']) && $_REQUEST['woo_order_id'] == $order ? 'selected="selected"' : '';
         ?>
         <option <?php echo $selected?> value="<?php echo $order?>">#<?php echo $order?></option>
         <?php
       }
       ?>
     </select>
   </div>
   <?php 
}