<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
final class WPSC_Woo_Backend{
  
  function get_purchase_details(){
    include( WPSC_WOO_PLUGIN_DIR.'includes/admin/get_purchase_details.php' );
    die();
  }

  function wpsc_print_custom_form_field($field,$custom_field_types){
    
    include( WPSC_WOO_PLUGIN_DIR.'includes/admin/print_custom_form_field.php' );
  }
  
  function wpsc_after_create_ticket_custom_field($args,$field,$custom_field_types){
    
    if( $custom_field_types==11 || $custom_field_types==12){
      $text = isset($_POST[$field->slug]) ? sanitize_text_field($_POST[$field->slug]) : '';
      if($text) $args[$field->slug] = $text; 
    }
    
    return $args;
  }
  
  function wpsc_add_ticket_meta_custom_field($ticket_id,$custom_field_types,$args,$field){
		global $wpscfunction;
    if($custom_field_types==11 || $custom_field_types==12){
      $text = isset($args[$field->slug]) ? $args[$field->slug] : '';
			$wpscfunction->add_ticket_meta($ticket_id,$field->slug,$text);
    }
  }
  
  function wpsc_widget_ticket_field_item($field,$ticket_id,$custom_field_types){    
    global $wpscfunction;
    if($custom_field_types==11){
			$label = get_term_meta( $field->term_id, 'wpsc_tf_label', true);
			$field_value =$wpscfunction->get_ticket_meta($ticket_id,$field->slug,true);
    	?>
      <div class="wpsp_sidebar_labels"><strong><?php _e($label,'supportcandy')?>:</strong> <?php echo "<a href='".get_permalink($field_value)."' target='_blank'>".get_the_title($field_value)."</a>"?></div>
      <?php
    }
    if($custom_field_types==12){
			$name = get_term_meta( $field->term_id, 'wpsc_tf_label', true);
			$label =$wpscfunction->get_ticket_meta($ticket_id,$field->slug,true);
		  $customer_email= $wpscfunction->get_ticket_fields($ticket_id,'customer_email');
      $value = '<a href="javascript:wpsc_woo_get_purchase_details(\''.$customer_email.'\','.$label.',\''.wp_create_nonce($label).'\')">#'.$label.'</a>';
      ?>
      <div class="wpsp_sidebar_labels"><strong><?php _e($name,'supportcandy')?>:</strong> <?php echo $value?></div>
      <?php
    }
  }
  
  function wpsc_print_edit_custom_form_field($field, $custom_field_types){
      
    include( WPSC_WOO_PLUGIN_DIR.'includes/admin/print_edit_custom_form_fields.php' );
  }
    
	function wpsc_set_change_ticket_field($fields_data, $field,$ticket_id,$wpsc_tf_type){
    
    global $wpscfunction;
    
		if($wpsc_tf_type == 11 || $wpsc_tf_type == 12 ){
     	$agentonly    = get_term_meta( $field->term_id, 'agentonly', true);
      $oldVal = $wpscfunction->get_ticket_meta( $ticket_id, $field->slug, true);
      $newVal = isset($fields_data->{$field->slug}) ? sanitize_text_field($fields_data->{$field->slug}) : '';
      if ( isset($fields_data->{$field->slug}) && (($agentonly == 0 && $wpscfunction->has_permission('change_ticket_fields',$ticket_id)) || ($agentonly == 1 && $wpscfunction->has_permission('change_agentonly_fields',$ticket_id)) ) && $oldVal != $newVal ) {
         $wpscfunction->change_field($ticket_id,$field->slug,$fields_data->{$field->slug});
      }
    }
  }
  
  function wpsc_add_ticket_widget($ticket_id, $ticket_widget, $ticket_widgets){
    if($ticket_widget->slug=="woo-order"){
      include( WPSC_WOO_PLUGIN_DIR.'includes/admin/print_woo_order.php' );
    }
		
		if ($ticket_widget->slug == 'woo-subscriptions' && class_exists('WC_Subscriptions')) {
			include( WPSC_WOO_PLUGIN_DIR.'includes/admin/print_woo_subscriptions.php' );
		}
		
  }
  
  function wpsc_after_individual_ticket($ticket_id){
    ?>
    <script>
      function wpsc_woo_get_purchase_details(customer_email,payment_id,nonce){
        
        wpsc_modal_open('Order Details');
        var data = {
          action: 'wpsc_woo_get_purchase_details',
          customer_email:customer_email,
          payment_id:payment_id,
          nonce:nonce,
        };
        jQuery.post(wpsc_admin.ajax_url, data, function(response_str) {
          var response = JSON.parse(response_str);
          jQuery('#wpsc_popup_body').html(response.body);
          jQuery('#wpsc_popup_footer').html(response.footer);
        });
      }
			
			function wpsc_get_subscriptions_details(customer_email,payment_id,nonce){
				
				wpsc_modal_open('Subscriptions Details');
				var data = {
					action: 'wpsc_get_subscriptions_details',
					customer_email:customer_email,
					payment_id:payment_id,
					nonce:nonce,
				};
				jQuery.post(wpsc_admin.ajax_url, data, function(response_str) {
					var response = JSON.parse(response_str);
					jQuery('#wpsc_popup_body').html(response.body);
					jQuery('#wpsc_popup_footer').html(response.footer);
				});
			}
    </script>
    <?php
  }
  
  function wpsc_custom_field_types($custom_field_types){
    
    $custom_field_types[11]=array( 
      'label' => __('Woo Product','wpsc-woocommerce'),
      'has_options' => 0,
      'allow_ticket_list' => 1,
      'allow_ticket_filter' => 1,
      'allow_orderby' => 1,
      'ticket_filter_type' => 'string'
    );
    
    $custom_field_types[12]=array( 
      'label' => __('Woo Order','wpsc-woocommerce'),
      'has_options' => 0,
      'allow_ticket_list' => 1,
      'allow_ticket_filter' => 1,
      'allow_orderby' => 1,
      'ticket_filter_type' => 'string'
    );
    
    return $custom_field_types;
  }
  
  function wpsc_print_custom_tl_field($ticket_list){
    include( WPSC_WOO_PLUGIN_DIR.'includes/admin/print_custom_tl_field.php' );
  }
	
	function wpsc_change_the_name($name,$ticket_id,$fields_slug,$wpsc_tf_type,$term_id_data) {
		if($wpsc_tf_type==11 || $wpsc_tf_type==12){
			$name = get_term_meta( $term_id_data->term_id, 'wpsc_tf_label', true);
		}
		return $name;
	} 
	
	function change_the_field($fields_value,$ticket_id,$wpsc_tf_type,$fields_slug){
	 	if($wpsc_tf_type == 11){
			 $fields_value = get_the_title($fields_value);
	 	}
	 	return $fields_value;
	} 
	
  function wpsc_filter_autocomplete($output,$term,$field_slug){
    include( WPSC_WOO_PLUGIN_DIR.'includes/admin/wpsc_filter_autocomplete.php' );
		return $output;
  }
  
  function wpsc_replace_macro_custom($str,$ticket_id,$tf_type,$field){
		global $wpscfunction;
		if($tf_type==11){
			$text = $wpscfunction->get_ticket_meta($ticket_id,$field->slug,true);
      $text = $text ? get_the_title($text) : '';
      $str  = preg_replace('/{'.$field->slug.'}/', $text, $str);
		}
    if($tf_type==12){
			$text = $wpscfunction->get_ticket_meta($ticket_id,$field->slug,true);
      $text = $text ? $text : '';
      $str  = preg_replace('/{'.$field->slug.'}/', $text, $str);
    }
    return $str;
  }
  
	function wpsc_filter_val_label($val, $field_slug){
		if ($field_slug == 'id') {
			$field_slug = 'ticket_id';
		}
		$custom_field = get_term_by('slug', $field_slug, 'wpsc_ticket_custom_fields');
		$type = get_term_meta( $custom_field->term_id, 'wpsc_tf_type', true);
		$term = $val;
		if($type == "11"){
			$term = $val ? get_the_title($val):'';
		}
		return $term;
	}
	
  // Add-on installed or not for licensing
  function is_add_on_installed($flag) {
    return true;
  }
  
  // Print license functionlity for this add-on
  function addon_license_area(){
    include WPSC_WOO_PLUGIN_DIR . 'includes/admin/addon_license_area.php';
  } 
   
  // Activate Canned Reply license
  function license_activate(){
    include WPSC_WOO_PLUGIN_DIR . 'includes/admin/license_activate.php';
		die();
  }
  // Deactivate Canned Reply license
  function license_deactivate(){
    include WPSC_WOO_PLUGIN_DIR . 'includes/admin/license_deactivate.php';
		die();
  }
  
  // Add new menu WPSC settings.
  function wpsc_woo_setting_pill(){
    include WPSC_WOO_PLUGIN_DIR . 'includes/woo_setting_pill.php';
  }
  
  // Setting UI
  function get_woo_settings(){
    include WPSC_WOO_PLUGIN_DIR . 'includes/get_woo_settings.php';
    die();
  }
  
  // Save Settings
  function save_settings(){
    include WPSC_WOO_PLUGIN_DIR . 'includes/save_settings.php';
    die();
  }
	
	function wpsc_search_filter_query($arr,$field){
		include WPSC_WOO_PLUGIN_DIR . 'includes/admin/wpsc_search_filter_query.php';
		return $arr;
	}
	
	function change_prev_field_value($prev_fields_value,$ticket_id,$wpsc_tf_type,$fields_slug){
		if($wpsc_tf_type == 11){
			 $prev_fields_value = get_the_title($prev_fields_value);
	 	}
	 	return $prev_fields_value;
	}
	
	function edit_st_rule_meta_custom_field($term_id,$field,$tf_type){
		if($tf_type == 11 ){
			$field_data = isset($_POST[$field->slug]) ? ($_POST[$field->slug]) : '';
			update_term_meta( $term_id, $field->slug, $field_data );
		}
	}
	
	function add_ep_rule_meta_custom_field($term_id,$field,$tf_type){
		if($tf_type == 11 || $tf_type ==12 ){
			$field_data = isset($_POST[$field->slug]) ? ($_POST[$field->slug]) : '';
			update_term_meta( $term_id, $field->slug, $field_data );
		}
	}
	
	function print_ep_rule_custom_field($field,$tf_type){
		include WPSC_WOO_PLUGIN_DIR . 'includes/admin/print_ep_rule_custom_field.php';
		
	}

	function add_st_rule_meta_custom_field($term_id,$field,$tf_type){
		if($tf_type == 11){
			$field_data = isset($_POST[$field->slug]) ? ($_POST[$field->slug]) : '';
			update_term_meta( $term_id, $field->slug, $field_data );
		}
	}

	function print_st_rule_custom_field($field,$tf_type){
		include WPSC_WOO_PLUGIN_DIR . 'includes/admin/print_st_rule_custom_field.php';
	}
	
	function print_st_edit_custom_field($field,$tf_type){
		include WPSC_WOO_PLUGIN_DIR . 'includes/admin/print_st_rule_custom_field.php';
	}
	
	function wpsc_print_ext_js_create_ticket(){
		?>
				
				jQuery(document).ready(function(){
					jQuery("#customer_name").on("change", function() {
						var user_email = jQuery("#customer_email").val();
						wpsc_get_users_order(user_email);
						
					});
				});
				
				function wpsc_get_users_order(user_email){
					var data = {
						action: 'wpsc_get_users_order',
					};	
					data.user_email = user_email;
					jQuery.post(wpsc_admin.ajax_url, data, function(response) {
						let arr = JSON.parse(response);
						
						jQuery('select[data-field="woo_order"]').empty();
					
						jQuery('select[data-field="woo_order"]').append('<option></option>');
						
						jQuery.each(arr, function(key, value) {
		     			jQuery('select[data-field="woo_order"]')
		          .append(jQuery('<option value="'+value+'"> ', { key : value })
		          .text('#'+value));
						});
						
					});
				}
			
		<?php
	}
	
	function get_users_order(){
    include WPSC_WOO_PLUGIN_DIR . 'includes/admin/get_users_order.php';
    die();
  }
	
	/**
	 * Add WooCommerce Custom Fields 
	 */
	function cond_options_custom_fields( $condition_options, $field_type, $field){
		include WPSC_WOO_PLUGIN_DIR . 'includes/admin/cond_options_custom_fields.php';
		return $condition_options;
	}
	
	/**
	 * Add Woocommerce custom fields options
	 */
	function condition_dd_options($options, $field_type, $custom_field){
		include WPSC_WOO_PLUGIN_DIR . 'includes/admin/condition_dd_options.php';
		return $options;
	}
	
	/**
	 * check ticket conditions WooCommerce custom field type 
	 */
	function check_ticket_conditions_custom_field_type($inner_flag, $ticket_id, $condition, $custom_field_type, $custom_field ){
		include WPSC_WOO_PLUGIN_DIR . 'includes/admin/check_ticket_conditions_custom_field_type.php';
		return $inner_flag;
	}
	
	/**
	 * get subscriptions details of user
	 */
	function get_subscriptions_details(){
    include( WPSC_WOO_PLUGIN_DIR.'includes/admin/get_subscriptions_details.php' );
    die();
  }
	
	function edit_ep_rule_meta_custom_field($term_id,$field,$tf_type){
		if($tf_type == 11 || $tf_type ==12 ){
			$field_data = isset($_POST[$field->slug]) ? ($_POST[$field->slug]) : '';
			update_term_meta( $term_id, $field->slug, $field_data );
		}
	}
	
	function wpsc_apply_ep_rule_custom_form_field($field, $custom_field_types, $rule, $ticket_id){
		include( WPSC_WOO_PLUGIN_DIR.'includes/admin/apply_ep_rule_custom_form_fields.php' );
	}
	
	function mv_add_meta_boxes(){
		
		add_meta_box( 'mv_other_fields', __('Create Ticket','woocommerce'), 'mv_add_other_fields_for_packaging', 'shop_order', 'side', 'core' );

		if (!function_exists( 'mv_add_other_fields_for_packaging' ) ) {

    		function mv_add_other_fields_for_packaging(){
			
				global $post;
				$meta_field_data = get_post_meta( $post->ID, '_my_field_slug', true ) ? get_post_meta( $post->ID, '_my_field_slug', true ) : '';

				echo '<input type="hidden" name="mv_other_meta_field_nonce" value="' . wp_create_nonce() . '">
				<div>'.__('Subject','wpsc-woocommerce').' <span style="color:red;">*</span>
					<input type="text" style="width:250px;" name="wpsc_subject" autocomplete="off" placeholder="' . $meta_field_data . '" value="' . $meta_field_data . '">
				</div>
				<div>'.__('Description','wpsc-woocommerce').' <span style="color:red;">*</span>
					<textarea type="text" name="wpsc_description" id="wpsc_description" class="form-control"  style = "width:100%;height:170px;"></textarea>
				</div>
        		<input type="submit" id="wpsc_ct_submit" class="button save_order button-primary" name="save" value="Create Ticket">';
				?>
				<script>
					jQuery(document).ready(function () {
						jQuery('#wpsc_ct_submit').click(function () {
							if(jQuery('[name=wpsc_subject]').val() == '' || jQuery('[name=wpsc_description]').val() == '' ){
								alert('Please enter the required fields');
								return false;
							}
							
    					});
					});
				
				</script>
				
				<?php
			}
		}
	}

	function mv_save_wc_order_other_fields($post_id){
		include( WPSC_WOO_PLUGIN_DIR.'includes/admin/create_ticket_from_order.php' );
	}

	
	function woo_product_link($str,$ticket_id){
		
		include WPSC_WOO_PLUGIN_DIR .'includes/admin/woo_product_permalink.php';
		return $str;
	}
}