<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $wpdb,$current_user, $wpscfunction,$form_field;

 if( $tf_type->type == 11 ){
   $args = array(
     'orderby'           => 'title',
     'order'             => 'ASC',
     'post_type'         => 'product',
     'post_status'       => 'publish',
     'posts_per_page'    => 100
   );
   $products = get_posts( $args );
	 
   $class = $tf_type->required ? 'wpsc_required' : '';
   $label = get_term_meta( $field->term_id, 'wpsc_tf_label', true);
   $wpsc_appearance_create_ticket = get_option('wpsc_create_ticket');
   
   $extra_info_css = 'color:'.$wpsc_appearance_create_ticket['wpsc_extra_info_text_color'].' !important;';
   ?>

   <div class="form-group">
      <label class="wpsc_ct_field_label" for="Product Name"><?php echo $label;?> 
         <?php echo $tf_type->required? '<span style="color:red;">*</span>':'';?>
     </label>
     <?php if($tf_type->extra_info){?><p class="help-block" style="<?php echo $extra_info_css?>"><?php echo $tf_type->extra_info;?></p><?php }?>
     <select id="<?php echo $field->slug; ?>" class="form-control" name="<?php echo $field->slug; ?>">
       <option value=""></option>
       <?php
       foreach( $products as $product ){
				 	$values = get_term_meta($tf_type->term_id, $field->slug, true );
          $selected = $values && $values == $product->ID ? 'selected="selected"' : '';
         ?>
         <option <?php echo $selected?> value="<?php echo $product->ID?>"><?php echo $product->post_title?></option>
         <?php
       }
       ?>
     
     </select>
   </div>
   <?php 
 }
 