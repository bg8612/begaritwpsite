<?php 
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $current_user, $wpdb;

$user_email = isset($_POST) && isset($_POST['user_email']) ? sanitize_text_field($_POST['user_email']) : '';

$user = get_user_by('email',$user_email);

$orders = array();
if($user){
  $purchases = get_posts(array(
    'meta_key' => '_customer_user',
    'meta_value' => $user->ID,
    'post_type' => 'shop_order',
    'post_status' => array_keys(wc_get_order_statuses()),
    'numberposts' => -1
  ));

  if ( $purchases ){
    
    foreach ( $purchases as $post ){ 
      setup_postdata( $post );
      $orders[] = $post->ID ;
    }
  }
	
}
echo json_encode($orders);
?>