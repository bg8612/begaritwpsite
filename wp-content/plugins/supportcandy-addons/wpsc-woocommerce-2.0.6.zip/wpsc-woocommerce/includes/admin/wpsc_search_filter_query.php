<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
//$arr,$field
$custom_field = get_term_by('slug', $field->slug, 'wpsc_ticket_custom_fields');
$type = get_term_meta( $custom_field->term_id, 'wpsc_tf_type', true);
if($type == "11"){
  $products = get_posts([
    'post_type'  => 'product',
    'hide_empty' => false,
    's'          => $arr['value'],
  ]);
  
  $results = array();
  foreach($products as $product){
    $results[] = $product->ID;
  }
  if($results){
    $arr = array(
      'key'     => $field->slug,
      'value'   => $results,
      'compare' => 'IN'
    );
  }
}
