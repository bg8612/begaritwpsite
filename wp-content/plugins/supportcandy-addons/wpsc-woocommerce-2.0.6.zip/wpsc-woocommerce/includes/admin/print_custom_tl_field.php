<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
global $current_user, $wpscfunction;
$label = '';
if($ticket_list->type=='11'){
	
	$label = $wpscfunction->get_ticket_meta($ticket_list->ticket['id'],$ticket_list->list_item->slug,true);
	$label = $label ? get_the_title($label):'';
}
if($ticket_list->type=='12'){
	
	$label = $wpscfunction->get_ticket_meta($ticket_list->ticket['id'],$ticket_list->list_item->slug,true);
}

echo $label;
?>

