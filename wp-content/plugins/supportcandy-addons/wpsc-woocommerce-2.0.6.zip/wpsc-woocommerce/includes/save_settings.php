<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $current_user;
if (!($current_user->ID && $current_user->has_cap('manage_options'))) {
	exit;
}

$wpsc_dashboard_support_tab = isset($_POST) && isset($_POST['wpsc_dashboard_support_tab']) ? sanitize_text_field($_POST['wpsc_dashboard_support_tab']) : '';
update_option('wpsc_dashboard_support_tab',$wpsc_dashboard_support_tab);

$wpsc_dashboard_support_tab_label = isset($_POST['wpsc_dashboard_support_tab_label']) ? sanitize_text_field($_POST['wpsc_dashboard_support_tab_label']) : '';
update_option('wpsc_dashboard_support_tab_label',$wpsc_dashboard_support_tab_label);

$wpsc_order_help_button = isset($_POST['wpsc_order_help_button']) ? sanitize_text_field($_POST['wpsc_order_help_button']) : '';
update_option('wpsc_order_help_button',$wpsc_order_help_button);

$wpsc_order_help_button_label = isset($_POST['wpsc_order_help_button_label']) ? sanitize_text_field($_POST['wpsc_order_help_button_label']) : '';
update_option('wpsc_order_help_button_label',$wpsc_order_help_button_label);

$wpsc_product_help_button = isset($_POST['wpsc_product_help_button']) ? sanitize_text_field($_POST['wpsc_product_help_button']) : '';
update_option('wpsc_product_help_button',$wpsc_product_help_button);

$wpsc_product_help_button_label = isset($_POST['wpsc_product_help_button_label']) ? sanitize_text_field($_POST['wpsc_product_help_button_label']) : '';
update_option('wpsc_product_help_button_label',$wpsc_product_help_button_label);

do_action('wpsc_set_woo_settings');
echo '{ "sucess_status":"1","messege":"'.__('Settings saved.','wpsc-woocommerce').'" }';