<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $current_user, $wpdb;
if (!($current_user->ID && $current_user->has_cap('manage_options'))) {
	exit;
}
?>
<h4><?php _e('WooCommerce','wpsc-woocommerce');?></h4>
<div class="wpsc_padding_space"></div>
<form id="frm_woo_settings" action="javascript:wpsc_set_woo_settings();" method="post">
	
  <div class="form-group">
	  <label for="wpsc_woo_page"><?php _e('Dashboard support tab','wpsc-woocommerce');?></label>
	  <p class="help-block"></p>
    <select class="form-control" name="wpsc_dashboard_support_tab" id="wpsc_dashboard_support_tab">
      <option <?php echo get_option('wpsc_dashboard_support_tab')=="0"?'selected="selected"':''; ?> value="0"><?php _e('Disable','wpsc-woocommerce')?></option>
			<option <?php echo get_option('wpsc_dashboard_support_tab')=="1"?'selected="selected"':''; ?> value="1"><?php _e('Enable','wpsc-woocommerce')?></option>
    </select>
	</div>
  
  <div class="form-group">
    <label for="wpsc_dashboard_support_tab_label"><?php _e('Dashboard support tab label','wpsc-woocommerce');?></label>
    <p class="help-block"></p>
    <input type="text" class="form-control" name="wpsc_dashboard_support_tab_label" id="wpsc_dashboard_support_tab_label" value="<?php echo get_option('wpsc_dashboard_support_tab_label');?>" />
  </div>

  <div class="form-group">
    <label for="wpsc_order_help_button"><?php _e('Order help button','wpsc-woocommerce');?></label>
    <p class="help-block"></p>
    <select class="form-control" name="wpsc_order_help_button" id="wpsc_order_help_button">
      <option <?php echo get_option('wpsc_order_help_button')=="1"?'selected="selected"':''; ?> value="1"><?php _e('Enable','wpsc-woocommerce')?></option>
      <option <?php echo get_option('wpsc_order_help_button')=="0"?'selected="selected"':''; ?> value="0"><?php _e('Disable','wpsc-woocommerce')?></option>
    </select>
  </div>
	
  <div class="form-group">
    <label for="wpsc_order_help_button_label"><?php _e('Order Help Button Label','wpsc-woocommerce');?></label>
    <p class="help-block"></p>
    <input type="text" class="form-control" name="wpsc_order_help_button_label" id="wpsc_order_help_button_label" value="<?php echo get_option('wpsc_order_help_button_label');?>" />
  </div>
  
  <div class="form-group">
    <label for="wpsc_product_help_button"><?php _e('Product Help Button','wpsc-woocommerce');?></label>
    <p class="help-block"></p>
    <select class="form-control" name="wpsc_product_help_button" id="wpsc_product_help_button">
      <option <?php echo get_option('wpsc_product_help_button')=="1"?'selected="selected"':''; ?> value="1"><?php _e('Enable','wpsc-woocommerce')?></option>
      <option <?php echo get_option('wpsc_product_help_button')=="0"?'selected="selected"':''; ?> value="0"><?php _e('Disable','wpsc-woocommerce')?></option>
    </select>
  </div>
	
  <div class="form-group">
    <label for="wpsc_product_help_button_label"><?php _e('Product Help Button Label','wpsc-woocommerce');?></label>
    <p class="help-block"></p>
    <input type="text" class="form-control" name="wpsc_product_help_button_label" id="wpsc_order_help_button_label" value="<?php echo get_option('wpsc_product_help_button_label');?>" />
  </div>
  
  <button type="submit" class="btn btn-success"><?php _e('Save Changes','wpsc-woocommerce');?></button>
  <img class="wpsc_submit_wait" style="display:none;" src="<?php echo WPSC_PLUGIN_URL.'asset/images/ajax-loader@2x.gif';?>">
  <input type="hidden" name="action" value="wpsc_woo_save_settings" />
	
</form>

<script>
function wpsc_set_woo_settings(){
  jQuery('.wpsc_submit_wait').show();
  var dataform = new FormData(jQuery('#frm_woo_settings')[0]);
  
  jQuery.ajax({
    url: wpsc_admin.ajax_url,
    type: 'POST',
    data: dataform,
    processData: false,
    contentType: false
  })
  .done(function (response_str) {
	  var response = JSON.parse(response_str);
	  jQuery('.wpsc_submit_wait').hide();
    if (response.sucess_status=='1') {
      jQuery('#wpsc_alert_success .wpsc_alert_text').text(response.messege);
    }
    jQuery('#wpsc_alert_success').slideDown('fast',function(){});
    setTimeout(function(){ jQuery('#wpsc_alert_success').slideUp('fast',function(){}); }, 3000);
  });
  
}
</script>