<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

final class WPSC_Woo_Frontend {
  
  function order_help($actions,$order){
    global $wpsupport;
    $order_help_button=get_option('wpsc_order_help_button');
    $order_help_button_label=get_option('wpsc_order_help_button_label');
    $dashboard_support_tab=get_option('wpsc_dashboard_support_tab');
    if($order_help_button){
      if($dashboard_support_tab){
        $url=get_permalink(get_option('woocommerce_myaccount_page_id')).'/support-ticket/?support_page=create_ticket&woo_order_id='.$order->get_id();
      }
      else {
        $url=get_permalink(get_option('wpsc_support_page_id'));
      }
      ?>
      <a class="woocommerce-button button view wpsc_woo_order_btn" href="<?php echo $url; ?>"><?php echo _e($order_help_button_label,'wpsc-woocommerce');?></a>
      <?php
    }
    return $actions;
  }
  
  function woo_new_product_tab( $tabs ) {
    $product_help_button=get_option('wpsc_product_help_button');
    $product_help_button_label=get_option('wpsc_product_help_button_label');
    if($product_help_button){
      
      $tabs['wpsc_woo_tab'] = array(
        'title'     => __( $product_help_button_label, 'wpsc-woocommerce' ),
        'priority'  => 50,
        'callback'  => array($this,'woo_new_product_tab_content'),
      );
    }
    return $tabs;
  }
  
  function woo_new_product_tab_content() {
    // The new tab content
    echo do_shortcode('[wpsc_create_ticket]' );
  }
  
  function woocommerce_add_support_ticket_endpoint(){
    add_rewrite_endpoint( 'support-ticket', EP_ROOT | EP_PAGES );
  }
    
  function add_custom_query_var($vars){
    $vars[] = 'support-ticket';
    return $vars;
  }
    
  function woocommerce_account_menu_items($items){
    
    $support_tab=get_option('wpsc_dashboard_support_tab');
    $support_tab_label=get_option('wpsc_dashboard_support_tab_label');
    if($support_tab==1){
      $items['support-ticket'] = __( $support_tab_label, 'woocommerce' );
    }
    return $items;
  }

  function wk_endpoint_content() {
    
    echo do_shortcode('[supportcandy]' );
  }
    
  function my_custom_flush_rewrite_rules(){
    flush_rewrite_rules();
  }
}
?>
