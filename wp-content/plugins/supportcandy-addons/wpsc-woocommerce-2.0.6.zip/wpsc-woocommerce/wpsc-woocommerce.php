<?php
/**
 * Plugin Name: SupportCandy Woocommerce Add-On
 * Plugin URI: https://supportcandy.net/
 * Description: Woocommerce integration SupportCandy!
 * Version: 2.0.6
 * Author: Support Candy
 * Author URI: https://supportcandy.net/
 * Requires at least: 4.4
 * Tested up to: 4.9
 * Text Domain: wpsc-woocommerce
 * Domain Path: /lang
 */
 
 if (!defined('ABSPATH')) {
     exit; // Exit if accessed directly
 }
if ( ! class_exists( 'WPSupportCandyWoocommerce' ) ) : 
final class WPSupportCandyWoocommerce {
      
     public $version = '2.0.6';
     
     public function __construct() {
       
       $this->define_constants();
       $this->include_files();
       add_action('init', array($this, 'load_textdomain'));
       add_action('init', array($this, 'after_init'));
       register_activation_hook(__FILE__,array($this,'activation'));
       register_deactivation_hook( __FILE__, array($this,'deactivate') );
       
     }
     
     function after_init(){
      if(!is_admin()){
        add_filter('wpsc_create_ticket_short_para', array($this, 'wpsc_create_ticket_short_para'));
      }
     }
     
     function wpsc_create_ticket_short_para($url_attrs){
      global $post;
      
      if(isset($post) && $post->post_type=='product'){
        $url_attrs[] = 'woo_prod_id :"'.$post->ID.'"';
      }
      
      return $url_attrs;
     }
     
     private function define_constants() {

       define('WPSC_WOO_PLUGIN_FILE', __FILE__ );
       define('WPSC_WOO_PLUGIN_URL', plugin_dir_url(__FILE__));
       define('WPSC_WOO_PLUGIN_DIR', plugin_dir_path(__FILE__));
       define('WPSC_WOO_VERSION', $this->version);
       define('WPSC_WOO_STORE_ID', '5397' );
     }
   
     function load_textdomain(){
       
       $locale = apply_filters( 'plugin_locale', get_locale(), 'wpsc-woocommerce' );
       load_textdomain( 'wpsc-woocommerce', WP_LANG_DIR . '/wpsc/wpsc-woocommerce-' . $locale . '.mo' );
       load_plugin_textdomain( 'wpsc-woocommerce', false, plugin_basename( dirname( __FILE__ ) ) . '/lang' );
     }

     function include_files(){
       include_once( WPSC_WOO_PLUGIN_DIR . 'class-wpsc-woo-install.php' );
       include( WPSC_WOO_PLUGIN_DIR.'includes/admin/admin.php' );
       include( WPSC_WOO_PLUGIN_DIR.'includes/frontend.php' );
       
       $backend    = new WPSC_Woo_Backend();
       $frontend   = new WPSC_Woo_Frontend();

       if (is_admin()) {

        add_action( 'wpsc_print_custom_form_field', array($backend, 'wpsc_print_custom_form_field'), 10, 2 );
        add_filter( 'wpsc_after_create_ticket_custom_field',array($backend,'wpsc_after_create_ticket_custom_field'),10,3);
        add_action( 'wpsc_print_edit_custom_form_field', array($backend, 'wpsc_print_edit_custom_form_field'), 10, 2 );
        add_action('wpsc_print_custom_tl_field',array($backend,'wpsc_print_custom_tl_field'),10,1);
        add_action('wpsc_print_ext_js_create_ticket',array($backend,'wpsc_print_ext_js_create_ticket'));
        //settings
        add_action( 'wpsc_after_setting_pills', array($backend,'wpsc_woo_setting_pill'));
        add_action( 'wp_ajax_wpsc_get_woo_settings', array($backend,'get_woo_settings'));
        add_action( 'wp_ajax_wpsc_woo_save_settings', array($backend,'save_settings'));
        //Email piping rule
        add_action('wpsc_print_ep_rules_custom_form_field',array($backend,'print_ep_rule_custom_field'),10,2);
        add_action('wpsc_edit_ep_rule_meta_custom_field',array($backend,'edit_ep_rule_meta_custom_field'),10,3);
        add_action('wpsc_add_ep_rule_meta_custom_field',array($backend,'add_ep_rule_meta_custom_field'),10,3);
        
        //Schedule Ticket
        add_action('wpsc_print_st_rules_custom_form_field',array($backend,'print_st_rule_custom_field'),10,2);
        add_action('wpsc_print_sl_edit_custom_form_field',array($backend ,'print_st_edit_custom_field'),10,2);
        add_action('wpsc_edit_st_rule_meta_custom_field',array($backend,'edit_st_rule_meta_custom_field'),10,3);
        add_action('wpsc_add_st_rule_meta_custom_field',array($backend,'add_st_rule_meta_custom_field'),10,3);
        
        //Conditions
        add_filter('wpsc_cond_options_custom_fields',array($backend,'cond_options_custom_fields'),10,3);
        add_filter('wpsc_condition_custom_field_dd_options',array($backend,'condition_dd_options'),10,3);
        add_filter('wpsc_check_ticket_conditions_custom_field_type',array($backend,'check_ticket_conditions_custom_field_type'),10,5);
  
        }else {
         
        add_filter( 'woocommerce_my_account_my_orders_actions', array($frontend, 'order_help'), 10, 2);
        add_filter( 'woocommerce_product_tabs',array($frontend, 'woo_new_product_tab' ));
        add_action( 'init', array($frontend,'woocommerce_add_support_ticket_endpoint' ));
        add_filter( 'query_vars', array($frontend,'add_custom_query_var'), 0 );
        add_action( 'wp_loaded',array($frontend,'my_custom_flush_rewrite_rules'));
        add_filter( 'woocommerce_account_menu_items',array($frontend,'woocommerce_account_menu_items'),10,1);
        add_action( 'woocommerce_account_support-ticket_endpoint',array($frontend,'wk_endpoint_content'));
      }
      //custom post type start
      add_filter( 'wpsc_custom_field_types', array($backend,'wpsc_custom_field_types'),10,1);
      add_action( 'wpsc_after_individual_ticket', array($backend,'wpsc_after_individual_ticket') );
      add_action( 'wpsc_after_guest_individual_ticket', array($backend,'wpsc_after_individual_ticket') );
      add_action( 'wpsc_add_ticket_widget',array($backend,'wpsc_add_ticket_widget'),10,3); 
      add_action( 'wp_ajax_wpsc_woo_get_purchase_details', array($backend,'get_purchase_details'));
      add_action( 'wp_ajax_nopriv_wpsc_woo_get_purchase_details', array($backend,'get_purchase_details'));
      add_filter( 'wpsc_replace_macro_custom',array($backend,'wpsc_replace_macro_custom'),10,4);
      add_filter('wpsc_replace_macro',array($backend,'woo_product_link'),10,2);

      //filter settings
      add_filter('wpsc_filter_autocomplete', array($backend, 'wpsc_filter_autocomplete'), 10, 3);
      add_filter('wpsc_filter_val_label', array($backend, 'wpsc_filter_val_label'), 10, 2);
      add_filter('wpsc_search_filter_query', array($backend, 'wpsc_search_filter_query'), 10, 2);
      
      add_filter('wpsc_change_field_value',array($backend,'change_the_field'),10,4);
      add_filter('wpsc_change_prev_field_value',array($backend,'change_prev_field_value'),10,4);
      add_filter('wpsc_change_field_name',array($backend,'wpsc_change_the_name'),10,5);
      add_action( 'wpsc_add_ticket_meta_custom_field',array($backend,'wpsc_add_ticket_meta_custom_field'),10,4);
      add_action('wp_ajax_wpsc_get_users_order',array($backend,'get_users_order'));
      
      // change ticket and agent fields 
      add_action( 'wpsc_set_change_ticket_field',array($backend, 'wpsc_set_change_ticket_field'), 10, 4);
      
      //subscriptions details
      add_action( 'wp_ajax_wpsc_get_subscriptions_details', array($backend,'get_subscriptions_details'));
      
      add_action('wpsc_apply_ep_rule_custom_form_field' , array($backend, 'wpsc_apply_ep_rule_custom_form_field'),10,4);
      add_action( 'wpsc_widget_ticket_field_item',array($backend, 'wpsc_widget_ticket_field_item'), 10, 3);

      if( class_exists( 'Support_Candy' )){
        add_action( 'add_meta_boxes', array($backend,'mv_add_meta_boxes') );
        add_action( 'save_post', array($backend,'mv_save_wc_order_other_fields'),10,1);  
      }
     
      // License
      add_filter( 'wpsc_is_add_on_installed', array($backend,'is_add_on_installed'));
      add_action( 'wpsc_addon_license_area', array($backend,'addon_license_area'));
      add_action( 'wp_ajax_wpsc_woo_activate_license', array($backend,'license_activate'));
      add_action( 'wp_ajax_wpsc_woo_deactivate_license', array($backend,'license_deactivate'));
      add_action( 'admin_init', array($this, 'plugin_updator'));
    }
    
    function deactivate(){
      include( WPSC_WOO_PLUGIN_DIR.'class-wpsc-woo-uninstall.php' );
    }
    
    function activation(){
      //add woo widget at installation
			$agent_role_ids = array();
			$agent_role = get_option('wpsc_agent_role');
			foreach ($agent_role as $key => $agent) {
				$agent_role_ids[] = $key;
			}
				
			$term = wp_insert_term('Woo Order', 'wpsc_ticket_widget' );
			if (!is_wp_error($term) && isset($term['term_id'])) {
				add_term_meta ($term['term_id'], 'wpsc_label', __('Woo Order','wpsc-woocommerce'));
				add_term_meta ($term['term_id'], 'wpsc_ticket_widget_load_order', '4');
				add_term_meta($term['term_id'], 'wpsc_ticket_widget_type', '1');
				add_term_meta($term['term_id'],'wpsc_ticket_widget_role', $agent_role_ids);
        $wpsc_custom_widget_localize = get_option('wpsc_custom_widget_localize');
        $wpsc_custom_widget_localize['custom_widget_'.$term['term_id']] = get_term_meta($term['term_id'], 'wpsc_label', true);;
        update_option('wpsc_custom_widget_localize', $wpsc_custom_widget_localize);
			}
      
      //add woo subscription widget at installation
			$agent_role_ids = array();
			$agent_role = get_option('wpsc_agent_role');
			foreach ($agent_role as $key => $agent) {
				$agent_role_ids[] = $key;
			}
				
			$term = wp_insert_term('Woo Subscriptions', 'wpsc_ticket_widget' );
			if (!is_wp_error($term) && isset($term['term_id'])) {
				add_term_meta ($term['term_id'], 'wpsc_label', __('Woo Subscriptions','wpsc-woocommerce'));
				add_term_meta ($term['term_id'], 'wpsc_ticket_widget_load_order', '5');
				add_term_meta($term['term_id'], 'wpsc_ticket_widget_type', '1');
				add_term_meta($term['term_id'],'wpsc_ticket_widget_role', $agent_role_ids);
        $wpsc_custom_widget_localize = get_option('wpsc_custom_widget_localize');
        $wpsc_custom_widget_localize['custom_widget_'.$term['term_id']] = get_term_meta($term['term_id'], 'wpsc_label', true);;
        update_option('wpsc_custom_widget_localize', $wpsc_custom_widget_localize);
			}

    }
    
    function plugin_updator(){
      $license_key = get_option( 'wpsc_woo_license_key' );
      $license_expiry = get_option('wpsc_woo_license_expiry','');
      if (class_exists('Support_Candy') && $license_key && $license_expiry) {
        $edd_updater = new EDD_SL_Plugin_Updater( WPSC_STORE_URL, __FILE__, array(
          'version' => WPSC_WOO_VERSION,
          'license' => $license_key,
          'item_id' => WPSC_WOO_STORE_ID,
          'author'  => 'Pradeep Makone',
          'url'     => site_url()
        ));
      }
    }
}
endif;

if(class_exists('WooCommerce')){
  new WPSupportCandyWoocommerce();  
}
