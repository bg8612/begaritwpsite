<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if ( ! class_exists( 'WPSC_WOO_Install' ) ) :

  final class WPSC_WOO_Install {
    
    public function __construct() {
  			$this->check_version();
    }
    
    public function check_version(){
      $installed_version = get_option( 'wpsc_woo_com_current_version', 0 );
			
			if( $installed_version != WPSC_WOO_VERSION ){						
          add_action( 'init', array($this,'upgrade'), 101 );
      }
		}
    
    // Upgrade
		public function upgrade(){
				
        $installed_version = get_option( 'wpsc_woo_com_current_version', 0 );
				$installed_version = $installed_version ? $installed_version : 0;

				if($installed_version <'1.0.0'){
				
					update_option('wpsc_dashboard_support_tab', '1');
					update_option('wpsc_dashboard_support_tab_label',__('Support Tickets','wpsc-woocommerce'));
					update_option('wpsc_order_help_button','1');
					update_option('wpsc_order_help_button_label',__('Help','wpsc-woocommerce'));
					update_option('wpsc_product_help_button','1');
					update_option('wpsc_product_help_button_label',__('Help','wpsc-woocommerce'));
					
					$term = wp_insert_term( 'Woo Product', 'wpsc_ticket_custom_fields' );
			 		if (!is_wp_error($term) && isset($term['term_id'])) {
						global $wpdb,$wpscfunction;
						$field_types = $wpscfunction->get_custom_field_types();

				 	  $load_order = $wpdb->get_var("select max(meta_value) as load_order from {$wpdb->prefix}termmeta WHERE meta_key='wpsc_tf_load_order'");
				 	  add_term_meta ($term['term_id'], 'wpsc_tf_label', __('Product','wpsc-woocommerce'));
				 	  add_term_meta ($term['term_id'], 'wpsc_tf_extra_info','');
				 		add_term_meta ($term['term_id'], 'agentonly', '0');
				 		add_term_meta ($term['term_id'], 'wpsc_tf_status', '1');
				 		add_term_meta ($term['term_id'], 'wpsc_tf_type', '11');
				 		add_term_meta ($term['term_id'], 'wpsc_tf_options', array());
				 		add_term_meta ($term['term_id'], 'wpsc_tf_required', '0');
				 		add_term_meta ($term['term_id'], 'wpsc_tf_width', '1');
				 		add_term_meta ($term['term_id'], 'wpsc_tf_visibility', array());
				 		add_term_meta ($term['term_id'], 'wpsc_tf_personal_info', '0');
				 		add_term_meta ($term['term_id'], 'wpsc_tf_load_order', ++$load_order);
				 		add_term_meta ($term['term_id'], 'wpsc_allow_ticket_list', '1');
						add_term_meta ($term['term_id'], 'wpsc_customer_ticket_list_status', '0');
						add_term_meta ($term['term_id'], 'wpsc_agent_ticket_list_status', '0');
						add_term_meta ($term['term_id'], 'wpsc_allow_ticket_filter', '1');
						add_term_meta ($term['term_id'], 'wpsc_ticket_filter_type', 'string');
						add_term_meta ($term['term_id'], 'wpsc_customer_ticket_filter_status', '0');
						add_term_meta ($term['term_id'], 'wpsc_agent_ticket_filter_status', '0');
				 		add_term_meta ($term['term_id'], 'wpsc_allow_orderby', '1');
					}
				
					$term = wp_insert_term( 'Woo Order', 'wpsc_ticket_custom_fields' );
					if (!is_wp_error($term) && isset($term['term_id'])) {
						global $wpdb,$wpscfunction;
						$field_types = $wpscfunction->get_custom_field_types();

						$load_order = $wpdb->get_var("select max(meta_value) as load_order from {$wpdb->prefix}termmeta WHERE meta_key='wpsc_tf_load_order'");
						add_term_meta ($term['term_id'], 'wpsc_tf_label', __('Order','wpsc-woocommerce'));
				 	  add_term_meta ($term['term_id'], 'wpsc_tf_extra_info','');
				 		add_term_meta ($term['term_id'], 'agentonly', '0');
				 		add_term_meta ($term['term_id'], 'wpsc_tf_status', '1');
				 		add_term_meta ($term['term_id'], 'wpsc_tf_type', '12');
				 		add_term_meta ($term['term_id'], 'wpsc_tf_options', array());
				 		add_term_meta ($term['term_id'], 'wpsc_tf_required', '0');
				 		add_term_meta ($term['term_id'], 'wpsc_tf_width', '1');
				 		add_term_meta ($term['term_id'], 'wpsc_tf_visibility', array());
				 		add_term_meta ($term['term_id'], 'wpsc_tf_personal_info', '1');
				 		add_term_meta ($term['term_id'], 'wpsc_tf_load_order', ++$load_order);
				 		add_term_meta ($term['term_id'], 'wpsc_allow_ticket_list', '1');
						add_term_meta ($term['term_id'], 'wpsc_customer_ticket_list_status', '0');
						add_term_meta ($term['term_id'], 'wpsc_agent_ticket_list_status', '0');
						add_term_meta ($term['term_id'], 'wpsc_allow_ticket_filter', '1');
						add_term_meta ($term['term_id'], 'wpsc_ticket_filter_type', 'string');
						add_term_meta ($term['term_id'], 'wpsc_customer_ticket_filter_status', '0');
						add_term_meta ($term['term_id'], 'wpsc_agent_ticket_filter_status', '0');
				 		add_term_meta ($term['term_id'], 'wpsc_allow_orderby', '1');
						
					}
				}
				
				if($installed_version < '2.0.2'){
					$fields = get_terms([
						'taxonomy'   => 'wpsc_ticket_custom_fields',
						'hide_empty' => false,
						'orderby'    => 'meta_value_num',
						'meta_key'	 => 'wpsc_tf_load_order',
						'order'    	 => 'ASC',
						'meta_query' => array(
							array(
					      'key'       => 'agentonly',
					      'value'     => '0',
					      'compare'   => '='
					    )
						),
					]);
					
					$custom_fields_localize = get_option('wpsc_custom_fields_localize');
					if (!$custom_fields_localize) {
						$custom_fields_localize = array();
					}
					
					$custom_fields_extra_info = get_option('wpsc_custom_fields_extra_info');
					if (!$custom_fields_extra_info) {
						 $custom_fields_extra_info = array();
					}
					
					foreach($fields as $custom_fields){
						$wpsc_tf_type      = get_term_meta( $custom_fields->term_id, 'wpsc_tf_type', true);
						if($wpsc_tf_type == 11 || $wpsc_tf_type == 12){
							$label = get_term_meta( $custom_fields->term_id, 'wpsc_tf_label', true);
							$custom_fields_localize['custom_fields_'.$custom_fields->term_id] = $label;
							update_option('wpsc_custom_fields_localize', $custom_fields_localize);
							
							$extra_info = get_term_meta( $custom_fields->term_id, 'wpsc_tf_extra_info', true);
							$custom_fields_extra_info['custom_fields_extra_info_' . $custom_fields->term_id] = $extra_info;
							update_option('wpsc_custom_fields_extra_info', $custom_fields_extra_info);
						}
					}
				}

				if($installed_version < '2.0.6' ){
					$term = wp_insert_term( 'woo_product_link', 'wpsc_ticket_custom_fields' );
					if ( !is_wp_error($term) && isset($term['term_id'])) {
						add_term_meta ($term['term_id'], 'wpsc_tf_label', __('Woo Product Permalink','wpsc-woocommerce'));
						add_term_meta ($term['term_id'], 'agentonly', '2');
						add_term_meta ($term['term_id'], 'wpsc_tf_type', '0');
						add_term_meta ($term['term_id'], 'wpsc_allow_ticket_list', '0');
						add_term_meta ($term['term_id'], 'wpsc_allow_ticket_filter', '0');
					}
				}
				
				update_option( 'wpsc_woo_com_current_version', WPSC_WOO_VERSION );
		}
	}
endif;

new WPSC_WOO_Install();