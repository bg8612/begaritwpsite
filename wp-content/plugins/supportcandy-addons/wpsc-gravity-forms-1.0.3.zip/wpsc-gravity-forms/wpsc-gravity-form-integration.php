<?php
/**
 * Plugin Name:  SupportCandy - Gravity Form Integration
 * Plugin URI: https://www.supportcandy.net/
 * Description: Gravity forms integration for your SupportCandy
 * Version: 1.0.3
 * Author: SupportCandy
 * Author URI: http://www.supportcandy.net/
 * Text Domain: wpsc-gf
 * Domain Path: /lang
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if(class_exists('GFCommon')){
	$GLOBALS['WPSC_SupportCandy_GF'] = new WPSC_SupportCandy_GF();
}

final class WPSC_SupportCandy_GF {

	public $version = '1.0.3';
	/*
   * Constructor
   */

 	public function __construct() {
		 $this->define_constants();
		 add_action( 'init', array($this,'load_textdomain') );
		 $this->include_files();
	}

	 function define_constants(){

		 define('WPSC_GF_PLUGIN_FILE', __FILE__);
		 define('WPSC_GF_ABSPATH', dirname(__FILE__) . '/');
		 define('WPSC_GF_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
		 define('WPSC_GF_PLUGIN_BASENAME', plugin_basename(__FILE__));
		 define('WPSC_GF_STORE_ID', '63231');
		 define('WPSC_GF_VERSION', $this->version);
   }
   /*
    * Textdomain loaded for this customization.
    */
		function load_textdomain(){
			$locale = apply_filters( 'plugin_locale', get_locale(), 'wpsc-gf' );
			load_textdomain( 'wpsc-gf', WP_LANG_DIR . '/wpsc/wpsc-gf-' . $locale . '.mo' );
			load_plugin_textdomain( 'wpsc-gf', false, plugin_basename( dirname( __FILE__ ) ) . '/lang' );
		}

		function include_files(){

			include( WPSC_GF_ABSPATH.'includes/admin/admin.php' );
			include( WPSC_GF_ABSPATH.'includes/frontend.php' );
			include( WPSC_GF_ABSPATH.'wpsc-gravity-form-install.php' );
			include( WPSC_GF_ABSPATH . 'wpsc-gravity-form-function.php' );

			$backend  = new WPSC_SupportCandy_GF_Backend();
			$frontend = new WPSC_SupportCandy_GF_Frontend();

			if (is_admin()) {
				add_action( 'wpsc_after_setting_pills', array($backend,'gravity_form_setting_pill'));
				add_action('wp_ajax_wpsc_get_gravity_form_setting', array($backend,'get_gravity_form_settings'));
				add_action('wp_ajax_wpsc_set_gravity_form_settings',array($backend,'set_gravity_form_settings'));
				add_action('wp_ajax_wpsc_get_edit_gf_rules', array($backend,'get_edit_gf_rules'));
				add_action('wp_ajax_wpsc_set_edit_gf_rules' , array($backend ,'set_edit_gf_rules'));
				add_action('wp_ajax_wpsc_delete_gf_rules' , array($backend , 'delete_gf_rules'));
				add_action('wp_ajax_wpsc_set_gf_rule_list_order' , array($backend ,'set_gf_rule_list_order'));
				add_action('wp_ajax_wpsc_get_edit_gf_values', array($backend,'get_edit_gf_values'));
				add_action('wp_ajax_wpsc_get_add_gf_rules', array($backend,'get_add_gf_rules'));
				add_action('wp_ajax_wpsc_set_add_gf_rules', array($backend,'set_add_gf_rules'));
	  	}

			// After gravity form submmision
			add_action('gform_after_submission', array($backend,'gf_after_submission'), 10, 2 );
			
			// supportcandy form field details
			add_action('wpsc_before_form_fields_edit_option', array($backend, 'custom_fields_option_details'));
			
			// custom fields info 
			add_action('wp_ajax_wpsc_custom_field_info', array($backend,'custom_field_info'));
			
			// After New form Created
			add_action( 'gform_after_save_form', array( $backend, 'after_save_form' ), 10, 2 );
			
			// After Form Deleted 
			add_action('gform_after_delete_form',array( $backend, 'after_delete_form'));

			//License
		  add_filter( 'wpsc_is_add_on_installed', array($backend,'is_add_on_installed'));
		  add_action( 'wpsc_addon_license_area', array($backend,'addon_license_area'));
		  add_action( 'wp_ajax_wpsc_gf_activate_license', array($backend,'license_activate'));
		  add_action( 'wp_ajax_wpsc_gf_deactivate_license', array($backend,'license_deactivate'));
		  add_action( 'admin_init', array($this, 'plugin_updator'));

		}

		function plugin_updator(){
			$license_key    = get_option('wpsc_gf_license_key','');
			$license_expiry = get_option('wpsc_gf_license_expiry','');
			if ( class_exists('Support_Candy') && $license_key && $license_expiry ) {
				$edd_updater = new EDD_SL_Plugin_Updater( WPSC_STORE_URL, __FILE__, array(
								'version' => WPSC_GF_VERSION,
								'license' => $license_key,
								'item_id' => WPSC_GF_STORE_ID,
								'author'  => 'Pradeep Makone',
								'url'     => site_url()
				) );
			}
		}
}
