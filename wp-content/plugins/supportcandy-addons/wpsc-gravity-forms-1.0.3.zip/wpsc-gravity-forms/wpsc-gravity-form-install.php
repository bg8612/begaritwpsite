<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if ( ! class_exists( 'WPSC_Gravity_Form_Install' ) ) :
  
  final class WPSC_Gravity_Form_Install {

    public function __construct() {
			add_action( 'init', array($this,'register_post_type'), 100 );
		  $this->check_version();
    }
		    		
		// Register post types and texonomies
    public function register_post_type(){
      
      // Register sla texonomy
			$args = array(
          'public'             => false,
          'rewrite'            => false
      );
      register_taxonomy( 'wpsc_gf', 'wpsc_ticket', $args );
      
    }
				
		/**
		 * Check version of WPSC
		 */
		public function check_version(){
				$installed_version = get_option( 'wpsc_gf_current_version', 0 );
				if( $installed_version != WPSC_GF_VERSION ){
						add_action( 'init', array($this,'upgrade'), 101 );
				}

		}
		
		// Upgrade
		public function upgrade(){
			
		  	$installed_version = get_option( 'wpsc_gf_current_version', 0 );
			$installed_version = $installed_version ? $installed_version : 0;
				
			update_option( 'wpsc_gf_current_version', WPSC_GF_VERSION );				
		}		
  }
endif;

new WPSC_Gravity_Form_Install();