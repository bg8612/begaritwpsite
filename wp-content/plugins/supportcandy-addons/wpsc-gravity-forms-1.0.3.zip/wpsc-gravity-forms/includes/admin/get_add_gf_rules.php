<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $current_user, $wpscfunction,$wpdb;
if (!($current_user->ID && $current_user->has_cap('manage_options'))) {
	exit;
}

$gravity_froms     = $wpdb->get_results("SELECT id,title FROM {$wpdb->prefix}gf_form WHERE is_active='1' AND is_trash='0' ");
$gravity_rule_terms = array();
$gravity_form_rules = get_terms([
	'taxonomy'   => 'wpsc_gf',
	'hide_empty' => false
]);
foreach($gravity_form_rules as $rule){
	$wpsc_gf_id = get_term_meta($rule->term_id,'wpsc_gravity_form_id',true);
	$gravity_rule_terms[] = $wpsc_gf_id;
}

?>
<div class="row">
  <form id="frm_new_gravity_form" class="" action="javascript:wpsc_set_add_gf_rules();" method="post">
		<h4> Gravity Forms / <?php _e('Add New','wpsc-gf');?></h4>
    <div class="form-group">
      <label for="new_gravity_form"><?php _e('Select form','wpsc-gf');?></label>
  		<p class="help-block"><?php _e("Please select gravity form to integrate.","wpsc-gf");?></p>
      <select class="form-control" name="wpsc_gravity_form_id" id="wpsc_gravity_form_id" >
        <option id="wpsc_gravity_from_type" value=""></option>
        <?php 
				foreach ($gravity_froms as $key => $gform) :
					
					if(!in_array($gform->id,$gravity_rule_terms)){
						?>
						<option id="wpsc_gravity_from_type" value="<?php echo $gform->id?>"><?php echo $gform->title?></option>
						<?php	
					}
				endforeach;?>
      </select>
    </div>
    
    <button type="submit" style="margin-top:10px;" class="btn btn-success" id="wpsc_save_changes_add_gf_btn"><?php _e('Add','wpsc-gf');?></button>
    <img class="wpsc_submit_wait" style="display:none;" src="<?php echo WPSC_PLUGIN_URL.'asset/images/ajax-loader@2x.gif';?>">
    <input type="hidden" name="action" value="wpsc_set_add_gf_rules" />
  </form>
  
</div>