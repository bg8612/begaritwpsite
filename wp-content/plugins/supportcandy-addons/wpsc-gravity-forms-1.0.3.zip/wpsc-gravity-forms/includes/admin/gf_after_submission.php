<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $current_user, $wpdb,$wpscfunction,$wpscgffunction;
$form_id = $entry['form_id'];

$args = array(
'hide_empty' => false,
'meta_query' => array(
    array(
       'key'       => 'wpsc_gravity_form_id',
       'value'     => $form_id,
       'compare'   => '='
    )
),
'taxonomy'  => 'wpsc_gf',
);
$terms = get_terms( $args );

$custom_fields = get_terms([
	'taxonomy'   => 'wpsc_ticket_custom_fields',
	'hide_empty' => false,
	'orderby'    => 'meta_value_num',
	'meta_key'	 => 'wpsc_tf_load_order',
	'order'    	 => 'ASC',
	'meta_query' => array(
		'relation' => 'AND',
		array(
			'key'       => 'agentonly',
      'value'     => '0',
			'compare'   => '='
		),
	)
]);

$mapping_term = $terms[0]->term_id;

$mapping_values = get_term_meta($mapping_term, 'wpsc_gf_mapping_values', true);

if($mapping_values){

	$args = array();
	foreach ($custom_fields as $field) {

		if ($field->slug == 'ticket_category') {
			$gravity_categoty = isset($entry[$mapping_values[$field->term_id]]) ? $entry[$mapping_values[$field->term_id]] : 0;
			if ($wpscfunction->is_category($gravity_categoty)) {
				$args[$field->slug] = $gravity_categoty;
			} else {
				$default_category = get_option('wpsc_default_ticket_category');
				$args[$field->slug] = $default_category;
			}
		} elseif ($field->slug == 'ticket_priority') {
			$gravity_priority = isset($entry[$mapping_values[$field->term_id]]) ? $entry[$mapping_values[$field->term_id]] : 0;
			if ($wpscfunction->is_priority($gravity_priority)) {
				$args[$field->slug] = $gravity_priority;
			} else {
				$default_priority = get_option('wpsc_default_ticket_priority');
				$args[$field->slug] = $default_priority;
			}
		} else {
			$tf_type = get_term_meta($field->term_id, 'wpsc_tf_type', true);
			$gravity_field = RGFormsModel::get_field($form, $mapping_values[$field->term_id]);
			switch ($tf_type) {
				case '1':
					if ($gravity_field['type'] == 'fileupload' || $gravity_field['inputType'] == 'fileupload') {
						continue;
					} else if ($gravity_field['type'] == 'address' || $gravity_field['inputType'] == 'address' || $gravity_field['inputType'] == 'list' || $gravity_field['type'] == 'list') {
						$address_field = GFFormsModel::get_field($form_id, $mapping_values[$field->term_id]);
						$address_value = is_object($address_field) ? $address_field->get_value_export($entry) : '';
						if ($address_value) {
							$args[$field->slug] = trim($address_value);
						}
					} else {
						$args[$field->slug] = $entry[$mapping_values[$field->term_id]];
					}
					break;

				case '2':
					if ($gravity_field['type'] == 'select' || $gravity_field['inputType'] == 'select') {
						$wpsc_tf_options = get_term_meta($field->term_id, 'wpsc_tf_options', true);
						if (in_array($entry[$mapping_values[$field->term_id]], $wpsc_tf_options)) {
							$args[$field->slug] = $entry[$mapping_values[$field->term_id]];
						}
					}
					break;

				case '3':
					if ($gravity_field['type'] == 'checkbox' || $gravity_field['inputType'] == 'checkbox') {
						$checkbox_field = GFFormsModel::get_field($form_id, $mapping_values[$field->term_id]);
						$checkbox_value = is_object($checkbox_field) ? $checkbox_field->get_value_export($entry) : '';
						$wpsc_tf_options = get_term_meta($field->term_id, 'wpsc_tf_options', true);
						if ($checkbox_value) {
							$checkbox_value = array_map('trim', explode(',', $checkbox_value));
							$common_value = array_intersect($wpsc_tf_options, $checkbox_value);
							$args[$field->slug] = $common_value;
						}
					}
					break;

				case '4':
					if ($gravity_field['type'] == 'radio' || $gravity_field['inputType'] == 'radio') {
						$wpsc_tf_options = get_term_meta($field->term_id, 'wpsc_tf_options', true);
						if (in_array($entry[$mapping_values[$field->term_id]], $wpsc_tf_options)) {
							$args[$field->slug] = $entry[$mapping_values[$field->term_id]];
						}
					}
					break;

				case '5':
					if ($gravity_field['type'] == 'fileupload' || $gravity_field['inputType'] == 'fileupload') {
						continue;
					} else if ($gravity_field['type'] == 'address' || $gravity_field['inputType'] == 'address' || $gravity_field['inputType'] == 'list' || $gravity_field['type'] == 'list') {
						$address_field = GFFormsModel::get_field($form_id, $mapping_values[$field->term_id]);
						$address_value = is_object($address_field) ? $address_field->get_value_export($entry) : '';
						if ($address_value) {
							$args[$field->slug] = trim($address_value);
						}
					} else {
						$args[$field->slug] = $entry[$mapping_values[$field->term_id]];
					}
					break;

				case '7':
					if ($gravity_field['type'] == 'website' || $gravity_field['inputType'] == 'website') {
						$args[$field->slug] = $entry[$mapping_values[$field->term_id]];
					}
					break;

				case '8':
					if ($gravity_field['type'] == 'email' || $gravity_field['inputType'] == 'email') {
						$args[$field->slug] = $entry[$mapping_values[$field->term_id]];
					}
					break;

				case '9':
					if ($gravity_field['type'] == 'number' || $gravity_field['inputType'] == 'number') {
						$args[$field->slug] = $entry[$mapping_values[$field->term_id]];
					}
					break;

				case '10':
					if ($gravity_field['type'] == 'fileupload' || $gravity_field['inputType'] == 'fileupload' || $gravity_field['type'] == 'post_image') {
						if (isset($entry[$mapping_values[$field->term_id]]) && $entry[$mapping_values[$field->term_id]]) {
							$attachment_ids = array();
							$attachment_ids = $wpscgffunction->upload_file($mapping_values[$field->term_id], $entry, $form);
							$args[$field->slug] = $attachment_ids;
						}
					}
					break;

				case '6':
					if ($gravity_field['type'] == 'date' || $gravity_field['inputType'] == 'date') {
						$args[$field->slug] = $wpscfunction->calenderDateFormatToDateTime($entry[$mapping_values[$field->term_id]]);
					}
					break;
				
				case '21':
					if ($gravity_field['type'] == 'time' || $gravity_field['inputType'] == 'time') {
						$args[$field->slug] = date("H:i:s " ,strtotime($entry[$mapping_values[$field->term_id]]));
					}
					break;


				default:
					if (isset($mapping_values[$field->term_id]) && $mapping_values[$field->term_id]) {

						if (($gravity_field['type'] == 'name' && $field->slug == 'customer_name') || ($gravity_field['inputType'] == 'name' && $field->slug == 'customer_name')) {
							$name_field = GFFormsModel::get_field($form_id, $mapping_values[$field->term_id]);
							$name_value = is_object($name_field) ? $name_field->get_value_export($entry) : '';
							if ($name_value) {
								$args[$field->slug] = $name_value;
							}
						} elseif ($field->slug == 'ticket_description') {
							if ($gravity_field['type'] == 'fileupload' || $gravity_field['inputType'] == 'fileupload') {
								continue;
							} else if ($gravity_field['type'] == 'address' || $gravity_field['inputType'] == 'address' || $gravity_field['inputType'] == 'list' || $gravity_field['type'] == 'list') {
								$address_field = GFFormsModel::get_field($form_id, $mapping_values[$field->term_id]);
								$address_value = is_object($address_field) ? $address_field->get_value_export($entry) : '';
								if ($address_value) {
									$args[$field->slug] = trim($address_value);
								}
							} else {
								$args[$field->slug] = $entry[$mapping_values[$field->term_id]];
							}
						} else {
							$args[$field->slug] = $entry[$mapping_values[$field->term_id]];
						}
					}
					break;
			}
		}
	}

	//Create Ticket
	$ticket_id = $wpscfunction->create_ticket($args);

}