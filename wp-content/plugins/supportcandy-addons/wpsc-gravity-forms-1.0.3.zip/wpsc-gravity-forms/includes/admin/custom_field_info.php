<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $current_user, $wpscfunction,$wpdb;
if (!($current_user->ID && $current_user->has_cap('manage_options'))) {
	exit;
}

$term_id 			= isset($_POST['term_id']) ? sanitize_text_field($_POST['term_id']) : '' ;
$term         = get_term_by('id',$term_id,'wpsc_ticket_custom_fields');

$wpsc_appearance_modal_window = get_option('wpsc_modal_window');
ob_start();
?>
<div class="row" style="padding-left:2px;">
  <div>
    <p class="help-block"><?php _e('Below are option label and its values given for you to use while creating custom field option in Gravity Form compatible to this custom field. You can use any label in Gravity Form but values must be the same in order to pipe it correctly. If value does not matches to any option in Supportcandy field, it will use either default value(if available) or blank.','wpsc-gf')?></p>           
	</div>
	<div>
		<table class="table table-bordered">
			<thead>
				<tr class="info">
          <th><?php _e('Label','wpsc-gf')?></th>
          <th><?php _e('Value','wpsc-gf')?></th>
        </tr>	
			</thead>
			<tbody>
				<?php 
					if($term->slug == 'ticket_category'){
							$categories = get_terms([
								'taxonomy'   => 'wpsc_categories',
								'hide_empty' => false,
								'orderby'    => 'meta_value_num',
								'order'    	 => 'ASC',
								'meta_query' => array('order_clause' => array('key' => 'wpsc_category_load_order')),
							]);
							foreach ( $categories as $category ) :
								$wpsc_custom_category_localize = get_option('wpsc_custom_category_localize');
								$category_id   = $category->term_id;
								$wpsc_custom_category_localize['custom_category_'.$category_id];
								$cat_info =  get_term($category_id);
								$slug     =  $cat_info->term_id;
								?>
								<tr>
									<td><?php echo $wpsc_custom_category_localize['custom_category_'.$category_id]; ?></td>
									<td><?php echo $slug ?> </td> 
								</tr>	
								<?php 
							endforeach;
							
					}elseif ($term->slug == 'ticket_priority') {
						$priorities = get_terms([
							'taxonomy'   => 'wpsc_priorities',
							'hide_empty' => false,
							'orderby'    => 'meta_value_num',
							'order'    	 => 'ASC',
							'meta_query' => array('order_clause' => array('key' => 'wpsc_priority_load_order')),
						]);
						
						foreach ( $priorities as $priority ) :
							$wpsc_custom_priority_localize = get_option('wpsc_custom_priority_localize');
							$priority_info =  get_term($priority->term_id);
							$slug          =  $priority_info->term_id;
							?>
							<tr>
								<td><?php echo $wpsc_custom_priority_localize['custom_priority_'.$priority->term_id]; ?> </td>
 							  <td><?php echo $slug ?></td>	
							</tr>
						<?php   
						endforeach;
					}else{
						$options = get_term_meta( $term->term_id, 'wpsc_tf_options', true);
						foreach ($options as $key => $value ): 
							?>
							<tr>
								<td><?php echo $value ?></td>
								<td><?php echo $value ?></td>	
							</tr>
							<?php
						endforeach;
					}  ?>
			</tbody>
		</table>
	</div>
</div>
<?php 
$body = ob_get_clean();
ob_start();
?>
  <button type="button" class="btn wpsc_popup_close"  style="background-color:<?php echo $wpsc_appearance_modal_window['wpsc_close_button_bg_color']?> !important;color:<?php echo $wpsc_appearance_modal_window['wpsc_close_button_text_color']?> !important;"    onclick="wpsc_modal_close();"><?php _e('Close','supportcandy');?></button>
<?php 
$footer = ob_get_clean();

$output = array(
  'body'   => $body,
  'footer' => $footer
);

echo json_encode($output);

