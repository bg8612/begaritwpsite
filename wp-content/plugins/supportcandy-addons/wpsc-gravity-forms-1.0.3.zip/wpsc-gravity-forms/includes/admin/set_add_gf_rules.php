<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $current_user, $wpscfunction,$wpdb;
if (!($current_user->ID && $current_user->has_cap('manage_options'))) {
	exit;
}

//Gravity form id
$wpsc_gravity_form_id = isset($_POST) && isset($_POST['wpsc_gravity_form_id']) ? sanitize_text_field($_POST['wpsc_gravity_form_id']) : '';
if (!$wpsc_gravity_form_id) {
  echo '{ "sucess_status":"0","messege":"'.__('Gravity Form must be selected.','wpsc-gf').'" }';
  exit;
}

$form = GFAPI::get_form( $wpsc_gravity_form_id );

if(!$wpsc_gravity_form_id){
	echo '{ "sucess_status":"0","messege":"'.__('Gravity Form must be selected.','wpsc-gf').'" }';
}else{
  $term = wp_insert_term( $form['title'], 'wpsc_gf' );
  if(!is_wp_error($term) && isset($term['term_id'])){
    add_term_meta ($term['term_id'], 'wpsc_gravity_form_id', $wpsc_gravity_form_id);
    
    do_action('wpsc_set_add_gravity_form_setting', $term['term_id']);
  }
	
	echo '{ "sucess_status":"1","messege":"'.__('Settings saved.','wpsc-gf').'","term_id":"'.$term['term_id'].'" }';
}