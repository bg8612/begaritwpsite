<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
?>

<li id="wpsc_gravity_form_integration" role="presentation"><a href="javascript:wpsc_get_gravity_form_setting();"><?php _e('Gravity Forms','wpsc-gf');?></a></li>

<script>
   function wpsc_get_gravity_form_setting(){
    jQuery('.wpsc_setting_pills li').removeClass('active');
    jQuery('#wpsc_gravity_form_integration').addClass('active');
    jQuery('.wpsc_setting_col2').html(wpsc_admin.loading_html);
    var data = {
      action: 'wpsc_get_gravity_form_setting',
    };
    jQuery.post(wpsc_admin.ajax_url, data, function(response) {
      jQuery('.wpsc_setting_col2').html(response);
    });
  }
</script>
