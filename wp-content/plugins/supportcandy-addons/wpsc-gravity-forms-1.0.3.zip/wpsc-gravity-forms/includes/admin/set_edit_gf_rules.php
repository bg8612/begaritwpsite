<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $current_user, $wpscfunction;
if (!($current_user->ID && $current_user->has_cap('manage_options'))) {
	exit;
}

$term_id = isset($_POST) && isset($_POST['term_id']) ? intval($_POST['term_id']) : 0;
if(!$term_id) die();

$gravity_form_id = isset($_POST) && isset($_POST['wpsc_gravity_form_id']) ? intval($_POST['wpsc_gravity_form_id']) : 0;
update_term_meta($term_id,'wpsc_gravity_form_id',$gravity_form_id);

$wpsc_gf_mapping_values = isset($_POST) && isset($_POST['wpsc_gf_mapping_values']) ? $wpscfunction->sanitize_array($_POST['wpsc_gf_mapping_values']) : array();

$wpsc_sc_custom_field = isset($_POST) && isset($_POST['wpsc_sc_custom_field']) ? $wpscfunction->sanitize_array($_POST['wpsc_sc_custom_field']) : array();

$wpsc_gf_mappings = array_combine($wpsc_sc_custom_field,$wpsc_gf_mapping_values);

$name_term = get_term_by('slug','customer_name','wpsc_ticket_custom_fields');
$email_term = get_term_by('slug','customer_email','wpsc_ticket_custom_fields');

if(!($wpsc_gf_mappings[$name_term->term_id] && $wpsc_gf_mappings[$email_term->term_id])){
	echo '{ "sucess_status":"0","messege":"'.__('Name and Email must be selected.','wpsc-gf').'" }';
}else{
	update_term_meta ($term_id, 'wpsc_gf_mapping_values', $wpsc_gf_mappings);
	do_action('wpsc_set_edit_gravity_form_setting',$term_id);
	echo '{ "sucess_status":"1","messege":"'.__('Settings saved.','wpsc-gf').'" }';
}
