<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $current_user, $wpscfunction,$wpdb;
if (!($current_user->ID && $current_user->has_cap('manage_options'))) {
	exit;
}

$form_id = $form['id'];
$form = GFAPI::get_form( $form_id );

$args = array(
'hide_empty' => false,
'meta_query' => array(
    array(
       'key'       => 'wpsc_gravity_form_id',
       'value'     => $form_id,
       'compare'   => '='
    )
),
'taxonomy'  => 'wpsc_gf',
);

$terms = get_terms( $args );

if( $terms){
	$wpsc_gf_id = get_term_meta($terms[0]->term_id,'wpsc_gravity_form_id',true);
	if( $wpsc_gf_id == $form_id ){
		wp_update_term($terms[0]->term_id,'wpsc_gf',array('name' => $form['title']));
	}
}
