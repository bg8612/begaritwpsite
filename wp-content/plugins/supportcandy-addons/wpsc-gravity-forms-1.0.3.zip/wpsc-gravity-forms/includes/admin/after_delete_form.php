<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $current_user, $wpscfunction;
if (!($current_user->ID && $current_user->has_cap('manage_options'))) {
	exit;
}

$gravity_forms = get_terms([
  'taxonomy'   => 'wpsc_gf',
	'hide_empty' => false
]);

foreach ($gravity_forms as $key => $gravity_form) {
  $gravity_form_id = get_term_meta($gravity_form->term_id,'wpsc_gravity_form_id',true);
	if($gravity_form_id==$form_id) {
		wp_delete_term($gravity_form->term_id, 'wpsc_gf');
  }
}
