<?php 
global $wpdb,$post_id;
final class WPSC_SupportCandy_GF_Backend{
  
   public function __construct() {
    add_action( 'admin_enqueue_scripts', array( $this, 'loadScripts') );
   }

   public function loadScripts(){
      wp_enqueue_script('jquery');
      wp_enqueue_script('jquery-ui-core');
      wp_enqueue_script('wpsc_gravity_admin', WPSC_GF_PLUGIN_URL.'asset/js/admin.js?version='.WPSC_GF_VERSION, array('jquery'), null, true);
  }  
   
   // Gravity form integration tab
   function gravity_form_setting_pill(){
     include WPSC_GF_ABSPATH.'includes/admin/gravity_form_setting_pill.php';
   }
   
   // get gravity form settings
   function get_gravity_form_settings(){
     include WPSC_GF_ABSPATH.'includes/admin/get_gravity_form_settings.php';
     die();
   }
   
   
   // get edit exsting form rules
   function get_edit_gf_rules(){
    include WPSC_GF_ABSPATH . 'includes/admin/get_edit_gf_rules.php';
    die(); 
   }
   
   // save after edit gravity form rules
   function set_edit_gf_rules(){
     include WPSC_GF_ABSPATH . 'includes/admin/set_edit_gf_rules.php';
     die(); 
   }
   
   // get edit gravity form values
   function get_edit_gf_values(){
     include WPSC_GF_ABSPATH . 'includes/admin/get_edit_gf_values.php';
     die();
   }
   
   // delete supportcandy gravity form integration rules
   function delete_gf_rules(){
     include WPSC_GF_ABSPATH . 'includes/admin/delete_gf_rules.php';
     die();
   }
   
   // save gravity form rule order
   function set_gf_rule_list_order(){
     include WPSC_GF_ABSPATH . 'includes/admin/set_gf_rule_list_order.php';
     die();
   }
   
   // Apply gravity form rule and create new supportcandy ticket
   function gf_after_submission($entry, $form){
     include WPSC_GF_ABSPATH . 'includes/admin/gf_after_submission.php';
   }
   
   // Add-on installed or not for licensing
   function is_add_on_installed($flag){
     return true;
   }
 
   // Print license functionlity for this add-on
   function addon_license_area(){
     include WPSC_GF_ABSPATH . 'includes/addon_license_area.php';
   }
 
   // Activate Timer license
   function license_activate(){
     include WPSC_GF_ABSPATH . 'includes/license_activate.php';
     die();
   }
 
   // Deactivate Timer license
   function license_deactivate(){
     include WPSC_GF_ABSPATH . 'includes/license_deactivate.php';
     die();
   }
    
   // diplay gravity form info icon
   function custom_fields_option_details($term_id){
    $type = get_term_meta($term_id, 'wpsc_tf_type', true);
    $tf   = get_term_by('id', $term_id, 'wpsc_ticket_custom_fields');
    if ($tf->slug == 'ticket_category' || $tf->slug == 'ticket_priority' || $type == '2' || $type == '3' || $type == '4') {
      ?>
       <div class="wpsc-sortable-wpsc-gravity" style="cursor:pointer;" onclick="wpsc_get_form_field_info(<?php echo $term_id ?>);" title="Gravity form integration" ><i class="fab fa-goodreads-g"></i></div>
      <?php
    }
  }      
  
  // display custom fields info 
  function custom_field_info(){
    include WPSC_GF_ABSPATH . 'includes/admin/custom_field_info.php';
    die();
  }
  
  // Add new gravity form
  function get_add_gf_rules(){
    include WPSC_GF_ABSPATH . 'includes/admin/get_add_gf_rules.php';
    die();  
  }
  
  // save new form
  function set_add_gf_rules(){
    include WPSC_GF_ABSPATH . 'includes/admin/set_add_gf_rules.php';
    die();
  }
  
  // After Form Save
  function after_save_form($form,$is_new){
    if ( $is_new ) {
       return;
     }
     include WPSC_GF_ABSPATH . 'includes/admin/after_save_form.php';
  }
  
  // After form delete 
  function after_delete_form($form_id){
    include WPSC_GF_ABSPATH . 'includes/admin/after_delete_form.php';
  } 
}

