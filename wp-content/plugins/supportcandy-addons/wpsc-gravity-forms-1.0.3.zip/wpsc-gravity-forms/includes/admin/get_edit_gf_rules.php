<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $current_user, $wpscfunction,$wpdb;
if (!($current_user->ID && $current_user->has_cap('manage_options'))) {
	exit;
}

$term_id = isset($_POST) && isset($_POST['term_id']) ? intval($_POST['term_id']) : 0;
if(!$term_id) die();

$term = get_term_by('id',$term_id,'wpsc_gf');

$form_id           = get_term_meta($term_id,'wpsc_gravity_form_id',true);
$wpsc_support_form = get_term_meta($term_id,'wpsc_support_form',true);

$mapping_values = get_term_meta($term_id, 'wpsc_gf_mapping_values', true);

// Custom Field Values
$custom_fields = get_terms([
	'taxonomy'   => 'wpsc_ticket_custom_fields',
	'hide_empty' => false,
	'orderby'    => 'meta_value_num',
	'meta_key'	 => 'wpsc_tf_load_order',
	'order'    	 => 'ASC',
	'meta_query' => array(
		'relation' => 'AND',
		array(
			'key'       => 'agentonly',
      'value'     => '0',
			'compare'   => '='
		),
	)
]);

$form = GFAPI::get_form( $form_id );
$gf_form_fields = $form['fields'];

?>
<h4 style="margin-bottom:20px;"><?php _e('Gravity Forms / '.$form['title'],'wpsc-gf');?></h4>

<form id="wpsc_gf_edit_rules_frm" action="javascript:wpsc_set_edit_gf_rules();" method="post">
    <?php $type = get_term_meta($term_id,'wpsc_gravity_form_id',true);?>
    <?php
			if($form_id) {
				?>
				<div class="wpsp_gf_selected_container" id="wpsc_gf_selected_container">
				  <div id="wpsc_gravity_form_values" name="wpsc_gravity_form_values" class="wpsc_gravity_form_values"></div>
					<table id='wpsc_gravity_field_mapping' class="table">
						<thead>
							<tr>
								<td>
									<label><?php _e('Custom Fields','wpsc-gf');?></label>
								</td>
								<td>
									<label><?php _e('Gravity Form lable','wpsc-gf');?></label>
							   	<p class="help-block"><?php _e('Select field to compare for piping.','wpsc-gf');?></p>
								</td>
							</tr>
						</thead>
						<tbody>
							<?php 
								foreach ( $custom_fields as $field) {
									$label = get_term_meta($field->term_id, 'wpsc_tf_label', true);
									?>
									<tr>
										<td>
											<h5><?php _e($label,'wpsc-gf');?></h5>
											<input type="hidden" class="form-control" name="wpsc_sc_custom_field[]" id="wpsc_sc_custom_field" value="<?php echo $field->term_id?>" />
										</td>
										<td>
											<select id="<?php echo $field->slug?>" class="form-control" name="wpsc_gf_mapping_values[]">
												<option value=""></option>
												<?php
												foreach ($gf_form_fields as $key => $gfield) {
													$selected = '';
													if($mapping_values){
														$map_key = $mapping_values[$field->term_id];
														$selected = ($gfield->id==$map_key) ? 'selected="selected"':'';
													}
													?>
											    <option <?php echo $selected ?> value="<?php echo $gfield->id?>"><?php echo $gfield->label?></option>
													<?php
												}
												?>
											</select>
										</td>
									</tr>
									<?php
								}
							?>
						</tbody>
					</table>
				</div>
		   <?php
		 } 
		?>
		
	<button type="submit" style="margin-top:10px;" class="btn btn-success" id="wpsc_save_changes_atc_btn"><?php _e('Save Changes','wpsc-gf');?></button>
  <img class="wpsc_submit_wait" style="display:none;" src="<?php echo WPSC_PLUGIN_URL.'asset/images/ajax-loader@2x.gif';?>">
	<input type="hidden" name="action" value="wpsc_set_edit_gf_rules" />
	<input type="hidden" name="term_id" value="<?php echo $term_id?>">
	<input type="hidden" name="wpsc_gravity_form_id" value="<?php echo $form_id ?>">
</from>

<style media="screen">
	#wpsc_gravity_field_mapping tr > td{
		border: 0px;
	}
</style>
<script>
	
jQuery(function() {
  jQuery("#wpsc_gravity_form_id").change(function() {
		var frm_id = jQuery('#wpsc_gravity_form_id option:selected').val();
		var data = {
      action : 'wpsc_get_edit_gf_values',
			frm_id : frm_id
    };
		jQuery.post(wpsc_admin.ajax_url, data, function(response_str) {
			 var response = JSON.parse(response_str);
			 jQuery('.wpsc_gravity_form_values').html(response.field_lable);
    });
  });
});


jQuery(document).ready(function() {
		
});

</script>