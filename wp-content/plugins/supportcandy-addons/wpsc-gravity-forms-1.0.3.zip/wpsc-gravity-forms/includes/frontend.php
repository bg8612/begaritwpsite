<?php 
final class WPSC_SupportCandy_GF_Frontend{
}