<?php
if ( ! defined( 'ABSPATH' ) ) {
  exit; // Exit if accessed directly
}

if ( ! class_exists( 'Gravity_form_Functions' ) ) :
  
  final class Gravity_form_Functions {
    
    function upload_file($field_id,$entry,$form){
      $gravity_field = RGFormsModel::get_field( $form, $field_id );
      $attachment_ids = array();
      if($gravity_field->multipleFiles){
        $wpsc_gf_files = json_decode($entry[$field_id]);
        foreach ($wpsc_gf_files as $key => $file) {
          $attachment_ids[] = $this->wpsc_gf_upload_file_to_sc($file);
        }
      }else{
        $attachment_ids[] = $this->wpsc_gf_upload_file_to_sc($entry[$field_id]);
      }
      
      return $attachment_ids;
    }
    
    function wpsc_gf_upload_file_to_sc($file){
      
      $attachment_count = get_option('wpsc_attachment_count');
      if(!$attachment_count) $attachment_count = 1;
      $term = wp_insert_term( 'attachment_'.$attachment_count, 'wpsc_attachment' );
      if(!$term) die();
      update_option('wpsc_attachment_count',++$attachment_count);

      $upload_dir = wp_upload_dir();
      if (!file_exists($upload_dir['basedir'] . '/wpsc/')) {
          mkdir($upload_dir['basedir'] . '/wpsc/', 0755, true);
      }
      
      $path_parts = pathinfo($file);
      
      add_term_meta ($term['term_id'], 'filename', $path_parts['basename']);      

      $img_extensions = array('png','jpeg','jpg','bmp','pdf','PNG','JPEG','JPG','BMP','PDF');
      $extension      = $path_parts['extension'];
      if(!in_array($extension, $img_extensions)){
        $extension = $extension.'.txt';
        add_term_meta ($term['term_id'], 'is_image', '0');
      } else {
        add_term_meta ($term['term_id'], 'is_image', '1');
      }

      $save_file_name = time().'_'.preg_replace('/[^A-Za-z0-9\-]/', '', $path_parts['filename']).'.'.$extension;

      $save_directory = $upload_dir['basedir'] . '/wpsc/'.$save_file_name;
      
      if (strpos($file, '|') == true) { 
        $fpath = explode('|', $file);
        $gfpath = realpath($_SERVER['DOCUMENT_ROOT'] . parse_url( $fpath[0], PHP_URL_PATH ));
      } else{
        $gfpath = realpath($_SERVER['DOCUMENT_ROOT'] . parse_url( $file, PHP_URL_PATH ));
      }
      
      copy( $gfpath, $save_directory );
      
      add_term_meta ($term['term_id'], 'save_file_name', $save_file_name);
      add_term_meta ($term['term_id'], 'active', '0');
      add_term_meta ($term['term_id'], 'time_uploaded', date("Y-m-d H:i:s"));

      return $term['term_id'];
    }
  }
endif;

$GLOBALS['wpscgffunction'] =  new Gravity_form_Functions();
