function wpsc_get_form_field_info(term_id){
  wpsc_modal_open('Gravity Forms'); 
   var data = {
     action: 'wpsc_custom_field_info',
     term_id: term_id
   }
   jQuery.post(wpsc_admin.ajax_url, data, function(response_str) { 
     var response = JSON.parse(response_str);  
     jQuery('#wpsc_popup_body').html(response.body);
     jQuery('#wpsc_popup_footer').html(response.footer);
   })
}