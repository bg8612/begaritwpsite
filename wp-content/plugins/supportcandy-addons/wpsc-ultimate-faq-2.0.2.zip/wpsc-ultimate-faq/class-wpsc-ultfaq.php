<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if ( ! class_exists( 'WPSC_ULTFAQ' ) ) :
  
  final class WPSC_ULTFAQ {
		
		function faq_setting_pill(){
			include WPSC_ULTFAQ_ABSPATH . 'includes/faq_setting_pill.php';
		}
		
		function get_faq_settings(){
			include WPSC_ULTFAQ_ABSPATH . 'includes/get_faq_settings.php';
			die();
		}
		
		function set_faq_settings(){
			include WPSC_ULTFAQ_ABSPATH . 'includes/set_faq_settings.php';
			die();
		}
    
		function faq_macro(){
			include WPSC_ULTFAQ_ABSPATH . 'includes/faq_macro.php';
		}
		
		function get_ultfaqs(){
			include WPSC_ULTFAQ_ABSPATH . 'includes/get_ultfaqs.php';
			die();
		}
		
		function insert_link(){
			include WPSC_ULTFAQ_ABSPATH . 'includes/insert_link.php';
			die();
		}
		
		function insert_text(){
			include WPSC_ULTFAQ_ABSPATH . 'includes/insert_text.php';
			die();
		}
		
		function replace_macro($str,$ticket_id){
			include WPSC_ULTFAQ_ABSPATH . 'includes/replace_macro.php';
			return $str;
		}
		
		//acronix faq Files
		
		function acronix_faq_macro(){
			include WPSC_ULTFAQ_ABSPATH . 'includes/Acronix-faq/faq_macro.php';
		}
		
		function get_acorfaqs(){
			include WPSC_ULTFAQ_ABSPATH . 'includes/Acronix-faq/get_accorfaqs.php';
			die();
		}
		
		function acronix_insert_link(){
			include WPSC_ULTFAQ_ABSPATH . 'includes/Acronix-faq/insert_link.php';
			die();
		}
		
		function acronix_insert_text(){
			include WPSC_ULTFAQ_ABSPATH . 'includes/Acronix-faq/insert_text.php';
			die();
		}
		
		function acronix_replace_macro($str,$ticket_id){
			include WPSC_ULTFAQ_ABSPATH . 'includes/Acronix-faq/replace_macro.php';
			return $str;
		}
		
		// Add-on installed or not for licensing
		function is_add_on_installed($flag){
    	return true;
		}
		
		// Print license functionlity for this add-on
		function addon_license_area(){
			include WPSC_ULTFAQ_ABSPATH . 'includes/addon_license_area.php';
		}
		
		// Activate UltimateFAQ license
		function license_activate() {
			include WPSC_ULTFAQ_ABSPATH . 'includes/license_activate.php';
      die();
		}
		
		// Deactivate UltimateFAQ license
		function license_deactivate() {
			include WPSC_ULTFAQ_ABSPATH . 'includes/license_deactivate.php';
 		  die();	
		}
  }
  
endif;