<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if ( ! class_exists( 'WPSC_ULTFAQ_Install' ) ) :
  
  final class WPSC_ULTFAQ_Install {
    
    public function __construct() {
      $this->check_version();
    }
    
		/**
     * Check version of WPSC
     */
    public function check_version(){
        $installed_version = get_option( 'wpsc_ultfaq_current_version', 0 );
        if( $installed_version != WPSC_ULTFAQ_VERSION ){
            add_action( 'init', array($this,'upgrade'), 101 );
        }

    }
    
    // Upgrade
		public function upgrade(){
				
        $installed_version = get_option( 'wpsc_ultfaq_current_version', 0 );
				$installed_version = $installed_version ? $installed_version : 0;
				
				if ( $installed_version < '1.0.0' ) {
					
					$term = wp_insert_term( 'ultimate_faq_suggestions', 'wpsc_ticket_custom_fields' );
					if ( !is_wp_error($term) && isset($term['term_id'])) {
						add_term_meta ($term['term_id'], 'wpsc_tf_label', __('FAQ Suggestions','wpsc'));
						add_term_meta ($term['term_id'], 'agentonly', '2');
						add_term_meta ($term['term_id'], 'wpsc_tf_type', '0');
						add_term_meta ($term['term_id'], 'wpsc_allow_ticket_list', '0');
						add_term_meta ($term['term_id'], 'wpsc_allow_ticket_filter', '0');
					}
				
    		}
				if ( $installed_version < '1.0.1' ) {
						
						$term = wp_insert_term( 'acronix_faq_suggestions', 'wpsc_ticket_custom_fields' );
						if ( !is_wp_error($term) && isset($term['term_id'])) {
								add_term_meta ($term['term_id'], 'wpsc_tf_label', __('FAQ Suggestions','wpsc-faq'));
								add_term_meta ($term['term_id'], 'agentonly', '2');
								add_term_meta ($term['term_id'], 'wpsc_tf_type', '0');
								add_term_meta ($term['term_id'], 'wpsc_allow_ticket_list', '0');
								add_term_meta ($term['term_id'], 'wpsc_allow_ticket_filter', '0');
								
						}
						
						update_option('wpsc_select_faq_set','WPSC_Ultimate_FAQ');
				}
        
        update_option( 'wpsc_ultfaq_current_version', WPSC_ULTFAQ_VERSION );
        
    }
    
  }
  
endif;

new WPSC_ULTFAQ_Install();
