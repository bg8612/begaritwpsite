<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
$select_faq = get_option('wpsc_select_faq_set','');
?>
<h4>
	<?php _e('Select Integration','wpsc-ultfaq');?>	
</h4><br />
<form id="wpsc_frm_faq_settings" method="post" action="javascript:wpsc_set_faq_settings();">
	<div class="row">
		<div class="col-sm-4" style="margin-bottom:10px; display:flex; width:">
			<div style="width:25px;">
				<input type="radio" class="wpsp_faq_addon_name" name="wpsp_faq_addon_name" value="WPSC_Ultimate_FAQ" <?php echo ($select_faq=='WPSC_Ultimate_FAQ')?'checked="checked"':''; ?> > 
			</div>
			<div style="padding-top:3px;">
				<?php _e('Ultimate FAQ (<a href="https://wordpress.org/plugins/ultimate-faqs/" target="_blank">Plugin Url</a>)','wpsc-ultfaq');?>
			</div>
		</div>
		<div class="col-sm-6">
		<?php if($select_faq=='WPSC_Ultimate_FAQ' && !function_exists('Set_EWD_UFAQ_Options')){?><div class="wpsc_faq_notice"> (<?php _e('Please Install Ultimate FAQ Plugin.','wpsc-uttfaq');?>)</div><?php } ?>	
		</div>
	</div>
	
	<div class="row">
		<div class="col-sm-4" style="margin-bottom:10px; display:flex; width: unset;">
			<div style="width:25px;">
				<input type="radio" class="wpsp_faq_addon_name" name="wpsp_faq_addon_name" value="WPSC_Acronix_FAQ" <?php echo ($select_faq=='WPSC_Acronix_FAQ')?'checked="checked"':''; ?> >	
			</div>
			<div style="padding-top:3px;">
				<?php _e('Acronix FAQ (<a href="https://wordpress.org/plugins/arconix-faq/" target="_blank">Plugin Url</a>)','wpsc-ultfaq');?> 
			</div>	
		</div>
		<div class="col-sm-6">
		<?php if($select_faq=='WPSC_Acronix_FAQ' && !class_exists('Arconix_FAQ')){?><div class="wpsc_faq_notice"> (<?php _e('Please Install Acronix FAQ Plugin.','wpsc-uttfaq');?>)</div><?php } ?>	
		</div>
	</div> 
  <br />
  <button type="submit" class="btn btn-success" id="wpsc_save_faq_settings_btn"><?php _e('Save Changes','wpsc-ultfaq');?></button>
  <img class="wpsc_submit_wait" style="display:none;" src="<?php echo WPSC_PLUGIN_URL.'asset/images/ajax-loader@2x.gif';?>">
  <input type="hidden" name="action" value="wpsc_set_faq_settings" />
  
</form>
<script>
function wpsc_set_faq_settings(){
  var dataform = new FormData(jQuery('#wpsc_frm_faq_settings')[0]);
  dataform.append('action', 'wpsc_set_faq_settings');
  jQuery('.wpsc_reply_widget').html(wpsc_admin.loading_html);
  jQuery.ajax({
    url: wpsc_admin.ajax_url,
    type: 'POST',
    data: dataform,
    processData: false,
    contentType: false
  })
  .done(function (response_str) {
    var response = JSON.parse(response_str);
     if (response.sucess_status=='1') {
       jQuery('#wpsc_alert_success .wpsc_alert_text').text(response.messege);
       jQuery('#wpsc_alert_success').slideDown('fast',function(){});
       setTimeout(function(){ jQuery('#wpsc_alert_success').slideUp('fast',function(){}); }, 3000);       
     } else {
       jQuery('#wpsc_alert_error .wpsc_alert_text').text(response.messege);
       jQuery('#wpsc_alert_error').slideDown('fast',function(){});
       setTimeout(function(){ jQuery('#wpsc_alert_error').slideUp('fast',function(){}); }, 3000);
     }
		 wpsc_get_faq_settings();
  }); 
}
</script>
<style>
	.wpsc_faq_notice{
		color: #b72929;
		margin-top: 3px;
	}
</style>