<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $current_user;
$select_faq_setting = get_option('wpsc_select_faq_set','');
if(!$current_user->ID || !$current_user->has_cap('wpsc_agent') || !function_exists('Set_EWD_UFAQ_Options')) return;
if($select_faq_setting=='WPSC_Ultimate_FAQ'){
?>
<span onclick="wpsc_get_ultfaqs()" ><?php _e('FAQs','wpsc-ultfaq')?></span>
<?php } ?>
<script>
  function wpsc_get_ultfaqs(){
    wpsc_modal_open("<?php _e('FAQs','wpsc-ultfaq')?>");
    var data = {
      action: 'wpsc_get_ultfaqs'  
    };
    jQuery.post(wpsc_admin.ajax_url, data, function(response_str) {
      var response = JSON.parse(response_str);
      jQuery('#wpsc_popup_body').html(response.body);
      jQuery('#wpsc_popup_footer').html(response.footer);
      jQuery('#wpsc_cat_name').focus();
    });
  }
</script>