<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
global $wpscfunction;
$ticket_subject = $wpscfunction->get_ticket_fields($ticket_id,'ticket_subject');
$ticket_subject = explode(' ',$ticket_subject);

$args = array(
	'post_type'      => 'faq',
	'post_status'    => 'publish',
	'posts_per_page' => 3,
  'tax_query'   => array( 
    array(
      'taxonomy' => 'group',
      'field'    => 'name',
      'terms'    => $ticket_subject,
      'operator' => 'IN',
    )
  ),
);
$posts = get_posts($args);

$count = 0;
$replace_data = '<ul>';
foreach($posts as $faq){
  $count ++;
  $replace_data .= '<li><a href="'.get_permalink($faq->ID).'" target="_blank">'.$faq->post_title.'</a></li>';
}
$replace_data .= '</ul>';

if(!$count){
  $replace_data .= __('No FAQ suggestions found','wpsc-ultfaq');
}

$str = preg_replace('/{acronix_faq_suggestions}/', $replace_data, $str);
