<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $current_user;

if(!$current_user->ID || !$current_user->has_cap('wpsc_agent')|| !class_exists('Arconix_FAQ') ) exit;

$wpsc_appearance_modal_window = get_option('wpsc_modal_window');

$args = array(
	'post_type'      => 'faq',
	'post_status'    => 'publish',
	'posts_per_page' => -1
);

$posts = get_posts($args);
ob_start();
?>
<div class="table-responsive">
	<table id="tbl_templates"   class="table table-striped table-bordered"  cellspacing="5" cellpadding="5">
  <thead>
  	<tr>
      <th><?php _e('Insert','wpsc-ultfaq')?></th>
      <th><?php _e('FAQ','wpsc-ultfaq')?></th>
      <th><?php _e('Category','wpsc-ultfaq')?></th>
    </tr>
	</thead>
	<tbody>
	<?php
	
	foreach ($posts as $field) {			
		?>
		<tr>
	    <td> 
        <a class="wpsc_tag_td" href="javascript:wpsc_acorfaq_insert_link(<?php echo $field->ID?>);"><?php _e('Link','wpsc-ultfaq')?></a> | 
        <a class="wpsc_tag_td" href="javascript:wpsc_acorfaq_insert_text(<?php echo $field->ID?>);"><?php _e('Content','wpsc-ultfaq')?></a>
      </td>
      <td><?php echo $field->post_title?></td>
			<?php 				
			$categories = get_the_terms($field->ID, "group");				
      if( ! empty( $categories ) ) {					
        $category_name= array();					
        foreach ($categories as $category) {										  
          $category_name[] = $category->name;						
        }					
			  ?>
        <td><?php echo $category_name = implode(', ', $category_name);?></td>
        <?php
      }else {
        $category_name = __('Uncategorized','wpsc-ultfaq');
				?>
        <td><?php echo $category_name;?></td>
        <?php
      }
			?>
	  </tr>
		<?php
	}
	?>
	</tbody>
</table>
</div>
<link rel="stylesheet" type="text/css" href="<?php echo WPSC_PLUGIN_URL.'asset/lib/DataTables/datatables.min.css';?>"/>
<script type="text/javascript" src="<?php echo WPSC_PLUGIN_URL.'asset/lib/DataTables/datatables.min.js';?>"></script>
<script>
  jQuery(document).ready(function() {
    jQuery('#tbl_templates').DataTable({
  		 "aLengthMenu": [[4, 8, 12, -1], [4, 8, 12, "All"]]		
    });
  });
  function wpsc_acorfaq_insert_link(post_id){  
    var data = {
      action: 'wpsc_acorfaq_insert_link',
      post_id: post_id	     
    };  
    jQuery.post(wpsc_admin.ajax_url, data, function(response) {      
      var is_tinymce = (typeof tinyMCE != "undefined") && tinyMCE.activeEditor && !tinyMCE.activeEditor.isHidden();
      if (is_tinymce) {
				tinymce.activeEditor.execCommand('mceInsertContent', false, response);
			} else {
        var $txt = jQuery(".wpsc_textarea");
    	  var caretPos = $txt[0].selectionStart;
    	  var textAreaTxt = $txt.val();
    	  $txt.val(textAreaTxt.substring(0, caretPos) + response + textAreaTxt.substring(caretPos) );
      } 
      wpsc_modal_close();
    }); ;       
  }
  function wpsc_acorfaq_insert_text(post_id){  
     var data = {
      action: 'wpsc_acorfaq_insert_text',
      post_id: post_id	     
    };  
    jQuery.post(wpsc_admin.ajax_url, data, function(response) {      
      var is_tinymce = (typeof tinyMCE != "undefined") && tinyMCE.activeEditor && !tinyMCE.activeEditor.isHidden();
      if (is_tinymce) {
				tinymce.activeEditor.execCommand('mceInsertContent', false, response);
			} else {
        var $txt = jQuery(".wpsc_textarea");
    	  var caretPos = $txt[0].selectionStart;
    	  var textAreaTxt = $txt.val();
    	  $txt.val(textAreaTxt.substring(0, caretPos) + response + textAreaTxt.substring(caretPos) );
      }
      wpsc_modal_close();
    }); ;       
  }
</script>
<?php 
$body = ob_get_clean();
ob_start();
?>
<button type="button" class="btn wpsc_popup_close" style="background-color:<?php echo $wpsc_appearance_modal_window['wpsc_close_button_bg_color']?> !important;color:<?php echo $wpsc_appearance_modal_window['wpsc_close_button_text_color']?> !important;" onclick="wpsc_modal_close();"><?php _e('Close','wpsc-ultfaq');?></button>
<?php 
$footer = ob_get_clean();

$output = array(
  'body'   => $body,
  'footer' => $footer
);

echo json_encode($output);
