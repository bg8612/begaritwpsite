<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $current_user;
$select_faq_setting = get_option('wpsc_select_faq_set','');
if(!$current_user->ID || !$current_user->has_cap('wpsc_agent') || !class_exists('Arconix_FAQ')) return;
if($select_faq_setting=='WPSC_Acronix_FAQ'){
?>
<span onclick="wpsc_get_accor_faqs()" ><?php _e('FAQs','wpsc-ultfaq')?></span>
<?php } ?>
<script>
  function wpsc_get_accor_faqs(){
    
    wpsc_modal_open("<?php _e('FAQs','wpsc-ultfaq')?>");
    var data = {
      action: 'wpsc_get_acorfaqs'  
    };
    jQuery.post(wpsc_admin.ajax_url, data, function(response_str) {
      var response = JSON.parse(response_str);
      jQuery('#wpsc_popup_body').html(response.body);
      jQuery('#wpsc_popup_footer').html(response.footer);
      jQuery('#wpsc_cat_name').focus();
    });
  }
</script>