<?php 
/**
 * Plugin Name: SupportCandy - FAQ Integration
 * Plugin URI: https://supportcandy.net/
 * Description: Ultimate FAQ integration for SupportCandy
 * Version: 2.0.2
 * Author: Support Candy
 * Author URI: https://supportcandy.net/
 * Requires at least: 4.4
 * Tested up to: 4.9
 * Text Domain: wpsc-ultfaq
 * Domain Path: /lang
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if ( ! class_exists( 'Support_Candy_ULT_FAQ' ) ) :
  
  final class Support_Candy_ULT_FAQ {
    
    public $version = '2.0.2';
    
    public function __construct() {
			
			$this->define_constants();
			$this->includes();
			add_action( 'init', array($this,'load_textdomain') );
			
    }
    
    function define_constants() {
      $this->define('WPSC_ULTFAQ_PLUGIN_FILE', __FILE__);
      $this->define('WPSC_ULTFAQ_ABSPATH', dirname(__FILE__) . '/');
      $this->define('WPSC_ULTFAQ_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
      $this->define('WPSC_ULTFAQ_PLUGIN_BASENAME', plugin_basename(__FILE__));
			$this->define('WPSC_ULTFAQ_STORE_ID', '265');
      $this->define('WPSC_ULTFAQ_VERSION', $this->version);
    }
    
    function load_textdomain(){
      $locale = apply_filters( 'plugin_locale', get_locale(), 'wpsc-ultfaq' );
      load_textdomain( 'wpsc-ultfaq', WP_LANG_DIR . '/wpsc/wpsc-ultfaq-' . $locale . '.mo' );
      load_plugin_textdomain( 'wpsc-ultfaq', false, plugin_basename( dirname( __FILE__ ) ) . '/lang' );
    }
    
    public function includes() {
      $select_faq_setting = get_option('wpsc_select_faq_set','');
      include_once( WPSC_ULTFAQ_ABSPATH . 'class-wpsc-ultfaq-install.php' );
      include_once( WPSC_ULTFAQ_ABSPATH . 'class-wpsc-ultfaq.php' );
      $ultfaq = new WPSC_ULTFAQ();
			
			// Setting
			add_action( 'wpsc_after_setting_pills', array($ultfaq,'faq_setting_pill'));
			add_action( 'wp_ajax_wpsc_get_faq_settings', array($ultfaq,'get_faq_settings'));
			add_action( 'wp_ajax_wpsc_set_faq_settings', array($ultfaq,'set_faq_settings'));
			
			//ult-mate faq actions
			if($select_faq_setting=='WPSC_Ultimate_FAQ'){
			add_action('wpsc_add_addon_tab_after_macro', array($ultfaq, 'faq_macro'));
			add_action('wp_ajax_wpsc_get_ultfaqs', array($ultfaq, 'get_ultfaqs'));
			add_action('wp_ajax_wpsc_ultfaq_insert_link', array($ultfaq, 'insert_link'));
			add_action('wp_ajax_wpsc_ultfaq_insert_text', array($ultfaq, 'insert_text'));
			
			// replace tag for faq suggestions
			add_filter('wpsc_replace_macro', array($ultfaq, 'replace_macro'), 10, 3);
			//Acronix FAQ
			} elseif ($select_faq_setting=='WPSC_Acronix_FAQ') {
			
			
			add_action('wpsc_add_addon_tab_after_macro', array($ultfaq, 'acronix_faq_macro'));
			add_action('wp_ajax_wpsc_get_acorfaqs', array($ultfaq, 'get_acorfaqs'));
			add_action('wp_ajax_wpsc_acorfaq_insert_link', array($ultfaq, 'acronix_insert_link'));
			add_action('wp_ajax_wpsc_acorfaq_insert_text', array($ultfaq, 'acronix_insert_text'));
			
			// replace tag for faq suggestions
			add_filter('wpsc_replace_macro', array($ultfaq, 'acronix_replace_macro'), 10, 3);
		  }
			// License
			add_filter( 'wpsc_is_add_on_installed', array($ultfaq,'is_add_on_installed'));
			add_action( 'wpsc_addon_license_area', array($ultfaq,'addon_license_area'));
			add_action( 'wp_ajax_wpsc_ultfaq_activate_license', array($ultfaq,'license_activate'));
			add_action( 'wp_ajax_wpsc_ultfaq_deactivate_license', array($ultfaq,'license_deactivate'));
			add_action( 'admin_init', array($this, 'plugin_updator'));
			
    }
    
    private function define($name, $value) {
      if (!defined($name)) {
        define($name, $value);
      }
    }
		
		function plugin_updator(){
			$license_key    = get_option('wpsc_ultfaq_license_key','');
			$license_expiry = get_option('wpsc_ultfaq_license_expiry','');
			if ( class_exists('Support_Candy') && $license_key && $license_expiry ) {
				$edd_updater = new EDD_SL_Plugin_Updater( WPSC_STORE_URL, __FILE__, array(
								'version' => WPSC_ULTFAQ_VERSION,
								'license' => $license_key,
								'item_id' => WPSC_ULTFAQ_STORE_ID,
								'author'  => 'Pradeep Makone',
								'url'     => site_url()
				) );
			}	
    }
    
  }
  
endif;

new Support_Candy_ULT_FAQ();
