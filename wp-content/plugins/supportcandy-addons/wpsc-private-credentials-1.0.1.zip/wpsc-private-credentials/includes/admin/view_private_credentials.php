<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
global $wpscfunction,$wpdb,$current_user;

$ticket_id                = isset($_POST['ticket_id']) ? sanitize_text_field($_POST['ticket_id']) : '' ;
$wpsc_private_credentials = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}wpsc_ticketmeta WHERE ticket_id = '$ticket_id' AND meta_key = 'private_credentials'");
$data                     = array();
$cipher                   = 'AES-128-CBC';
$ekey  	  = base64_decode($wpscfunction->get_ticket_meta($ticket_id,'secure_key',true));
$iv_name  = base64_decode($wpscfunction->get_ticket_meta($ticket_id,'secure_iv',true));
ob_start();

$role_data = get_option('wpsc_pc_role_permissions');
$modify_flag = false;
$delete_flag = false;

if (!($current_user->has_cap('wpsc_agent'))) {
	$modify_flag = true;
	$delete_flag = true;
} else{
	
	$role_id          = get_user_option('wpsc_agent_role');
	$current_agent_id = $wpscfunction->get_current_user_agent_id();
	$assigned_agents  = $wpscfunction->get_ticket_meta($ticket_id,'assigned_agent');
	
	if ( (in_array($current_agent_id,$assigned_agents) && $role_data[$role_id]["role_matching_criteria"] == "2") || ($role_data[$role_id]["role_matching_criteria"] == "1") ) {
		if (array_key_exists("role_modify", $role_data[$role_id])) {
			$modify_flag = true;
		}
		if (array_key_exists("role_delete", $role_data[$role_id])) {
			$delete_flag = true;
		}
	}
} 

if (!$wpsc_private_credentials) {
	_e("No Credentials Added !",'wpsc-pc');	
}

foreach ($wpsc_private_credentials as $wpsc_key => $wpsc_pc) {
	$data = json_decode($wpsc_pc->meta_value);
	?>
	<table class="table table-condensed wpsc_pc_list">
		<tr>
			<td colspan="2"> <label style="font-size:15px"><?php _e($data->title,'wpsc-pc');?></label></td>
		</tr>
		<?php
		foreach ($data->data as $e_key => $e_data) {
			$username       = base64_decode($e_data->name);
			
			$decrypted_name = openssl_decrypt($username,$cipher,$ekey,$options=0,$iv_name);
			?>
			<tr>
				<td style="width:250px !important;"><?php _e($e_data->label,'wpsc-pc');?></td>
				<td><?php  echo  nl2br( stripcslashes( $decrypted_name) );?></td>
			</tr>
			<?php
		} 
		if( $modify_flag || $delete_flag ){
			?>
			<tr>
				<td colspan="2">
					<?php
					if ($modify_flag) {?>
						<a class="btn btn-default btn-xs" href="javascript:wpsc_edit_private_credentials(<?php echo $wpsc_pc->id;?>,<?php echo $ticket_id?>)">Edit</a><?php 
					}
					if ($delete_flag) {?>
						<a class="btn btn-default btn-xs" href="javascript:wpsc_delete_private_credentials(<?php echo $wpsc_pc->id; ?>,<?php echo $ticket_id?>)">Delete</a><?php 
					} 
					?>
				</td>
			</tr>
			<?php
		}
		?>
	</table>
	<?php if (next($wpsc_private_credentials)): ?>
		<hr class="widget_divider">
	<?php endif; ?>
	<?php	
 } 

do_action('wpsc_view_private_credentials');
?>
	
<script>
	function wpsc_add_private_credentials(ticket_id){
		wpsc_modal_open(wpsc_admin.add_pc);
		var data = {
			action: 'wpsc_add_private_credentials',
			ticket_id: ticket_id
		};
		jQuery.post(wpsc_admin.ajax_url, data, function(response_str) {
			 var response = JSON.parse(response_str);
			 jQuery('#wpsc_popup_body').html(response.body);
			 jQuery('#wpsc_popup_footer').html(response.footer);
		});
	}

	function wpsc_delete_private_credentials(key,ticket_id){
			
		var flag = confirm(wpsc_admin.are_you_sure);
		if (flag) {
			var data = {
				action:'wpsc_delete_private_credentials',
				key:key,
				ticket_id:ticket_id
			};
				
			jQuery.post(wpsc_admin.ajax_url, data, function(response_str) {
					
				var response = JSON.parse(response_str);
				if (response.sucess_status=='1') {
					wpsc_view_private_credentials(ticket_id);
				}
			});
		}
	}
	
	function wpsc_edit_private_credentials(key,ticket_id){
			
		var data = {
			action:'wpsc_edit_private_credentials',
			key:key,
			ticket_id:ticket_id,
		};
		
		jQuery.post(wpsc_admin.ajax_url, data, function(response_str) {
			var response = JSON.parse(response_str);
			jQuery('#wpsc_popup_body').html(response.body);
			jQuery('#wpsc_popup_footer').html(response.footer);
		});
	}

</script>

<style>
	.bootstrap-iso .wpsc_pc_list > tbody > tr > td,.wpsc_pc_list{
		border: none !important;
	}
</style>

<?php	
$body = ob_get_clean();
ob_start();
?>
<button type="button" class="btn wpsc_popup_close" onclick="wpsc_modal_close();"><?php _e('Close','wpsc-pc');?></button>
<?php  if ($modify_flag) {?>
	<button type="button" class="btn wpsc_popup_action"  onclick="javascript:wpsc_add_private_credentials(<?php echo $ticket_id;?>)"><?php _e('Add New','wpsc-pc');?></button>
<?php } ?>
<?php
$footer = ob_get_clean();
$response = array(
    'body'  => $body,
		'footer' => $footer
);
echo json_encode($response);