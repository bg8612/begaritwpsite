<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $wpscfunction,$current_user,$wpdb;

$keyval     = isset($_POST['keyval']) ? sanitize_text_field($_POST['keyval']) : '' ;
$wpsc_title = isset($_POST['wpsc_title']) ? sanitize_text_field($_POST['wpsc_title']) : '' ;
$ticket_id  = isset($_POST['ticket_id']) ? sanitize_text_field($_POST['ticket_id']) : '' ;

$key_size   = 32; // 256 bits
$cipher     = 'AES-128-CBC';
$ekey  	  	= base64_decode($wpscfunction->get_ticket_meta($ticket_id,'secure_key',true));
$iv_name  	= base64_decode($wpscfunction->get_ticket_meta($ticket_id,'secure_iv',true));

$data    = array();
foreach($_POST as $key => $value){
	if (strstr($key, 'row_')){
		$data[] = array(
		'label'	=> $value[0],
		'type' => $value[2],
		'value' => $value[1]);
	}
}

$encript_data = array();

foreach ($data as $key => $value) {
	$enc_name = openssl_encrypt(stripcslashes($value['value']), $cipher, $ekey,$options=0,$iv_name);
	
	$edata = array(
		'label' => $value['label'],
		'name'  => base64_encode($enc_name),
    	'type'  => $value['type']
  	);
	$encript_data[stripcslashes($key)]=$edata;
}

$wpsc_private_credentials =array(
	'title' => $wpsc_title,
	'data' => $encript_data
);

$meta_value = array('meta_value'=> json_encode($wpsc_private_credentials));

$wpdb->update($wpdb->prefix.'wpsc_ticketmeta', $meta_value, array('ticket_id'=>$ticket_id,'meta_key' => 'private_credentials','id' => $keyval));

$pc = 'private credential';
$log_str  = sprintf( __('%1$s updated %2$s','wpsc-pc'), '<strong>'.$current_user->display_name.'</strong>', '<strong>'.$pc.'</strong>' );
$args = array(
	'ticket_id'      => $ticket_id,
	'reply_body'     => $log_str,
	'thread_type'    => 'log'
);
$wpscfunction->submit_ticket_thread($args);
do_action('wpsc_set_edit_private_credentials',$ticket_id);
echo '{ "sucess_status":"1","messege":"'.__('Credentials saved.','wpsc-pc').'" }';