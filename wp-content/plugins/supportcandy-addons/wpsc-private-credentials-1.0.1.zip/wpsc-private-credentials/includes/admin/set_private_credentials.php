<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
global $wpscfunction,$current_user;

$ticket_id  = isset($_POST['ticket_id']) ? sanitize_text_field($_POST['ticket_id']) : '' ;
$wpsc_title = isset($_POST['wpsc_title']) ? sanitize_text_field($_POST['wpsc_title']) : '' ;
$data       = array();

foreach($_POST as $key => $value){
	if (strstr($key, 'row_')){
		$data[] = array(
		'label' => $value[0],
		'type' 	=> $value[2],
		'value' => $value[1]);
	}
}
$cipher       = 'AES-128-CBC';

$ekey  	  = base64_decode($wpscfunction->get_ticket_meta($ticket_id,'secure_key',true));
$iv_name  = base64_decode($wpscfunction->get_ticket_meta($ticket_id,'secure_iv',true));

if( !$ekey && !$iv_name){
	$ekey_size    = 32; // 256 bits
	$ekey     = openssl_random_pseudo_bytes($ekey_size, $strong);
	$ivlen    = openssl_cipher_iv_length($cipher);
	$iv_name  = openssl_random_pseudo_bytes($ivlen);
	$wpscfunction->add_ticket_meta($ticket_id,'secure_key', base64_encode($ekey));
	$wpscfunction->add_ticket_meta($ticket_id,'secure_iv', base64_encode($iv_name));
}

$encript_data = array();

foreach ($data as $key => $value) {
  	$enc_name = openssl_encrypt(stripcslashes($value['value']), $cipher, $ekey,$options=0,$iv_name);

	$edata = array(
		'label'        => $value['label'],
		'name'         => base64_encode($enc_name),
    	'type'         => $value['type'],
  	);
	$encript_data[] = $edata;
}

$wpsc_private_credentials = array(
	'title' => $wpsc_title,
	'data'  => $encript_data
);
$wpscfunction->add_ticket_meta($ticket_id,'private_credentials',json_encode($wpsc_private_credentials));

$pc      = 'private credential';
$log_str = sprintf( __('%1$s added %2$s','wpsc-pc'), '<strong>'.$current_user->display_name.'</strong>', '<strong>'.$pc.'</strong>' );
$args    = array(
	'ticket_id'      => $ticket_id,
	'reply_body'     => $log_str,
	'thread_type'    => 'log'
);
$wpscfunction->submit_ticket_thread($args);

do_action('wpsc_set_private_credentials',$ticket_id);

echo '{ "sucess_status":"1","messege":"'.__('Credentials Added Successfully.','wpsc-pc').'" }';