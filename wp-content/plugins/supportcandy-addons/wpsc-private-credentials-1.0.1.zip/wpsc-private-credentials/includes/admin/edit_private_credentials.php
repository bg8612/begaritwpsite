<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
global  $wpscfunction,$wpdb;

$keyval                   = isset($_POST['key']) ? sanitize_text_field($_POST['key']) : '' ;
$ticket_id                = isset($_POST['ticket_id']) ? sanitize_text_field($_POST['ticket_id']) : '' ;
$cipher                   = 'AES-128-CBC';
$wpsc_pc                  = $wpdb->get_row("SELECT * FROM {$wpdb->prefix}wpsc_ticketmeta WHERE ticket_id = $ticket_id AND id = $keyval");
$wpsc_private_credentials = json_decode($wpsc_pc->meta_value);

$ekey  	  = base64_decode($wpscfunction->get_ticket_meta($ticket_id,'secure_key',true));
$iv_name  = base64_decode($wpscfunction->get_ticket_meta($ticket_id,'secure_iv',true));

$decrypted_data           = array();
ob_start();
?>
<form id="edit_private_credentials" method="post" action =" javascript:wpsc_set_edit_private_credentials(<?php echo $keyval?>,<?php echo $ticket_id;?>); ">
	
	<table id="wpsc_pc_tbl_user_edit" class="table table-striped table-hover">
		<thead>
			<tr>
				<td>
					<label for="wpsc_pc_title"><?php _e('Title','wpsc-pc') ?></label>
				</td>
				<td>
					<input name="wpsc_title" class="form-control wpsc_title" type="text" value="<?php echo $wpsc_private_credentials->title?>" />
				</td>
			</tr>
		</thead>
		<?php 
		foreach ($wpsc_private_credentials->data as $encrypt_key => $encrypt_value) {
			$username = base64_decode($encrypt_value->name);
			$type     = $encrypt_value->type;
			$label	  = $encrypt_value->label;
			$decrypted_data[$label] = array('type' => $type, 'value'=> openssl_decrypt($username,$cipher,$ekey,$options = 0,$iv_name));
		}
		?>
		<tbody>
			<?php
			$count = 1 ; 
			foreach ($decrypted_data as $d_key => $d_value) {
				?>
				
				<tr data-field ="row_<?php echo $count ?>">
					<td style='width:250px'><input name="row_<?php echo $count ?>[]" type='text' class="form-control field_label" placeholder='Field label' value='<?php echo $d_key; ?>'></td>
				
					<?php if ($d_value['type'] == '1') { ?>
					
						<td><input type="text" class="form-control field_label" name="row_<?php echo $count ?>[]" placeholder='Field value' value="<?php echo $d_value['value'];?>"/></td>
						<td><input name="row_<?php echo $count ?>[]" type='hidden' value='1'/></td>
				
					<?php } else { ?>
						
						<td><textarea style='height:60px !important;' placeholder='Field value' class='form-control textarea_field' name="row_<?php echo $count ?>[]" ><?php echo $d_value['value'];?></textarea></td>
						<td><input name="row_<?php echo $count ?>[]" type='hidden' value='2'/></td>
					<?php } ?>
					
					<td><div class='wpsc_flex' style='cursor:pointer;margin-top:8px;' onclick='wpsc_remove_field(this);'><i class='fa fa-times-circle' style='color:#d61111;font-size:15px;'></i></div></td>
				</tr>
				<?php 
				$count = $count+1;
			} ?>
			
		</tbody>
			
		<tfoot>
			<tr>
				<td colspan="2">				
					<button type="button" id ="btn_add_new" class="btn" onclick="javascript:wpsc_add_dropdown()"><?php _e('New Field','wpsc-pc'); ?></button>

					<select id="add_field" style="display:none; width:150px !important; height:33px;">
						<option value=" "></option>
						<option name="add_text_field" value="1" id="add_text_field"><?php _e('Text Field','wpsc-pc'); ?></option>
						<option name="add_text_area" value="2" id="add_text_area"><?php _e('Textarea','wpsc-pc'); ?></option>
					</select>
		
					<button type="button"  id="btn_add" class="btn" style="display:none;" onclick="wpsc_add_selected_field();"><?php _e('Add Field','wpsc-pc'); ?></button>
				</td>
			</tr>
		</tfoot>
		
	</table>
	<img class="wpsc_submit_wait" style="display:none;" src="<?php echo WPSC_PLUGIN_URL.'asset/images/ajax-loader@2x.gif';?>">
	<input type="hidden" name="action" value="wpsc_set_edit_private_credentials" />

</form>
<?php do_action('wpsc_edit_private_credentials'); ?>
<script>

var count = 1;

<?php if ($count) { ?>
var count = <?php echo $count  ?>;
<?php } ?>

function wpsc_add_dropdown(){
	jQuery('#add_field').show();
	jQuery('#btn_add').show();
	jQuery('#btn_add_new').hide();
}

function wpsc_add_selected_field(){
	var select_field=jQuery('#add_field').val();
	if (select_field == 1) {
		if(jQuery("#wpsc_pc_tbl_user_edit tbody tr").length > 0){
			jQuery("table tbody tr").last().after("<tr data-field='row_"+count+"'><td style='width:250px;'><input name='row_"+count+"[]' type='text' class='form-control field_label' placeholder='Field label'></td><td><input name='row_"+count+"[]' class='form-control field_label' placeholder='Field value' type='text' value=''/></td><td><input name='row_"+count+"[]' type='hidden' value='1'/></td><td><div style='cursor:pointer;margin-top:8px;' onclick='wpsc_remove_field(this);'><i class='fa fa-times-circle' style='color:#d61111;font-size:15px;'></i></div></td></tr>");
		} else {
			jQuery('#wpsc_pc_tbl_user_edit tbody').append("<tr data-field='row_"+count+"'><td style='width:250px'><input name='row_"+count+"[]' type='text' class='form-control field_label' placeholder='Field label'></td><td><input name='row_"+count+"[]' class='form-control field_label' type='text' style='' placeholder='Field value' value=''/></td><td><input name='row_"+count+"[]' type='hidden' style='' value='1'/></td><td><div style='cursor:pointer;margin-top:8px;' onclick='wpsc_remove_field(this);'><i class='fa fa-times-circle' style='color:#d61111;font-size:15px;'></i></div></td></tr>");
		}
		
	} else if (select_field == 2) {
		if(jQuery("#wpsc_pc_tbl_user_edit tbody tr").length > 0){
			jQuery("table tbody tr").last().after("<tr data-field='row_"+count+"'><td style='250px;'><input name='row_"+count+"[]' type='text' class='form-control field_label' placeholder='Field label'></td><td><textarea style='height:60px !important;' class='form-control textarea_field' placeholder='Field value' name='row_"+count+"[]'></textarea></td><td><input name='row_"+count+"[]' type='hidden' value='2'/></td><td><div style='cursor:pointer;margin-top:8px;' onclick='wpsc_remove_field(this);'><i class='fa fa-times-circle' style='color:#d61111;font-size:15px;'></i></div></td></tr>");
		} else {
			jQuery('#wpsc_pc_tbl_user_edit tbody').append("<tr data-field='row_"+count+"'><td style='width:250px'><input name='row_"+count+"[]' type='text' class='form-control field_label' placeholder='Field label'></td><td><textarea style='height:60px !important;' class='form-control textarea_field' placeholder='Field value' name='row_"+count+"[]'></textarea></td><td><input name='row_"+count+"[]' type='hidden' value='2'/></td><td><div style='cursor:pointer;margin-top:8px;' onclick='wpsc_remove_field(this);'><i class='fa fa-times-circle' style='color:#d61111;font-size:15px;'></i></div></td></tr>");
		}
	}
	
	jQuery('#add_field').val('');
	jQuery('#add_field').hide();
	jQuery('#btn_add').hide();
	jQuery('#btn_add_new').show();
	count++;
}
	
function wpsc_remove_field(e){
	jQuery(e).closest("tr").remove();
}

</script>
<style>
.bootstrap-iso #wpsc_pc_tbl_user_edit > tbody > tr > td,.bootstrap-iso #wpsc_pc_tbl_user_edit > tfoot > tr > td, #wpsc_pc_tbl_user_edit{
	border: none !important;
}
</style>
<?php
$body = ob_get_clean();
ob_start();
?>

<button type="button" class="btn wpsc_popup_close" onclick="wpsc_modal_close();"><?php _e('Close','wpsc-pc');?></button>
<button type="button" class="btn wpsc_popup_action" onclick="javascript:wpsc_set_edit_private_credentials(<?php echo $keyval?>,<?php echo $ticket_id;?>)"><?php _e('Save','wpsc-pc');?></button>

<script>
function wpsc_set_edit_private_credentials(keyval,ticket_id) {
	
	validation = false;
	jQuery('.wpsc_title').each(function(e){
	
		var title = jQuery(this).val().trim();
		if(title.length > 0) {
			validation = true;
		}
		if (!validation) return;
	});
	
	jQuery('input[type="text"].field_label').each(function () {
		var field_label = jQuery(this).val();
		if(field_label == '') {
			validation = false;
		}
	});
	
	jQuery('.textarea_field').each(function () {
		var textarea_val = jQuery.trim(jQuery(this).val());
		if(textarea_val == '') {
			validation = false;
		}
	});
		
	if (!validation) {
		alert("<?php _e('Please enter the required fields!','wpsc-pc')?>");
		return false;
	}
		
	jQuery('.wpsc_submit_wait').show();
	
	var dataform = new FormData(jQuery('#edit_private_credentials')[0]);
	dataform.append('keyval', keyval);
	dataform.append('ticket_id', ticket_id);

	jQuery.ajax({
		url: wpsc_admin.ajax_url,
		type: 'POST',
		data: dataform,
		processData: false,
		contentType: false
	})
	
	.done(function (response_str) {
		
		wpsc_modal_close();
		var response = JSON.parse(response_str);
		jQuery('.wpsc_submit_wait').hide();
		
		if (response.sucess_status=='1') {
			wpsc_view_private_credentials(ticket_id);
		}
	});
}
</script>

<?php 
$footer = ob_get_clean();
$output = array(
  'body'   => $body,
  'footer' => $footer
);
echo json_encode($output);