<?php 
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $current_user, $wpscfunction;

$ticket_status    = $wpscfunction->get_ticket_status($ticket_id);

$role_data        = get_option('wpsc_pc_role_permissions');

$general_appearance = get_option('wpsc_appearance_general_settings');

$action_default_btn_css = 'background-color:'.$general_appearance['wpsc_default_btn_action_bar_bg_color'].' !important;color:'.$general_appearance['wpsc_default_btn_action_bar_text_color'].' !important;';

$flag = false;

if (!($current_user->has_cap('wpsc_agent'))) {
	$flag = true;
}else{
	$role_id          = get_user_option('wpsc_agent_role');
	$current_agent_id = $wpscfunction->get_current_user_agent_id();
	$assigned_agents  = $wpscfunction->get_ticket_meta($ticket_id,'assigned_agent');
	
	if ( in_array($current_agent_id,$assigned_agents) && $role_data[$role_id]["role_matching_criteria"] == "2" && array_key_exists("role_view", $role_data[$role_id])) {
		$flag = true;
	} else if( $role_data[$role_id]["role_matching_criteria"] == "1"  && array_key_exists("role_view", $role_data[$role_id])){
		$flag = true;
	}
} 
?>

<?php if ( $ticket_status && $flag):?>
	<button type="button" id="wpsc_individual_credntial_btn" onclick="wpsc_view_private_credentials(<?php echo $ticket_id ?>)" class="btn btn-sm wpsc_action_btn" style="<?php echo $action_default_btn_css?>"><i class="fas fa-user-lock"></i>  <?php _e('Credentials','wpsc-pc')?></button>

	<script>
	function wpsc_view_private_credentials(ticket_id){
	  wpsc_modal_open(wpsc_admin.pc);
	  var data = {
	    action: 'wpsc_view_private_credentials',
			ticket_id:ticket_id,
	  };

	  jQuery.post(wpsc_admin.ajax_url, data, function(response_str) {
	    var response = JSON.parse(response_str); 
	    jQuery('#wpsc_popup_body').html(response.body);
	    jQuery('#wpsc_popup_footer').html(response.footer);
	  });
	}
</script>

<?php endif;?>