<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

final class WPSC_PC_Backend{
	
	function wpsc_after_indidual_ticket_action_btn($ticket_id){
		include( WPSC_PC_PLUGIN_DIR.'includes/admin/print_private_credentials.php' );
	}
	
	function wpsc_view_private_credentials(){
		include( WPSC_PC_PLUGIN_DIR.'includes/admin/view_private_credentials.php');
		die();
	}
	
	function wpsc_add_private_credentials(){
		include( WPSC_PC_PLUGIN_DIR.'includes/admin/add_private_credentials.php');
		die();
	}
	
	function wpsc_set_private_credentials(){
		include( WPSC_PC_PLUGIN_DIR.'includes/admin/set_private_credentials.php');
		die();	
	}
	
	function wpsc_delete_private_credentials(){
		include( WPSC_PC_PLUGIN_DIR.'includes/admin/delete_private_credentials.php');
		die();	
	}
	
	function wpsc_edit_private_credentials(){
		include( WPSC_PC_PLUGIN_DIR.'includes/admin/edit_private_credentials.php');
		die();
	}
	
	function wpsc_set_edit_private_credentials(){
		include( WPSC_PC_PLUGIN_DIR.'includes/admin/set_edit_private_credentials.php');
		 die();
	}
	
	// Add-on installed or not for licensing
  function is_add_on_installed($flag) {
    return true;
  }
  // Print license functionlity for this add-on
  function addon_license_area(){
    include WPSC_PC_PLUGIN_DIR . 'includes/admin/addon_license_area.php';
  } 
  // Activate Canned Reply license
  function license_activate(){
    include WPSC_PC_PLUGIN_DIR . 'includes/admin/license_activate.php';
		die();
  }
  // Deactivate Canned Reply license
  function license_deactivate(){
    include WPSC_PC_PLUGIN_DIR . 'includes/admin/license_deactivate.php';
		die();
  }
	
	function wpsc_pc_setting_pill(){
		include WPSC_PC_PLUGIN_DIR . 'includes/pc_setting_pill.php';
	}
	
	function get_pc_settings(){
		include WPSC_PC_PLUGIN_DIR . 'includes/get_pc_settings.php';
		die();
	}
	
	function set_pc_settings(){
		include WPSC_PC_PLUGIN_DIR . 'includes/set_pc_settings.php';
		die();
	}
	
	function wpsc_admin_localize_script($data){
		$data['pc']     = __('Private credentials','wpsc-pc');
		$data['add_pc'] = __('Add private credential','wpsc-pc');
		return $data;
	}
	
	function wpsc_set_change_status($ticket_id,$status_id,$prev_status){
		global $wpdb;
		$wpsc_close_ticket_status = get_option('wpsc_close_ticket_status');
		if ($wpsc_close_ticket_status == $status_id) {
			$wpdb->delete($wpdb->prefix.'wpsc_ticketmeta', array('meta_key'=> 'private_credentials','ticket_id'=> $ticket_id));
		}
	}
}
?>