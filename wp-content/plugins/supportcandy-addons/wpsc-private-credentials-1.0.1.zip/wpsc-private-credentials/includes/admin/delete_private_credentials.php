<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
global $wpscfunction,$current_user,$wpdb;

$ticket_id = isset($_POST['ticket_id']) ? sanitize_text_field($_POST['ticket_id']) : '' ;
if(!$ticket_id) die();

$key_val = isset($_POST['key']) ? sanitize_text_field($_POST['key']) : '' ;
$wpdb->delete($wpdb->prefix.'wpsc_ticketmeta', array('id'=> $key_val,'ticket_id'=> $ticket_id));

$pc = 'private credential';
$log_str  = sprintf( __('%1$s deleted %2$s','wpsc-pc'), '<strong>'.$current_user->display_name.'</strong>', '<strong>'.$pc.'</strong>' );
$args = array(
	'ticket_id'      => $ticket_id,
	'reply_body'     => $log_str,
	'thread_type'    => 'log'
);
$wpscfunction->submit_ticket_thread($args);

do_action('wpsc_after_delete_private_credentials',$ticket_id);

echo '{ "sucess_status":"1","messege":"'.__('Credentials deleted successfully','wpsc-pc').'" }';