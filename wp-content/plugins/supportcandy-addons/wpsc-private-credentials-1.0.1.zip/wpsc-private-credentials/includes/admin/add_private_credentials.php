<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $wpscfunction;

$ticket_id = isset($_POST['ticket_id']) ? sanitize_text_field($_POST['ticket_id']) : '' ;
ob_start();
?>

<form id="add_private_credentials" method="post" action="javascript:wpsc_set_private_credentials(<?php echo $ticket_id;?>);">
	<table id="tbl_user" class="table table-striped table-hover">
		<thead>
			<tr>
				<td>
					<label for="wpsc_pc_title"><?php _e('Title','wpsc-pc') ?></label>
				</td>
				<td>
					<input name="wpsc_title" class="form-control wpsc_title" type="text"  value=""/>
				</td>
			</tr>
		</thead>
		<tbody>
		</tbody>
		<tfoot>
			<tr>
				<td colspan="2">				
					<button type="button" id ="btn_add_new" class="btn" onclick="javascript:wpsc_add_dropdown()"><?php _e('New Field','wpsc-pc'); ?></button>

					<select id="add_field" style="display:none; width:150px !important; height:33px;">
						<option value=" "></option>
						<option name="add_text_field" value="1" id="add_text_field"><?php _e('Text Field','wpsc-pc'); ?></option>
						<option name="add_text_area" value="2" id="add_text_area"><?php _e('Textarea','wpsc-pc'); ?></option>
					</select>
		
					<button type="button"  id="btn_add" class="btn" style="display:none;" onclick="wpsc_add_selected_field();"><?php _e('Add','wpsc-pc'); ?></button>
				</td>
			</tr>
		</tfoot>
	</table>
	<img class="wpsc_submit_wait" style="display:none;" src="<?php echo WPSC_PLUGIN_URL.'asset/images/ajax-loader@2x.gif';?>">
	<input type="hidden" name="action" value="wpsc_set_private_credentials" />
	
</form>
<?php do_action('wpsc_add_private_credentials'); ?>
<script>
	function wpsc_add_dropdown(){
		jQuery('#add_field').show();
		jQuery('#btn_add').show();
		jQuery('#btn_add_new').hide();
	}
	
	var count = 1;
	
	function wpsc_add_selected_field(){
		var select_field=jQuery('#add_field').val();
		if (select_field == 1) {
			jQuery('#tbl_user tbody').append("<tr data-field='row_"+count+"'><td style='width:250px'><input name='row_"+count+"[]' type='text' class='form-control field_label' placeholder='Field label'></td><td><input name='row_"+count+"[]' class='form-control field_label' type='text' style='' placeholder='Field value' value=''/></td><td><input name='row_"+count+"[]' type='hidden' style='' value='1'/></td><td><div style='cursor:pointer;margin-top:8px;' onclick='wpsc_remove_field(this);'><i class='fa fa-times-circle' style='color:#d61111;font-size:15px;'></i></div></td></tr>");
		} else if (select_field == 2) {
			jQuery('#tbl_user tbody').append("<tr data-field='row_"+count+"'><td style='width:250px'><input name='row_"+count+"[]' type='text' class='form-control field_label' placeholder='Field label'></td><td><textarea style='height:60px !important;' class='form-control textarea_field' placeholder='Field value' name='row_"+count+"[]'></textarea></td><td><input name='row_"+count+"[]' type='hidden' value='2'/></td><td><div style='cursor:pointer;margin-top:8px;' onclick='wpsc_remove_field(this);'><i class='fa fa-times-circle' style='color:#d61111;font-size:15px;'></i></div></td></tr>");
		}
		jQuery('#add_field').val('');
		jQuery('#add_field').hide();
		jQuery('#btn_add').hide();
		jQuery('#btn_add_new').show();
		count++;
	}
	
	function wpsc_remove_field(e){
		jQuery(e).closest("tr").remove();
	}
</script>

<style>
.bootstrap-iso #add_private_credentials > #tbl_user > tbody > tr > td,.bootstrap-iso #add_private_credentials > #tbl_user > tfoot > tr > td{
	border: none !important;
}
#add_private_credentials table{
	border: none !important;
}
</style>
<?php 
$body = ob_get_clean();
ob_start();
?>
<button type="button" class="btn wpsc_popup_close" onclick="wpsc_modal_close();"><?php _e('Close','wpsc-pc');?></button>
<button type="button" class="btn wpsc_popup_action" onclick="javascript:wpsc_set_private_credentials(<?php echo $ticket_id;?>);"><?php _e('Save','wpsc-pc');?></button>

<script>

	function wpsc_set_private_credentials(ticket_id){
		validation = false;
		var	values = [];
		jQuery('.wpsc_title').each(function(e){
			var title = jQuery(this).val().trim();
			if(title.length > 0) {
				validation = true;
			}
			if (!validation) return;
		});
	
		jQuery('input[type="text"].field_label').each(function () {
			var field_label = jQuery(this).val();
			if(field_label == '') {
				validation = false;
			}
		});
		
		jQuery('.textarea_field').each(function () {
			var textarea_val = jQuery.trim(jQuery(this).val());
			if(textarea_val == '') {
				validation = false;
			}
		});
		
		if (!validation) {
			alert("<?php _e('Please enter the required fields!','wpsc-pc')?>");
			return false;
		}
		jQuery('.wpsc_submit_wait').show();;
		var dataform = new FormData(jQuery('#add_private_credentials')[0]);
		dataform.append('ticket_id', ticket_id);

		jQuery.ajax({
			url: wpsc_admin.ajax_url,
			type: 'POST',
			data: dataform,
			processData: false,
			contentType: false
		})
		.done(function (response_str) {
			wpsc_modal_close();
			var response = JSON.parse(response_str);
			jQuery('.wpsc_submit_wait').hide();
			if (response.sucess_status=='1') {
				wpsc_open_ticket(ticket_id);
			}
		});
	}
</script>
<?php 
$footer = ob_get_clean();
$output = array(
  'body'   => $body,
  'footer' => $footer
);
echo json_encode($output);