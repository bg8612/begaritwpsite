<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $current_user, $wpdb;
if (!($current_user->ID && $current_user->has_cap('manage_options'))) {
	exit;
}

?>

<h4><?php _e('Private Credentials','wpsc-pc');?></h4>

<form id="frm_pc_settings" action="javascript:wpsc_set_pc_settings();" method="post">
	<div class="wpsc_padding_space"></div>
	<table class="table table-striped table-hover table-bordered">
		<thead>
			<tr>
				<th><?php _e('Roles','wpsc-pc')?></th>
		    <th><?php _e('View','wpsc-pc')?></th>
		    <th><?php _e('Modify','wpsc-pc')?></th>
		    <th><?php _e('Delete','wpsc-pc')?></th>
				<th><?php _e('Matching criteria','wpsc-pc')?></th>
			</tr>
		</thead>
		<tbody>
		<?php
			
		$agent_role = get_option('wpsc_agent_role');
		$role_data = get_option('wpsc_pc_role_permissions');
		$role_data = $role_data ? $role_data : array();

		foreach ($agent_role as $agent_key => $agent) {
				 
			$checked_view 	= isset($role_data[$agent_key]["role_view"]) && $role_data[$agent_key]["role_view"] ? 'checked = "checked"' : 0;
			$checked_edit   = isset($role_data[$agent_key]["role_modify"]) && $role_data[$agent_key]["role_modify"] ? 'checked="checked"' : 0;
			$checked_delete = isset($role_data[$agent_key]["role_delete"]) && $role_data[$agent_key]["role_delete"] ? 'checked="checked"' : 0;
			$disabled  = (!isset($role_data[$agent_key]["role_view"])) ? "disabled" : " ";
			?>
			<tr>
				<td><?php echo $agent['label'];?></td>
				<td><input type="checkbox" <?php  echo $checked_view;?>  name="role_data[<?php  echo $agent_key?>][role_view]" value="1" /></td>
				<td><input type="checkbox" <?php echo $checked_edit; ?>  name="role_data[<?php  echo $agent_key?>][role_modify]" value="1" <?php echo $disabled; ?>/></td>
				<td><input type="checkbox" <?php echo $checked_delete; ?>  name="role_data[<?php  echo $agent_key?>][role_delete]" value="1" <?php echo $disabled; ?>/></td>
				<td>
					<select name ="role_data[<?php echo $agent_key?>][role_matching_criteria]" class="form-control" <?php echo $disabled; ?>>
						<option <?php echo 	$selected = isset($role_data[$agent_key]["role_matching_criteria"]) && $role_data[$agent_key]["role_matching_criteria"] == '1' ? 'selected = "selected"' : '';; ?> value="1"><?php _e('All','wpsc-pc'); ?></option>
						<option <?php echo 	$selected = isset($role_data[$agent_key]["role_matching_criteria"]) &&  $role_data[$agent_key]["role_matching_criteria"] == '2' ? 'selected = "selected"' : '';; ?> value="2"><?php _e('Assigned agents only ','wpsc-pc'); ?></option>
					</select>
				</td>
			</tr>
			<script>
				jQuery("input[name='role_data[<?php echo $agent_key;?>][role_view]']").change(function() {
					if(this.checked) {
						jQuery("input[name='role_data[<?php echo $agent_key;?>][role_modify]']").removeAttr("disabled");
						jQuery("input[name='role_data[<?php echo $agent_key;?>][role_delete]']").removeAttr("disabled");
						jQuery("select[name='role_data[<?php echo $agent_key;?>][role_matching_criteria]']").removeAttr("disabled");
					} else {
						jQuery("input[name='role_data[<?php echo $agent_key;?>][role_modify]']").attr("disabled",true);
						jQuery("input[name='role_data[<?php echo $agent_key;?>][role_delete]']").attr("disabled",true);
						jQuery("select[name='role_data[<?php echo $agent_key;?>][role_matching_criteria]']").attr("disabled",true);
					}
					});
			</script>
			<?php 
		}
		?>
		</tbody>
	</table>
  <button type="submit" class="btn btn-success"><?php _e('Save Changes','wpsc-pc');?></button>
  <img class="wpsc_submit_wait" style="display:none;" src="<?php echo WPSC_PLUGIN_URL.'asset/images/ajax-loader@2x.gif';?>">
  <input type="hidden" name="action" value="wpsc_set_pc_settings" />
</form>

<script>
	function wpsc_set_pc_settings(){
		jQuery('.wpsc_submit_wait').show();
		var dataform = new FormData(jQuery('#frm_pc_settings')[0]);
		jQuery.ajax({
			url: wpsc_admin.ajax_url,
			type: 'POST',
			data: dataform,
			processData: false,
			contentType: false
		})
		.done(function (response_str) {
			var response = JSON.parse(response_str);
			jQuery('.wpsc_submit_wait').hide();
			if (response.sucess_status=='1') {
				jQuery('#wpsc_alert_success .wpsc_alert_text').text(response.messege);
			}
			jQuery('#wpsc_alert_success').slideDown('fast',function(){});
			setTimeout(function(){ jQuery('#wpsc_alert_success').slideUp('fast',function(){}); }, 3000);
		});
	}
			
</script>