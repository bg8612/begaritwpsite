<?php
 if ( ! defined( 'ABSPATH' ) ) {
 	exit; // Exit if accessed directly
 }

global $current_user, $wpscfunction;
if (!($current_user->ID && $current_user->has_cap('manage_options'))) {
	exit;
}

$role_data = isset($_POST) && isset($_POST['role_data']) ? $wpscfunction->sanitize_array($_POST['role_data']) : array();
update_option('wpsc_pc_role_permissions',$role_data);
 
echo '{ "sucess_status":"1","messege":"'.__('Settings saved.','wpsc-pc').'" }';