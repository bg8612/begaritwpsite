<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if ( ! class_exists( 'WPSC_PC_Install' ) ) :

  final class WPSC_PC_Install {
    
		public function __construct() {
			$this->check_version();
		}
    
		public function check_version(){
			$installed_version = get_option( 'wpsc_pc_current_version', 0 );
			if( $installed_version != WPSC_PC_VERSION ){						
				add_action( 'init', array($this,'upgrade'), 101 );
			}
		}
		// Upgrade
		public function upgrade(){
			$installed_version = get_option( 'wpsc_pc_current_version', 0 );
			$installed_version = $installed_version ? $installed_version : 0;
			if( $installed_version < '1.0.0' ){
				$agent_role = get_option('wpsc_agent_role');
				foreach ($agent_role as $key => $agent) {
					if($key == 1 ){
						$roledata[$key] = array(
							"role_view"    => '1',
							"role_modify"   => '1',
							"role_delete" => '1',
							"role_matching_criteria"		=> '1'
						);
					} else {
						$roledata[$key] = array(
							"role_view"    => '1',
							"role_modify"   => '0',
							"role_delete" => '0',
							"role_matching_criteria"		=> '2'
						);
					}
				}

				update_option( 'wpsc_pc_role_permissions',$roledata);
			}
			
			update_option( 'wpsc_pc_current_version', WPSC_PC_VERSION );
		}
	}
endif;

new WPSC_PC_Install();