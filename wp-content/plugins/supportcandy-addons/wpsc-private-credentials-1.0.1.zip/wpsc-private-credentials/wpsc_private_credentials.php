<?php
/**
 * Plugin Name: SupportCandy - Private Credentials 
 * Plugin URI: https://supportcandy.net/
 * Description: Private Credientials Add-on for SupportCandy!
 * Version: 1.0.1
 * Author: SupportCandy
 * Author URI: https://supportcandy.net/
 * Text Domain: wpsc-pc
 */
 
if (!defined('ABSPATH')) {
     exit; // Exit if accessed directly
 }

if ( ! class_exists( 'WPSupportCandyPrivateCredentials' ) ) : 
  
final class WPSupportCandyPrivateCredentials {
      
     public $version = '1.0.1';
     
     public function __construct() {
       
       $this->define_constants();
       $this->include_files();
       add_action('init', array($this, 'load_textdomain'));
     }
      
     private function define_constants() {

       define('WPSC_PC_PLUGIN_FILE', __FILE__ );
       define('WPSC_PC_PLUGIN_URL', plugin_dir_url(__FILE__));
       define('WPSC_PC_PLUGIN_DIR', plugin_dir_path(__FILE__));
       define('WPSC_PC_VERSION', $this->version);
       define('WPSC_PC_STORE_ID', '64200' );
     }
   
     function load_textdomain(){
       
       $locale = apply_filters( 'plugin_locale', get_locale(), 'wpsc-pc' );
       load_textdomain( 'wpsc-pc', WP_LANG_DIR . '/wpsc/wpsc-pc-' . $locale . '.mo' );
       load_plugin_textdomain( 'wpsc-pc', false, plugin_basename( dirname( __FILE__ ) ) . '/lang' );
     }

     function include_files(){
       include_once( WPSC_PC_PLUGIN_DIR . 'class-wpsc-pc-install.php' );
       include( WPSC_PC_PLUGIN_DIR.'includes/admin/admin.php' );
       
       $backend    = new WPSC_PC_Backend();
      
       add_action('wpsc_after_indidual_ticket_action_btn',array($backend,'wpsc_after_indidual_ticket_action_btn'),10,1);
       add_action( 'wp_ajax_wpsc_view_private_credentials', array($backend,'wpsc_view_private_credentials'));
       add_action( 'wp_ajax_wpsc_add_private_credentials', array($backend,'wpsc_add_private_credentials'));
       add_action( 'wp_ajax_wpsc_set_private_credentials', array($backend,'wpsc_set_private_credentials'));
       add_action( 'wp_ajax_wpsc_delete_private_credentials', array($backend,'wpsc_delete_private_credentials'));
       add_action('wp_ajax_wpsc_edit_private_credentials',array($backend,'wpsc_edit_private_credentials'));
       add_action('wp_ajax_wpsc_set_edit_private_credentials',array($backend,'wpsc_set_edit_private_credentials'));
       add_action('wpsc_set_change_status',array($backend,'wpsc_set_change_status'),10,3);
       
       // License
       add_filter( 'wpsc_is_add_on_installed', array($backend,'is_add_on_installed'));
       add_action( 'wpsc_addon_license_area', array($backend,'addon_license_area'));
       add_action( 'wp_ajax_wpsc_pc_activate_license', array($backend,'license_activate'));
       add_action( 'wp_ajax_wpsc_pc_deactivate_license', array($backend,'license_deactivate'));
       add_action( 'admin_init', array($this, 'plugin_updator'));
       
       //settings
       add_action( 'wpsc_after_setting_pills', array($backend,'wpsc_pc_setting_pill'));
       add_action( 'wp_ajax_wpsc_get_pc_settings', array($backend,'get_pc_settings'));
       add_action( 'wp_ajax_wpsc_set_pc_settings', array($backend,'set_pc_settings'));
       add_filter('wpsc_admin_localize_script',array($backend,'wpsc_admin_localize_script'));
     }

     function plugin_updator(){
       $license_key = get_option( 'wpsc_pc_license_key' );
       $license_expiry = get_option('wpsc_pc_license_expiry','');
       if (class_exists('Support_Candy') && $license_key && $license_expiry) {
         $edd_updater = new EDD_SL_Plugin_Updater( WPSC_STORE_URL, __FILE__, array(
           'version' => WPSC_PC_VERSION,
           'license' => $license_key,
           'item_id' => WPSC_PC_STORE_ID,
           'author'  => 'Pradeep Makone',
           'url'     => site_url()
          ));
       }
     }
   }
endif;

new WPSupportCandyPrivateCredentials();