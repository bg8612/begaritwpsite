<?php 

if ( ! defined( 'ABSPATH' ) ) {
  exit; // Exit if accessed directly
}

global $current_user, $wpscfunction;

$role_id    = get_user_option('wpsc_agent_role');

$wpsc_appearance_individual_ticket_page = get_option('wpsc_individual_ticket_page');

$wpsc_ticket_widget_type = get_term_meta( $ticket_widget->term_id, 'wpsc_ticket_widget_type', true);
$wpsc_ticket_widget_role = get_term_meta( $ticket_widget->term_id, 'wpsc_ticket_widget_role', true);
  
if($wpsc_ticket_widget_type && (in_array($role_id,$wpsc_ticket_widget_role) || !$current_user->has_cap('wpsc_agent') && in_array('customer',$wpsc_ticket_widget_role))) {
  $wpsc_custom_widget_localize = get_option('wpsc_custom_widget_localize');
  $name = $wpsc_custom_widget_localize['custom_widget_'.$ticket_widget->term_id];
?>

  <div class="row" style="background-color:<?php echo $wpsc_appearance_individual_ticket_page['wpsc_ticket_widgets_bg_color']?> !important;color:<?php echo $wpsc_appearance_individual_ticket_page['wpsc_ticket_widgets_text_color']?> !important;border-color:<?php echo $wpsc_appearance_individual_ticket_page['wpsc_ticket_widgets_border_color']?> !important;">
    <h4 class="widget_header"> <i class="fas fa-shopping-cart"></i>
      <?php echo $name;?>
    </h4>
    <hr class="widget_divider">
    
    <?php 
    
    $customer_email= $wpscfunction->get_ticket_fields($ticket_id,'customer_email');
    $user = get_user_by('email',$customer_email);
    $purchases = array();
    if($user){
      $purchases = edd_get_users_purchases($user->ID , 1000, true, 'any' );
    }
    if($purchases){
      ?>
      
      <div style="overflow-y: auto;max-height: 130px;" id="wpsc_user_edd_orders">
        <?php foreach ( $purchases as $purchase ) : setup_postdata( $purchase ); ?>
          <?php 
          
          $purchase_data = edd_get_payment_meta( $purchase->ID ); 
          $payment   = get_post( edd_get_payment_number( $purchase->ID ) );
          $status    = edd_get_payment_status( $payment, true );
          $date = date_i18n('j M Y', strtotime(get_post_field( 'post_date', $purchase->ID ) ));
                       
          $value = '<a href="javascript:wpsc_edd_get_purchase_details(\''.$customer_email.'\','.$purchase->ID.',\''.wp_create_nonce($purchase->ID).'\')">#'.$purchase->ID .
          ' ' .'('.$date .'-'. $status .')'.
          '</a>'
          ?>
          <div class="wpsp_sidebar_labels"><?php echo $value ?></div>
          <?php
        endforeach;
        ?>
      </div>
      <?php              
    }
    else {
      ?>
      <div class="wpsp_sidebar_labels">
        <?php	_e("No Orders Found",'wpsc-woocommerce');	?>
      </div>
      <?php
    }
    ?>
    </div>
<?php
  }
  ?>