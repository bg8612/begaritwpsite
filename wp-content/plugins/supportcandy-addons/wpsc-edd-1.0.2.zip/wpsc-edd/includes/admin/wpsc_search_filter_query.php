<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
$custom_field = get_term_by('slug', $field->slug, 'wpsc_ticket_custom_fields');
$type = get_term_meta( $custom_field->term_id, 'wpsc_tf_type', true);
if($type == "13"){
  $args = array(
    'orderby'           => 'title',
    'order'             => 'ASC',
    'post_type'         => 'download',
    'post_status'       => 'publish',
    'posts_per_page'    => 100,
    's'                 => $arr['value'],
  );
  
  $products = get_posts( $args );  
  $results = array();
  
  foreach($products as $product){
    $results[] = $product->ID;
  }
  if($results){
    $arr = array(
      'key'     => $field->slug,
      'value'   => $results,
      'compare' => 'IN'
    );
  }
}