<?php 
  global $current_user;
if($custom_field_types->type==13) {
  $args = array(
      'orderby'           => 'title',
      'order'             => 'ASC',
      'post_type'         => 'download',
      'post_status'       => 'publish',
      'posts_per_page'    => 100
  );
  $products = get_posts( $args );

  $class = $custom_field_types->required ? 'wpsc_required' : '';
  $label = get_option('wpsc_custom_fields_localize');
  $extra_info = get_option('wpsc_custom_fields_extra_info'); 
  $wpsc_appearance_create_ticket = get_option('wpsc_create_ticket');
    
  $extra_info_css = 'color:'.$wpsc_appearance_create_ticket['wpsc_extra_info_text_color'].' !important;';
  ?>
  <div  data-fieldtype="dropdown" data-visibility="<?php echo $custom_field_types->visibility_conditions?>" class="<?php echo $custom_field_types->col_class?> <?php echo $custom_field_types->visibility? 'hidden':'visible'?> <?php echo $custom_field_types->required? 'wpsc_required':''?> form-group wpsc_form_field <?php echo 'field_'.$field->term_id?>">
    <label class="wpsc_ct_field_label" for="Product Name"><?php echo $label['custom_fields_'.$field->term_id];?> 
      <?php echo $custom_field_types->required? '<span style="color:red;">*</span>':'';?>
    </label>
    <?php if($extra_info['custom_fields_extra_info_'.$field->term_id]){?><p class="help-block" style="<?php echo $extra_info_css?>"><?php echo $extra_info['custom_fields_extra_info_'.$field->term_id];?></p><?php }?>

    <select id="<?php echo $field->slug; ?>" class="form-control" name="<?php echo $field->slug; ?>">
      <option value=""></option>
      <?php
      foreach( $products as $product ){
        $selected = isset($_REQUEST['edd_product_id']) && $_REQUEST['edd_product_id'] == $product->ID ? 'selected="selected"' : '';
        ?>
        <option <?php echo $selected?> value="<?php echo $product->ID?>"><?php echo $product->post_title?></option>
        <?php
      }
      ?>
    </select>
  </div>
  <?php 
  }
  
  if($current_user->ID && $custom_field_types->type==14){
    $orders = array();
    $purchases = edd_get_users_purchases( $current_user->ID, 1000, true, 'any' );
    if ($purchases){
      foreach ( $purchases as $post ) { 
        setup_postdata( $post );
        $orders[] = edd_get_payment_number( $post->ID );
      }
      wp_reset_postdata();
    }
    $class = $custom_field_types->required ? 'wpsc_required' : '';
    $wpsc_appearance_create_ticket = get_option('wpsc_create_ticket');
    $label = get_option('wpsc_custom_fields_localize');
    $extra_info = get_option('wpsc_custom_fields_extra_info'); 
    $extra_info_css = 'color:'.$wpsc_appearance_create_ticket['wpsc_extra_info_text_color'].' !important;';
    ?>

    <div  data-fieldtype="dropdown" data-visibility="<?php echo $custom_field_types->visibility_conditions?>" class="<?php echo $custom_field_types->col_class?> <?php echo $custom_field_types->visibility? 'hidden':'visible'?> <?php echo $custom_field_types->required? 'wpsc_required':''?> form-group wpsc_form_field <?php echo 'field_'.$field->term_id?>">
      <label class="wpsc_ct_field_label"><?php echo  $label['custom_fields_'.$field->term_id];?> 
        <?php echo $custom_field_types->required? '<span style="color:red;">*</span>':'';?>
      </label>
      <?php if($extra_info['custom_fields_extra_info_'.$field->term_id]){?><p class="help-block" style="<?php echo $extra_info_css?>"><?php echo $extra_info['custom_fields_extra_info_'.$field->term_id];?></p><?php }?>
      <select class="form-control" id="<?php echo $field->slug; ?>" name="<?php echo $field->slug; ?>">
        <option value=""></option>
        <?php
        foreach( $orders as $order ){
          $selected = isset($_REQUEST['edd_order_id']) && $_REQUEST['edd_order_id'] == $order ? 'selected="selected"' : '';
          ?>
          <option <?php echo $selected?> value="<?php echo $order?>">#<?php echo $order?></option>
          <?php
        }
        ?>
      </select>
    </div>
    <?php 
  }
?>