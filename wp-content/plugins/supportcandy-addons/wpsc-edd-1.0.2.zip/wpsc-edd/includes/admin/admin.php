<?php 
final class WPSC_EDD_Backend{

  function get_purchase_details(){
    include( WPSC_EDD_DIR.'includes/admin/get_purchase_details.php' );
    die();
  }
  
  function wpsc_custom_field_types($custom_field_types){
    
    $custom_field_types[13]=array( 
      'label' => __('EDD Product','wpsc-edd'),
      'has_options' => 0,
      'allow_ticket_list' => 1,
      'allow_ticket_filter' => 1,
      'allow_orderby' => 1,
      'ticket_filter_type' => 'string'
    );
    
    $custom_field_types[14]=array( 
      'label' => __('EDD Order','wpsc-edd'),
      'has_options' => 0,
      'allow_ticket_list' => 1,
      'allow_ticket_filter' => 1,
      'allow_orderby' => 1,
      'ticket_filter_type' => 'string'
    );
    return $custom_field_types;
  }
  
  function wpsc_print_custom_form_field($field,$custom_field_types){
    include( WPSC_EDD_DIR.'includes/admin/print_custom_form_field.php' );
  }
  
  function wpsc_after_create_ticket_custom_field($args,$field,$custom_field_types){

    if($custom_field_types ==13 || $custom_field_types ==14){
      $text = isset($_POST[$field->slug]) ? sanitize_text_field($_POST[$field->slug]) : '';
      if($text) $args[$field->slug] = $text; 
    }
    return $args;
  }

  function wpsc_add_ticket_meta_custom_field($ticket_id,$custom_field_types,$args,$field){
    global $wpscfunction;
    if($custom_field_types==13 || $custom_field_types==14){
      $text = isset($args[$field->slug]) ? $args[$field->slug] : '';
      $wpscfunction->add_ticket_meta($ticket_id,$field->slug, $text );
    }
  }
   
  function wpsc_widget_ticket_field_item($field,$ticket_id,$custom_field_types){    
    
    global $wpscfunction;
    
    if($custom_field_types==13){
      $label = get_term_meta( $field->term_id, 'wpsc_tf_label', true);
      $field_value = $wpscfunction->get_ticket_meta($ticket_id,$field->slug, true);
      ?>
      <div class="wpsp_sidebar_labels"><strong><?php _e($label,'wpsc-edd')?>:</strong> 
        <?php echo "<a href='".get_permalink($field_value)."' target='_blank'>".get_the_title($field_value)."</a>"?></div>
      <?php
    }
    
    if($custom_field_types==14){
      $name = get_term_meta( $field->term_id, 'wpsc_tf_label', true);
      $label =   $wpscfunction->get_ticket_meta($ticket_id,$field->slug, true);
      $customer_email=$wpscfunction->get_ticket_fields($ticket_id,'customer_email');
      $value = '<a href="javascript:wpsc_edd_get_purchase_details(\''.$customer_email.'\','.$label.',\''.wp_create_nonce($label).'\')">#'.$label.'</a>';
      ?>
      <div class="wpsp_sidebar_labels"><strong><?php _e($name,'wpsc-edd')?>:</strong> <?php echo $value?></div>
      <?php
    }    
  }
  
  function wpsc_print_edit_custom_form_field($field, $custom_field_types){
    include( WPSC_EDD_DIR.'includes/admin/print_edit_custom_form_fields.php' );
  }
  
    function change_the_field($fields_value,$ticket_id,$wpsc_tf_type,$fields_slug){
      if($wpsc_tf_type == 13){
          $fields_value=get_the_title($fields_value);
        }
      return $fields_value;
    }
    function change_prev_field_value($prev_fields_value,$ticket_id,$wpsc_tf_type,$fields_slug){
  		if($wpsc_tf_type == 13){
  			 $prev_fields_value = get_the_title($prev_fields_value);
  	 	}
  	 	return $prev_fields_value;
  	}
    function wpsc_change_the_name($name, $ticket_id, $fields_slug, $wpsc_tf_type, $term_id_data) {
      if($wpsc_tf_type==13 || $wpsc_tf_type==14){
        $name = get_term_meta( $term_id_data->term_id, 'wpsc_tf_label', true);
      }
      return $name;
    }
    
    function wpsc_after_individual_ticket($ticket_id){
    ?>
    <script>
    function wpsc_edd_get_purchase_details(customer_email,payment_id,nonce){
      wpsc_modal_open('Order Details');
      var data = {
        action: 'wpsc_edd_get_purchase_details',
        customer_email:customer_email,
        payment_id:payment_id,
        nonce:nonce,
      };
      jQuery.post(wpsc_admin.ajax_url, data, function(response_str) {
        var response = JSON.parse(response_str);
        jQuery('#wpsc_popup_body').html(response.body);
        jQuery('#wpsc_popup_footer').html(response.footer);
      });
    }      
  </script>
  <?php
  }
  
  function wpsc_set_change_ticket_field($fields_data, $field,$ticket_id,$wpsc_tf_type){
    
    global $wpscfunction;
    
		if($wpsc_tf_type == 13 || $wpsc_tf_type == 14 ){
     	$agentonly    = get_term_meta( $field->term_id, 'agentonly', true);
      $oldVal = $wpscfunction->get_ticket_meta( $ticket_id, $field->slug, true);
      $newVal = isset($fields_data->{$field->slug}) ? sanitize_text_field($fields_data->{$field->slug}) : '';
      if ( isset($fields_data->{$field->slug}) && (($agentonly == 0 && $wpscfunction->has_permission('change_ticket_fields',$ticket_id)) || ($agentonly == 1 && $wpscfunction->has_permission('change_agentonly_fields',$ticket_id)) ) && $oldVal != $newVal ) {
         $wpscfunction->change_field($ticket_id,$field->slug,$fields_data->{$field->slug});
      }
    }
  }
  
  function wpsc_print_custom_tl_field($ticket_list){
    global $current_user, $wpscfunction,$label;
    if($ticket_list->type=='13'){
    
    	$label = $wpscfunction->get_ticket_meta($ticket_list->ticket['id'], $ticket_list->list_item->slug,true);
    	$label = $label ? get_the_title($label):'';
    }
    if($ticket_list->type=='14'){
      $label = $wpscfunction->get_ticket_meta($ticket_list->ticket['id'], $ticket_list->list_item->slug,true);
    }

    echo $label;
  }
  
  function wpsc_add_ticket_widget($ticket_id, $ticket_widget, $ticket_widgets){
    if($ticket_widget->slug== 'edd-order'){
      include( WPSC_EDD_DIR.'includes/admin/print_edd_order.php' );
    }
  }
  
  function filter_autocomplete( $output,$term,$field_slug ){
    include(WPSC_EDD_DIR. 'includes/admin/filter_autocomplete.php');
    return $output;
  }
  
  function replace_macro($str,$ticket_id,$tf_type,$field){
    
    global $wpscfunction;
    
    if($tf_type==13){
      
      $text =$wpscfunction->get_ticket_meta($ticket_id, $field->slug, true);
      $text = $text ? get_the_title($text) : '';
      $str  = preg_replace('/{'.$field->slug.'}/', $text, $str);

    }
    if( $tf_type==14){
      
      $text =$wpscfunction->get_ticket_meta($ticket_id, $field->slug, true);
      $text = $text ? $text : '';
      $str  = preg_replace('/{'.$field->slug.'}/', $text, $str);
      
    }
    return $str;
  }
  
  function wpsc_filter_val_label($val, $field_slug){
		$custom_field = get_term_by('slug', $field_slug, 'wpsc_ticket_custom_fields');
		$type = get_term_meta( $custom_field->term_id, 'wpsc_tf_type', true);
		$term = $val;
		if($type == "13"){
			$term = $val ? get_the_title($val):'';
		}
		return $term;
	}
  
  function wpsc_search_filter_query($arr,$field){
    include WPSC_EDD_DIR . 'includes/admin/wpsc_search_filter_query.php';
    return $arr;
  }
  
  // Add-on installed or not for licensing
  function is_add_on_installed($flag) {
    return true;
  }
  // Print license functionlity for this add-on
  function addon_license_area(){
    include WPSC_EDD_DIR . 'includes/admin/addon_license_area.php';
  }
  // Activate Canned Reply license
  function license_activate(){
    include WPSC_EDD_DIR . 'includes/admin/license_activate.php';
    die();
  }
  
  // Deactivate Canned Reply license
  function license_deactivate(){
    include WPSC_EDD_DIR . 'includes/admin/license_deactivate.php';
    die();
  }
  
  /**
   * Add EDD Custom Fields 
   */
  function cond_options_custom_fields( $condition_options, $field_type, $field){
    include WPSC_EDD_DIR . 'includes/admin/cond_options_custom_fields.php';
    return $condition_options;
  }
  
  /**
   * Add EDD custom fields options
   */
  function condition_dd_options($options, $field_type, $custom_field){
    include WPSC_EDD_DIR . 'includes/admin/condition_dd_options.php';
    return $options;
  }
  
  /**
   * check ticket conditions EDD custom field type 
   */
  function check_ticket_conditions_custom_field_type($inner_flag, $ticket_id, $condition, $custom_field_type, $custom_field ){
    include WPSC_EDD_DIR . 'includes/admin/check_ticket_conditions_custom_field_type.php';
    return $inner_flag;
  }
}
?>