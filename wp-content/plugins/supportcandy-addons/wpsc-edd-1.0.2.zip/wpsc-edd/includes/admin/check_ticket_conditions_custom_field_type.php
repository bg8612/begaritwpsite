<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $current_user, $wpscfunction;

if($custom_field_type == 13 ){
  $field_val  = $wpscfunction->get_ticket_meta( $ticket_id, $custom_field->slug );
  if( $condition->compare == 'match' ){
    $inner_flag = in_array( $condition->cond_val, $field_val ) ? true : false;
  } elseif( $condition->compare == 'not_match' ) {
    $inner_flag = (!in_array( $condition->cond_val, $field_val )) ? true : false;
  }
}