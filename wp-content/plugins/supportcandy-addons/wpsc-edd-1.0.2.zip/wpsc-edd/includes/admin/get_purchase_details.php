<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $wpdb, $current_user, $edd_receipt_args;

$customer_email = isset($_POST['customer_email']) ? sanitize_text_field($_POST['customer_email']) : '' ;
$payment_id = isset($_POST['payment_id']) ? intval(sanitize_text_field($_POST['payment_id'])) : 0 ;
$nonce      = isset($_POST['nonce']) ? sanitize_text_field($_POST['nonce']) : '' ;


$modal_title = sprintf(__('Order #%s','wpsc-edd'),$payment_id);

	ob_start();
    /**
     * This template is used to display the purchase summary with [edd_receipt]
     */
		 $edd_receipt_args=array(
			 'error'           => __( 'Sorry, trouble retrieving payment receipt.', 'wpsc-edd' ),
       'price'           => true,
       'discount'        => true,
       'products'        => true,
       'date'            => true,
       'notes'           => true,
       'payment_key'     => false,
       'payment_method'  => true,
       'payment_id'      => true
     );

		 $payment   = get_post( $payment_id );
		 if( empty( $payment ) ) : ?>

		 <div class="edd_errors edd-alert edd-alert-error">
			 <?php _e( 'The specified receipt ID appears to be invalid', 'wpsc-edd' ); ?>
		 </div>
		 <?php
		 return;
	 endif;

	 $meta      = edd_get_payment_meta( $payment->ID );
	 $cart      = edd_get_payment_meta_cart_details( $payment->ID, true );
	 $user      = edd_get_payment_meta_user_info( $payment->ID );
	 $email     = edd_get_payment_user_email( $payment->ID );
	 $status    = edd_get_payment_status( $payment, true );
	 ?>

	 <div class="col-md-12 table-responsive">
		 <table id="edd_purchase_receipt" class="table table-striped table-hover">
			 <thead>
				 <?php do_action( 'edd_payment_receipt_before', $payment, $edd_receipt_args ); ?>

				 <?php if ( filter_var( $edd_receipt_args['payment_id'], FILTER_VALIDATE_BOOLEAN ) ) : ?>
					 <tr>
						 <th><strong><?php _e( 'Payment', 'wpsc-edd' ); ?>:</strong></th>
						 <th><?php echo edd_get_payment_number( $payment->ID ); ?></th>
					 </tr>
				 <?php endif; ?>
			 </thead>

			 <tbody>
				 <tr>
					 <td class="edd_receipt_payment_status"><strong><?php _e( 'Payment Status', 'wpsc-edd' ); ?>:</strong></td>
					 <td class="edd_receipt_payment_status <?php echo strtolower( $status ); ?>"><?php echo $status; ?></td>
				 </tr>

				 <?php if ( filter_var( $edd_receipt_args['payment_key'], FILTER_VALIDATE_BOOLEAN ) ) : ?>
					 <tr>
						 <td><strong><?php _e( 'Payment Key', 'wpsc-edd' ); ?>:</strong></td>
						 <td><?php echo get_post_meta( $payment->ID, '_edd_payment_purchase_key', true ); ?></td>
					 </tr>
				 <?php endif; ?>

				 <?php if ( filter_var( $edd_receipt_args['payment_method'], FILTER_VALIDATE_BOOLEAN ) ) : ?>
					 <tr>
						 <td><strong><?php _e( 'Payment Method', 'wpsc-edd' ); ?>:</strong></td>
						 <td><?php echo edd_get_gateway_checkout_label( edd_get_payment_gateway( $payment->ID ) ); ?></td>
					 </tr>
				 <?php endif; ?>
        
				 <?php if ( filter_var( $edd_receipt_args['date'], FILTER_VALIDATE_BOOLEAN ) ) : ?>
					 <tr>
						 <td><strong><?php _e( 'Date', 'wpsc-edd' ); ?>:</strong></td>
						 <td><?php echo date_i18n( get_option( 'date_format' ), strtotime( $meta['date'] ) ); ?></td>
					 </tr>
				 <?php endif; ?>

				 <?php if ( ( $fees = edd_get_payment_fees( $payment->ID, 'fee' ) ) ) : ?>
					 <tr>
						 <td><strong><?php _e( 'Fees', 'wpsc-edd' ); ?>:</strong></td>
						 <td>
							 <ul class="edd_receipt_fees">
								 <?php foreach( $fees as $fee ) : ?>
									 <li>
										 <span class="edd_fee_label"><?php echo esc_html( $fee['label'] ); ?></span>
										 <span class="edd_fee_sep">&nbsp;&ndash;&nbsp;</span>
										 <span class="edd_fee_amount"><?php echo edd_currency_filter( edd_format_amount( $fee['amount'] ) ); ?></span>
									 </li>
								 <?php endforeach; ?>
							 </ul>
						 </td>
					 </tr>
				 <?php endif; ?>

				 <?php if ( filter_var( $edd_receipt_args['discount'], FILTER_VALIDATE_BOOLEAN ) && isset( $user['discount'] ) && $user['discount'] != 'none' ) : ?>
					 <tr>
						 <td><strong><?php _e( 'Discount(s)', 'wpsc-edd' ); ?>:</strong></td>
						 <td><?php echo $user['discount']; ?></td>
					 </tr>
				 <?php endif; ?>

				 <?php if( edd_use_taxes() ) : ?>
					 <tr>
						 <td><strong><?php _e( 'Tax', 'wpsc-edd' ); ?></strong></td>
						 <td><?php echo edd_payment_tax( $payment->ID ); ?></td>
					 </tr>
				 <?php endif; ?>

				 <?php if ( filter_var( $edd_receipt_args['price'], FILTER_VALIDATE_BOOLEAN ) ) : ?>
					 <tr>
						 <td><strong><?php _e( 'Subtotal', 'wpsc-edd' ); ?></strong></td>
						 <td>
							 <?php echo edd_payment_subtotal( $payment->ID ); ?>
						 </td>
					 </tr>

					 <tr>
						 <td><strong><?php _e( 'Total Price', 'wpsc-edd' ); ?>:</strong></td>
						 <td><?php echo edd_payment_amount( $payment->ID ); ?></td>
					 </tr>

				 <?php endif; ?>
				 	<?php do_action( 'edd_payment_receipt_after', $payment, $edd_receipt_args ); ?>
				</tbody>
			</table>

			<?php do_action( 'edd_payment_receipt_after_table', $payment, $edd_receipt_args ); ?>

			<?php if ( filter_var( $edd_receipt_args['products'], FILTER_VALIDATE_BOOLEAN ) ) : ?>

				<h4><?php echo apply_filters( 'edd_payment_receipt_products_title', __( 'Products', 'wpsc-edd' ) ); ?></h4>

				<table id="edd_purchase_receipt_products" class="table table-striped table-hover">
					<thead>
          
						<th><?php _e( 'Name', 'wpsc-edd' ); ?></th>
						<?php if ( edd_use_skus() ) { ?>
							<th><?php _e( 'SKU', 'wpsc-edd' ); ?></th>
						<?php } ?>
						<?php if ( edd_item_quantities_enabled() ) : ?>
							<th><?php _e( 'Quantity', 'wpsc-edd' ); ?></th>
						<?php endif; ?>
						<th><?php _e( 'Price', 'wpsc-edd' ); ?></th>
					</thead>
					
					<tbody>
						<?php if( $cart ) : ?>
							<?php foreach ( $cart as $key => $item ) : ?>
								<?php if( ! apply_filters( 'edd_user_can_view_receipt_item', true, $item ) ) : ?>
									<?php continue; // Skip this item if can't view it ?>
								<?php endif; ?>

								<?php if( empty( $item['in_bundle'] ) ) : ?>
									<tr>
										<td>
											<?php
											$price_id       = edd_get_cart_item_price_id( $item );
											$download_files = edd_get_download_files( $item['id'], $price_id );
											?>

											<div class="edd_purchase_receipt_product_name">
												<?php echo esc_html( $item['name'] ); ?>
												<?php if( edd_has_variable_prices( $item['id'] ) && ! is_null( $price_id ) ) : ?>
													<span class="edd_purchase_receipt_price_name">&nbsp;&ndash;&nbsp;<?php echo edd_get_price_option_name( $item['id'], $price_id, $payment->ID ); ?></span>
												<?php endif; ?>
											</div>
										</td>
                  
										<?php if ( edd_item_quantities_enabled() ) { ?>
											<td><?php echo $item['quantity']; ?></td>
										<?php } ?>
                  
										<td>
											<?php if( empty( $item['in_bundle'] ) ) : // Only show price when product is not part of a bundle ?>
												<?php echo edd_currency_filter( edd_format_amount( $item[ 'price' ] ) ); ?>
											<?php endif; ?>
										</td>
									</tr>
								<?php endif; ?>
							<?php endforeach; ?>
						<?php endif; ?>
          
						<?php if ( ( $fees = edd_get_payment_fees( $payment->ID, 'item' ) ) ) : ?>
							<?php foreach( $fees as $fee ) : ?>
								<tr>
									<td class="edd_fee_label"><?php echo esc_html( $fee['label'] ); ?></td>
									<?php if ( edd_item_quantities_enabled() ) : ?>
										<td></td>
									<?php endif; ?>
									<td class="edd_fee_amount"><?php echo edd_currency_filter( edd_format_amount( $fee['amount'] ) ); ?></td>
								</tr>
							<?php endforeach; ?>
						<?php endif; ?>
					</tbody>
				</table>
				<?php 
			endif;
			?>
		</div>
		<?php
$modal_body = ob_get_clean();

$response = array(
    'title'     => $modal_title,
    'body'      => $modal_body
);

echo json_encode($response);