<?php 
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
$custom_field = get_term_by('slug', $field_slug, 'wpsc_ticket_custom_fields');
$type = get_term_meta( $custom_field->term_id, 'wpsc_tf_type', true);
if($type == "13"){
  $args = array(
    'orderby'           => 'title',
    'order'             => 'ASC',
    'post_type'         => 'download',
    'post_status'       => 'publish',
    'posts_per_page'    => 100,
    's'          => $term,
  );
  
  $products = get_posts( $args );
  foreach($products as $product){
    $output[] = array(
      'label'    => $product->post_title,
      'value'    => '',
      'flag_val' => $product->ID,
      'slug'     => $field_slug,
    );
  }
  }


 ?>