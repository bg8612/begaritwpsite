<?php 

final class WPSC_EDD_Frontend{
  
  function edd_purchase_history_header_after(){
    ?>
    <th class="edd_purchase_details"><?php _e('Support','wpsc-edd' ); ?></th>
    <?php
  }
  
  function edd_purchase_history_row_end($ticket_id, $purchase_data){
    
    $url=get_permalink(get_option('wpsc_support_page_id')).'/?support_page=create_ticket&edd_order_id='.$ticket_id;
    ?>
    <td>
      <a href="<?php echo $url;?>"><?php _e('Help','wpsc-edd');?></a>
    </td>
    <?php
  }
  }
 ?>