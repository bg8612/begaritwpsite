<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

$widget = get_term_by( 'slug', 'edd-order', 'wpsc_ticket_widget' );

if($widget){
	wp_delete_term( $widget->term_id, 'wpsc_ticket_widget' );
	$wpsc_custom_widget_localize = get_option('wpsc_custom_widget_localize');
	unset($wpsc_custom_widget_localize['custom_widget_' .$widget->term_id]);
  update_option('wpsc_custom_widget_localize', $wpsc_custom_widget_localize);
}

$fields = get_terms([
	'taxonomy'   => 'wpsc_ticket_custom_fields',
	'hide_empty' => false,
	'orderby'    => 'meta_value_num',
	'meta_key'	 => 'wpsc_tf_load_order',
	'order'    	 => 'ASC',
	'meta_query' => array(
		array(
			'key'       => 'wpsc_tf_type',
			'value'     => array(13,14),
			'compare'   => 'IN'
		)
	),
]);

foreach ($fields as $field){
	update_term_meta ($field->term_id, 'wpsc_customer_ticket_list_status', '0');
	update_term_meta ($field->term_id, 'wpsc_agent_ticket_list_status', '0');
	update_term_meta ($field->term_id, 'wpsc_customer_ticket_filter_status', '0');
	update_term_meta ($field->term_id, 'wpsc_agent_ticket_filter_status', '0');
}
