<?php 
/**
 * Plugin Name:  SupportCandy - EDD Integration
 * Plugin URI: https://www.supportcandy.net/
 * Description: Easy digital Downloads integration SupportCandy!
 * Version: 1.0.2
 * Author: Support Candy
 * Author URI: https://supportcandy.net/
 * Requires at least: 4.4
 * Text Domain: wpsc-edd
 * Domain Path: /lang
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if(class_exists('Support_Candy') && class_exists( 'Easy_Digital_Downloads' )){
	$GLOBALS['WPSC_EDD'] = new WPSC_EDD();
}

final class WPSC_EDD {
  /*
   * Constructor
   */
	 public function __construct() {
		 $this->define_constants();
		 add_action( 'init', array($this,'load_textdomain') );
		 $this->include_files();
		 //plugin updator
		 add_action('admin_init',array($this,'plugin_updator'));
		 add_action('init', array($this, 'after_init'));

		 register_deactivation_hook( __FILE__, array($this,'deactivate') );
		 register_activation_hook(__FILE__,array($this,'activation'));
	 }
	 function define_constants(){

		 define( 'WPSC_EDD_PLUGIN_FILE', __FILE__ );
		 define( 'WPSC_EDD_URL', plugin_dir_url( __FILE__ ) );
		 define( 'WPSC_EDD_DIR', plugin_dir_path( __FILE__ ) );
		 define( 'WPSC_EDD_VERSION', '1.0.2');
		 define( 'WPSC_EDD_STORE_ID', '15956' );
   }
	 
	 function after_init(){
		if(!is_admin()){
			add_filter('wpsc_create_ticket_short_para', array($this, 'wpsc_create_ticket_short_para'));
		}
	 }
	 
	 function wpsc_create_ticket_short_para($url_attrs){
		global $post;
		
		if(isset($post) && $post->post_type=='product'){
			$url_attrs[] = 'edd_prod_id :"'.$post->ID.'"';
		}
		
		return $url_attrs;
	 }
   /*
    * Textdomain loaded for this customization.
    */

		function load_textdomain(){
			$locale = apply_filters( 'plugin_locale', get_locale(), 'wpsc-edd' );
			load_textdomain( 'wpsc-edd', WP_LANG_DIR . '/wpsc/wpsc-edd-' . $locale . '.mo' );
			load_plugin_textdomain( 'wpsc-edd', false, plugin_basename( dirname( __FILE__ ) ) . '/lang' );
		}

		function include_files(){

			include( WPSC_EDD_DIR.'includes/admin/admin.php' );
			include( WPSC_EDD_DIR.'includes/frontend.php' );
			include_once( WPSC_EDD_DIR. 'class-wpsc-edd-install.php' );

			$woo_install = new WPSC_EDD_Install();
			$backend=new WPSC_EDD_Backend();
			$frontend=new WPSC_EDD_Frontend();
			
			if (is_admin()) {
				
				add_filter('wpsc_custom_field_types', array($backend,'wpsc_custom_field_types'),10,1);
				add_action('wpsc_print_custom_form_field', array($backend, 'wpsc_print_custom_form_field'), 10, 2 );
				add_filter('wpsc_after_create_ticket_custom_field',array($backend,'wpsc_after_create_ticket_custom_field'),10,3);
				add_action('wpsc_add_ticket_meta_custom_field',array($backend,'wpsc_add_ticket_meta_custom_field'),10,4);
				add_action('wpsc_widget_ticket_field_item',array($backend, 'wpsc_widget_ticket_field_item'), 10, 3);
				add_action('wpsc_print_edit_custom_form_field', array($backend, 'wpsc_print_edit_custom_form_field'), 10, 2 );
			  add_action('wpsc_print_custom_tl_field',array($backend,'wpsc_print_custom_tl_field'),10,1);
				add_action('wpsc_add_ticket_widget',array($backend,'wpsc_add_ticket_widget'),10,3); 
				add_filter('wpsc_change_field_value',array($backend,'change_the_field'),10,4);
				add_filter('wpsc_change_prev_field_value',array($backend,'change_prev_field_value'),10,4);
				add_filter('wpsc_change_field_name',array($backend,'wpsc_change_the_name'),10,5);
				
				//Conditions
        add_filter('wpsc_cond_options_custom_fields',array($backend,'cond_options_custom_fields'), 10, 3);
        add_filter('wpsc_condition_custom_field_dd_options',array($backend,'condition_dd_options'),10, 3);
        add_filter('wpsc_check_ticket_conditions_custom_field_type',array($backend,'check_ticket_conditions_custom_field_type'), 10, 5);
			}  
			else {
				add_action( 'edd_purchase_history_header_after', array($frontend, 'edd_purchase_history_header_after') );
				add_action( 'edd_purchase_history_row_end', array($frontend, 'edd_purchase_history_row_end'), 10, 2 );
			}
			     
			add_action( 'wpsc_after_individual_ticket', array($backend,'wpsc_after_individual_ticket'),10,1);
			add_action( 'wp_ajax_wpsc_edd_get_purchase_details', array($backend,'get_purchase_details'));
			
			// change edd field
			add_action('wpsc_set_change_ticket_field',array($backend, 'wpsc_set_change_ticket_field'), 10, 4);
			
			add_filter( 'wpsc_filter_autocomplete', array($backend, 'filter_autocomplete'), 10, 3 ); //required only if saved value is different than search value
			add_filter('wpsc_filter_val_label', array($backend, 'wpsc_filter_val_label'), 10, 2);
      add_filter('wpsc_search_filter_query', array($backend, 'wpsc_search_filter_query'), 10, 2);
      
			//Macro
			add_filter('wpsc_replace_macro_custom', array($backend, 'replace_macro'), 10, 4);
			
			// License
			add_filter( 'wpsc_is_add_on_installed', array($backend,'is_add_on_installed'));
			add_action( 'wpsc_addon_license_area', array($backend,'addon_license_area'));
			add_action( 'wp_ajax_wpsc_edd_activate_license', array($backend,'license_activate'));
			add_action( 'wp_ajax_wpsc_edd_deactivate_license', array($backend,'license_deactivate'));
			add_action( 'admin_init', array($this, 'plugin_updator'));
	
		}
		
		function activation(){
			//add edd widget at activation
			$agent_role_ids = array();
			$agent_role = get_option('wpsc_agent_role');
			foreach ($agent_role as $key => $agent) {
				$agent_role_ids[] = $key;
			}
			$term = wp_insert_term('EDD Order', 'wpsc_ticket_widget' );
			if (!is_wp_error($term) && isset($term['term_id'])) {
					add_term_meta ($term['term_id'], 'wpsc_label', __('EDD Order','wpsc-edd'));
					add_term_meta ($term['term_id'], 'wpsc_ticket_widget_load_order', '4');
					add_term_meta($term['term_id'], 'wpsc_ticket_widget_type', '1');
					add_term_meta($term['term_id'],'wpsc_ticket_widget_role', $agent_role_ids);
					$wpsc_custom_widget_localize = get_option('wpsc_custom_widget_localize');
	        $wpsc_custom_widget_localize['custom_widget_'.$term['term_id']] = get_term_meta($term['term_id'], 'wpsc_label', true);;
	        update_option('wpsc_custom_widget_localize', $wpsc_custom_widget_localize);
			}
		}
		
		function deactivate(){
			include( WPSC_EDD_DIR.'class-wpsc-edd-uninstall.php' );
		}
		
		function plugin_updator(){
      $license_key = get_option( 'wpsc_edd_license_key' ,'');
      $license_expiry = get_option('wpsc_edd_license_expiry','');
       if(class_exists('Support_Candy') && $license_key && $license_expiry ) {
        $edd_updater = new EDD_SL_Plugin_Updater( WPSC_STORE_URL, __FILE__, array(
          'version' => WPSC_EDD_VERSION,
          'license' => $license_key,
          'item_id' => WPSC_EDD_STORE_ID,
          'author'  => 'Pradeep Makone',
          'url'     => site_url()
        ));
      }
    }
	}